<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-02-08 16:46:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:47:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:47:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:49:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 16:49:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:21:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:21:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:21:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:21:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:21:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-02-08 17:21:57 --> Parsing Error - syntax error, unexpected T_INC, expecting ')' in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 12
WARNING - 2015-02-08 17:22:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-02-08 17:22:04 --> Parsing Error - syntax error, unexpected T_INC, expecting ')' in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 12
WARNING - 2015-02-08 17:23:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-02-08 17:23:23 --> 8 - Undefined variable: i in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 14
ERROR - 2015-02-08 17:23:23 --> 8 - Undefined variable: i in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 14
ERROR - 2015-02-08 17:23:23 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 14
ERROR - 2015-02-08 17:23:23 --> 8 - Undefined variable: i in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 14
ERROR - 2015-02-08 17:23:23 --> 8 - Undefined variable: i in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 14
ERROR - 2015-02-08 17:23:23 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\propertydetails\propertyoverlay.php on line 14
WARNING - 2015-02-08 17:23:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-08 17:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
