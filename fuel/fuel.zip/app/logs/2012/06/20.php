<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-06-20 00:00:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:03:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:04:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:05:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:06:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:07:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:09:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:09:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:12:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:17:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:18:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:22:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:23:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:23:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:24:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:25:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:25:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:26:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:28:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:28:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:30:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:30:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:31:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:32:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:32:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:33:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:34:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:38:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 00:38:20 --> Parsing Error - syntax error, unexpected '/' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 00:38:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 00:38:56 --> Parsing Error - syntax error, unexpected T_NS_SEPARATOR, expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 00:39:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 00:39:14 --> Parsing Error - syntax error, unexpected T_NS_SEPARATOR, expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 00:39:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 00:39:24 --> Parsing Error - syntax error, unexpected T_VARIABLE, expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 00:39:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:41:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:47:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:48:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:49:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:49:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:50:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:50:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:51:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:51:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:52:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:52:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:53:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:53:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 00:54:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:35:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:37:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:40:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:40:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:40:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:41:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:41:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:41:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:41:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:41:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:42:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:42:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:42:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:42:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:43:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:43:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:44:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:45:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:45:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:46:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:46:27 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:27 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-20 18:46:27 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:27 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-20 18:46:27 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:27 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-20 18:46:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:46:41 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:41 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:41 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-20 18:46:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:46:55 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:55 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 18:46:55 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-20 18:47:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:48:45 --> Parsing Error - syntax error, unexpected '{', expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 18:49:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:49:26 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW, expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 18:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:49:40 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR, expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 18:50:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:50:28 --> Parsing Error - syntax error, unexpected '(', expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 18:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:51:00 --> Parsing Error - syntax error, unexpected '}', expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 16
Warning - 2012-06-20 18:51:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:51:24 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-20 18:51:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 18:51:38 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-20 18:51:38 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-20 18:51:38 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-20 18:51:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:53:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:53:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:53:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:55:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:56:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:57:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:59:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 18:59:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:00:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:00:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:00:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:01:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:01:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:01:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:02:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:02:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:02:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:02:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:03:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:13:31 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Error - 2012-06-20 19:13:31 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Error - 2012-06-20 19:13:31 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Warning - 2012-06-20 19:13:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:13:47 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 23
Error - 2012-06-20 19:13:47 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 23
Error - 2012-06-20 19:13:47 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 23
Warning - 2012-06-20 19:14:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:14:22 --> Parsing Error - syntax error, unexpected '(', expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 19:14:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:14:35 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 23
Error - 2012-06-20 19:14:35 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 23
Error - 2012-06-20 19:14:35 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 23
Warning - 2012-06-20 19:14:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:14:58 --> 8 - Undefined index: lat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 19:14:58 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Error - 2012-06-20 19:14:58 --> 8 - Undefined index: lat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 19:14:58 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Error - 2012-06-20 19:14:58 --> 8 - Undefined index: lat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-20 19:14:58 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Warning - 2012-06-20 19:15:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:15:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:16:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:16:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:16:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:16:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:17:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:18:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:18:31 --> Parsing Error - syntax error, unexpected '{' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 19:20:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:20:03 --> Parsing Error - syntax error, unexpected '{' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 19:24:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:25:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:26:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:27:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:27:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:28:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:28:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:28:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:28:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:29:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:30:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:36:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:36:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:38:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:38:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:39:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:41:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:41:30 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Warning - 2012-06-20 19:41:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:41:57 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Warning - 2012-06-20 19:42:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 19:42:00 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Warning - 2012-06-20 19:42:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:42:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:44:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:44:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:45:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:46:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:47:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:48:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:48:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:48:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:48:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:49:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:49:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:50:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:50:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:50:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:54:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:55:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:56:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:57:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:58:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:58:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 19:59:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:02:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:02:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:03:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:03:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:03:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:04:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:05:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:06:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:07:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:08:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:09:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:09:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:14:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:16:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:16:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:18:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:19:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:19:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 20:59:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:00:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:05:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:06:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:14:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 21:14:49 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-20 21:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:16:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:20:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:21:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:23:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:24:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:24:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:25:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:25:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:25:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:28:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:31:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 21:31:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:00:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:01:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:01:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:01:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:02:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:03:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:04:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:08:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:08:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:08:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:08:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:09:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:09:36 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-20 22:09:36 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Warning - 2012-06-20 22:09:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:09:53 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-20 22:09:53 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Warning - 2012-06-20 22:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:10:47 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Warning - 2012-06-20 22:11:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:11:58 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 28
Warning - 2012-06-20 22:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:12:23 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Warning - 2012-06-20 22:14:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:18:17 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:18:17 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:18:32 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:18:32 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:18:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:18:45 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:18:45 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:19:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:19:11 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 22:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:19:22 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:19:22 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:19:45 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:19:45 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:20:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:20:26 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:20:26 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:20:52 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-20 22:20:52 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:20:52 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:21:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:21:07 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:21:07 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:21:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:21:49 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-20 22:21:49 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-20 22:21:49 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-20 22:21:49 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:22:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:22:02 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-20 22:22:02 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-20 22:22:02 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-20 22:22:02 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:22:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:22:26 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Warning - 2012-06-20 22:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:28:01 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Warning - 2012-06-20 22:28:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:28:29 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Warning - 2012-06-20 22:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:29:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:30:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:30:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:30:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:30:48 --> 8 - Undefined variable: num in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 39
Error - 2012-06-20 22:30:48 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 41
Error - 2012-06-20 22:30:48 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Error - 2012-06-20 22:30:48 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Warning - 2012-06-20 22:31:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Error - 2012-06-20 22:31:28 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 22:31:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:31:54 --> 8 - Undefined variable: num in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 39
Error - 2012-06-20 22:31:54 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 41
Error - 2012-06-20 22:31:54 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Error - 2012-06-20 22:31:54 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Warning - 2012-06-20 22:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:32:10 --> 8 - Undefined variable: num in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 39
Error - 2012-06-20 22:32:10 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 41
Error - 2012-06-20 22:32:10 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Error - 2012-06-20 22:32:10 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 45
Warning - 2012-06-20 22:32:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:33:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:34:41 --> Parsing Error - syntax error, unexpected T_LOGICAL_OR in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-20 22:37:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:37:34 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 340
Warning - 2012-06-20 22:37:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:37:43 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 22:38:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:38:49 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 22:38:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:38:50 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 22:40:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:40:59 --> 8 - Undefined property: stdClass::$id in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 144
Error - 2012-06-20 22:40:59 --> 8 - Undefined property: stdClass::$id in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 144
Error - 2012-06-20 22:40:59 --> 8 - Undefined property: stdClass::$id in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 144
Error - 2012-06-20 22:40:59 --> 4096 - Object of class stdClass could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-20 22:44:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:44:04 --> 8 - Undefined property: stdClass::$id in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 144
Error - 2012-06-20 22:44:04 --> 8 - Undefined property: stdClass::$id in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 144
Error - 2012-06-20 22:44:04 --> 8 - Undefined property: stdClass::$id in C:\wamp\www\rentsignal\fuel\core\classes\database\result.php on line 144
Error - 2012-06-20 22:44:04 --> 8 - Undefined variable: num in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Error - 2012-06-20 22:44:04 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Error - 2012-06-20 22:44:04 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:44:04 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:45:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:45:53 --> 8 - Undefined variable: num in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Error - 2012-06-20 22:45:53 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Error - 2012-06-20 22:45:53 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:45:53 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:47:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:47:03 --> 8 - Undefined variable: num in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Error - 2012-06-20 22:47:03 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Error - 2012-06-20 22:47:03 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-20 22:47:03 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-20 22:47:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:47:17 --> 4096 - Object of class stdClass could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-20 22:47:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:47:51 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:47:51 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:48:12 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:48:12 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:48:45 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:48:45 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:49:11 --> Compile Error - Cannot use [] for reading in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Warning - 2012-06-20 22:49:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:49:20 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:49:20 --> 8 - Undefined variable: groupcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:51:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:51:41 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Error - 2012-06-20 22:51:41 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 22:52:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:52:33 --> 8 - Undefined variable: print_r in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-20 22:52:33 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-20 22:53:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:53:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:53:49 --> 8 - Undefined offset: 1 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Warning - 2012-06-20 22:53:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:53:51 --> 8 - Undefined offset: 1 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Warning - 2012-06-20 22:54:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:54:07 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Error - 2012-06-20 22:54:07 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Warning - 2012-06-20 22:54:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:54:34 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:54:34 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:54:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:54:43 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:54:43 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:55:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:55:03 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Error - 2012-06-20 22:55:03 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 33
Warning - 2012-06-20 22:56:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:56:43 --> 8 - Use of undefined constant i - assumed 'i' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 36
Error - 2012-06-20 22:56:43 --> 8 - Undefined index: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 36
Warning - 2012-06-20 22:57:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:57:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 22:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:59:31 --> Error - Call to undefined method Fuel\Core\Database_Result_Cached::as_object() in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 22:59:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 22:59:48 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 23:02:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:02:39 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:16:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:16:03 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-20 23:16:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:16:22 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-20 23:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:17:03 --> Error - Cannot use object of type stdClass as array in C:\wamp\www\rentsignal\fuel\core\classes\arr.php on line 199
Warning - 2012-06-20 23:17:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:17:33 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:18:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:18:19 --> Error - Cannot use object of type stdClass as array in C:\wamp\www\rentsignal\fuel\core\classes\arr.php on line 199
Warning - 2012-06-20 23:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:19:30 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:20:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:20:17 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:20:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:20:50 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:24:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:24:55 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:25:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:25:36 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-20 23:27:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:27:30 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-20 23:28:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-20 23:28:00 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 30
Warning - 2012-06-20 23:28:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 23:29:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 23:33:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 23:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 23:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-20 23:35:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
