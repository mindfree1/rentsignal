<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-05-06 22:06:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:07:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:09:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:10:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:10:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:12:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:12:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:12:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:12:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:12:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:13:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:13:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:13:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:41:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 22:41:15 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'action NOT NULL,
	`load` action NOT NULL,
	`created_at` int(11) NOT NULL,
	`upda' at line 3 with query: "CREATE TABLE IF NOT EXISTS `mapgens` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`update` action NOT NULL,
	`load` action NOT NULL,
	`created_at` int(11) NOT NULL,
	`updated_at` int(11) NOT NULL,
	PRIMARY KEY `id` (`id`)
) DEFAULT CHARACTER SET utf8;" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2014-05-06 22:49:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 22:50:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:13:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:13:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:13:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:13:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:13:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:15:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:15:04 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-06 23:15:04 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-06 23:15:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:15:04 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-06 23:15:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:15:14 --> Error - SQLSTATE[42S02]: Base table or view not found: 1146 Table 'rentsignal.signals' doesn't exist with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`title` AS `t0_c1`, `t0`.`tags` AS `t0_c2`, `t0`.`short_description` AS `t0_c3`, `t0`.`lng_description` AS `t0_c4`, `t0`.`location` AS `t0_c5`, `t0`.`lat` AS `t0_c6`, `t0`.`lng` AS `t0_c7`, `t0`.`rent` AS `t0_c8`, `t0`.`avail_from` AS `t0_c9`, `t0`.`rooms` AS `t0_c10`, `t0`.`bathrooms` AS `t0_c11`, `t0`.`user_id` AS `t0_c12`, `t0`.`created_at` AS `t0_c13`, `t0`.`updated_at` AS `t0_c14` FROM `signals` AS `t0`" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2014-05-06 23:16:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:16:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:17:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:17:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:17:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:17:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:17:26 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-06 23:17:26 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-06 23:17:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:26 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-06 23:17:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:17:42 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:17:42 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:18:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:19:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:19:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:19:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:19:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:22:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:22:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:22:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:23:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:23:01 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:23:01 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:27:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:27:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:27:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:31:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:31:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:31:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:33:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:33:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:34:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:34:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:34:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:34:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:34:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:34:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:34:52 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:34:52 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:35:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:35:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:36:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:36:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:36:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:38:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:38:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:40:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:40:21 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:40:21 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-06 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:40:27 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-06 23:40:27 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-06 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:40:27 --> Error - Class 'Model_User' not found in C:\wamp\fuel\app\classes\controller\base.php on line 10
Warning - 2014-05-06 23:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:27 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-06 23:41:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:41:52 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-06 23:42:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:42:05 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-06 23:51:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:51:13 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\fuel\app\views\welcome\index.php on line 76
Warning - 2014-05-06 23:51:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:51:42 --> Parsing Error - syntax error, unexpected '/' in C:\wamp\fuel\app\views\welcome\index.php on line 76
Warning - 2014-05-06 23:52:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:52:21 --> 8 - Use of undefined constant hello - assumed 'hello' in C:\wamp\fuel\app\views\welcome\index.php on line 76
Error - 2014-05-06 23:52:21 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\welcome\index.php on line 76
Warning - 2014-05-06 23:53:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:53:48 --> 8 - Use of undefined constant hello - assumed 'hello' in C:\wamp\fuel\app\views\welcome\index.php on line 76
Error - 2014-05-06 23:53:48 --> Error - Using $this when not in object context in C:\wamp\fuel\app\views\welcome\index.php on line 76
Warning - 2014-05-06 23:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-06 23:54:06 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-06 23:56:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:56:46 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\welcome\index.php on line 76
Error - 2014-05-06 23:56:46 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\views\welcome\index.php on line 76
Warning - 2014-05-06 23:57:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:57:11 --> Error - Using $this when not in object context in C:\wamp\fuel\app\views\welcome\index.php on line 76
Warning - 2014-05-06 23:59:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-06 23:59:31 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\welcome\index.php on line 76
Error - 2014-05-06 23:59:31 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\views\welcome\index.php on line 76
