<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-09-20 13:17:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:17:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:17:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:17:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:19:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:19:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:19:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:20:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:20:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:20:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:20:55 --> 2 - Missing argument 1 for Model\Mapgen::search_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 28 and defined in C:\wamp\fuel\app\classes\model\mapgen.php on line 12
Error - 2012-09-20 13:20:55 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 14
Error - 2012-09-20 13:20:55 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 15
Error - 2012-09-20 13:20:55 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN  AND" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:26:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:26:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:26:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:26:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:26:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:26:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:26:22 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'bathooms' in 'where clause' with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms=1  AND bathooms=2" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:26:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:26:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:26:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:26:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:26:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:27:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:27:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:27:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:27:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:27:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:27:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:28:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:28:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:28:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:28:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:28:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:28:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:28:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:28:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:28:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:28:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:29:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:29:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:32:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:32:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:32:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:32:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:32:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:33:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:33:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:33:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:33:09 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Any' in 'where clause' with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=Any" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:33:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:33:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:33:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:33:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:33:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:33:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:33:26 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Any' in 'where clause' with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=Any" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:33:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:33:33 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 28
Warning - 2012-09-20 13:33:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:33:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:33:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:33:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:33:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:33:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:33:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:33:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:35:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:43:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:43:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:43:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:43:14 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:43:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:43:20 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:43:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:43:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:43:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:43:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:43:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:43:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:44:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:44:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:44:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:44:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:44:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:44:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:23 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:27 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 700 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:44:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:29 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:32 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:44:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:36 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:44:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:44:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:44:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '/% AND bathrooms=/%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=/% AND bathrooms=/%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:45:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:45:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:45:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:45:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:45:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:45:25 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 78 AND 1000 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:45:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:45:32 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 78 AND 1000 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:45:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:45:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:45:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:45:50 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:46:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:46:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:46:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:46:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:46:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:48:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:48:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:48:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 13:48:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 13:48:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 13:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:49:11 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:49:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:49:14 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 13:49:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 13:49:19 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 17:28:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 17:28:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 17:28:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 17:28:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 17:28:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 17:28:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 17:28:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 17:28:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 17:28:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 17:28:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 17:28:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:11:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:20 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:25 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:31 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:36 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:41 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:41 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:42 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:57 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:11:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:11:57 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:12:02 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:12:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:12:03 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:12:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:12:09 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:12:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:12:10 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:48:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:48:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:48:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:48:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:48:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:48:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:48:46 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms LIKE%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE% AND bathrooms LIKE%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:50:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:50:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:50:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:50:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:50:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:50:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:50:11 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE1  AND bathrooms LIKE2' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms LIKE1  AND bathrooms LIKE2" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:50:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:50:16 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE1  AND bathrooms LIKE2' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 1000 AND rooms LIKE1  AND bathrooms LIKE2" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:50:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:50:18 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE1  AND bathrooms LIKE2' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 0 AND 1000 AND rooms LIKE1  AND bathrooms LIKE2" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:50:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:51:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:51:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:51:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:51:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:51:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:51:41 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 700 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:51:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:51:44 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 300 AND 964 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:51:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:51:47 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 13 AND 964 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:52:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:52:07 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% AND bathrooms=%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 13 AND 964 AND rooms=% AND bathrooms=%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:53:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:53:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:53:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:53:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:53:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:53:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:53:44 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '\% AND bathrooms LIKE\%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 23 AND 987 AND rooms LIKE\% AND bathrooms LIKE\%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 18:54:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:54:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:54:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 18:54:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 18:54:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 18:54:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 18:54:21 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '\% AND bathrooms LIKE \%' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN 30 AND 967 AND rooms LIKE \% AND bathrooms LIKE \%" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-20 19:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:00:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:00:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:00:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:00:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:00:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 19:00:25 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 34
Warning - 2012-09-20 19:00:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:00:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:01:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:01:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:01:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 19:01:44 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 34
Warning - 2012-09-20 19:01:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:01:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:06:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:06:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:06:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:06:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 19:07:22 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2012-09-20 19:07:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 19:07:35 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2012-09-20 19:07:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-20 19:07:38 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2012-09-20 19:07:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:07:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:07:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:07:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:08:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:08:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:08:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:08:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:08:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:08:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:08:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:08:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:08:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:08:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:09:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:09:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:09:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:09:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:09:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:09:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:09:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:09:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:09:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:10:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:10:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:10:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:11:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:11:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:11:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:11:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:11:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:11:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:11:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:11:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-20 19:12:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-20 19:12:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-20 19:12:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
