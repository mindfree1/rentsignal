<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-01-06 14:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-06 14:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-06 14:20:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-06 14:20:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-06 14:20:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-06 19:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
