<p style="position:absolute;margin-left:0px;"><b></b></p>
<ul id="pagination" style="position:absolute;margin-left:0px;">
	<p></p>
</ul>
<div style="padding-left:20px;padding-top:40px;right:10px;width:400px;height:300px;">
    <div style="width:800px;height:300px;">
<script>
	
</script>
<?php

	for($x=1; $x <= 1; $x++)
	{
		echo '<img id="img_'. $x .'" class="overlay_images" width="400px" height="300px" src="'. $images[$x-1]. '"' . '/>';	
	}

	for($i=2; $i <= $image_amount; $i++)
	{
		echo '<img id="img_'. $i .'" class="overlay_images" width="120px" height="120px" src="'. $images[$i-1]. '"' . '/>';
	}
	echo "</div>";
echo "</div>";
?>