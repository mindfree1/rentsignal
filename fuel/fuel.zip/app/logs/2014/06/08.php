<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-06-08 11:18:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 11:18:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 13:10:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 14:22:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 14:22:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 14:22:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 14:22:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 14:22:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 14:22:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-08 14:22:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-08 15:51:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 15:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 15:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 15:51:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 15:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 15:51:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-08 15:51:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-08 15:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-08 15:52:06 --> 8 - Undefined variable: current_user in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Error - 2014-06-08 15:52:06 --> 8 - Trying to get property of non-object in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-06-08 15:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-08 15:52:06 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-06-08 15:52:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
