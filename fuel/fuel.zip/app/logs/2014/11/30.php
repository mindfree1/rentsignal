<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2014-11-30 15:17:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-30 15:17:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
