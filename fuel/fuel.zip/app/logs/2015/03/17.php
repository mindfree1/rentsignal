<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-03-17 22:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
