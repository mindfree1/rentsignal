<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-06-25 19:40:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-25 19:40:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-25 19:40:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
