<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-14 00:01:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-14 00:01:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-14 00:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-14 00:03:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-14 00:08:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-14 00:48:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
