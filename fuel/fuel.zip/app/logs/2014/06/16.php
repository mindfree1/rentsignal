<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-06-16 19:44:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-16 19:44:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-16 19:44:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
