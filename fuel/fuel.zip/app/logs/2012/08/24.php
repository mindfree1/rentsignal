<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-24 00:00:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:00:02 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:02 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:02 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:02 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:00:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:00:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:00:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:00:06 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:00:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:00:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:00:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:00:16 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:16 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:16 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:16 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:16 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:00:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:00:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:00:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:00:48 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:00:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:00:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:00:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:00:55 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:55 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:55 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:55 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:00:55 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:00:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:00:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:01:07 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-24 00:01:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:01:16 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:01:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:01:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:01:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:01:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:01:21 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:01:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:01:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:03:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:03:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:03:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:03:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:03:41 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\fuel\app\views\listings\listings.php on line 47
Error - 2012-08-24 00:03:52 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-24 00:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:04:50 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:05:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:05:07 --> Parsing Error - syntax error, unexpected T_VARIABLE, expecting '(' in C:\wamp\fuel\app\views\listings\listings.php on line 47
Warning - 2012-08-24 00:05:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:05:24 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:06:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:06:17 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\views\listings\listings.php on line 47
Warning - 2012-08-24 00:06:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:06:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:06:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:07:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:07:27 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:07:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:07:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:07:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:07:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:07:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:08:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-24 00:08:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:08:01 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:08:01 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-24 00:08:01 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-24 00:08:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:08:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-24 00:08:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-24 00:08:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-24 00:08:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
