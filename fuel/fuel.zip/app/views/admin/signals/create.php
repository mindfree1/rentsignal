<h2>New Signal</h2>
<br>

<?php echo render('admin\signals/_form'); ?>


<p><?php echo Html::anchor('admin/signals', 'Back'); ?></p>
