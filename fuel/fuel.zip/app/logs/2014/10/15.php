<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-10-15 00:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:00:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:00:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:00:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:00:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:00:15 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 58
Warning - 2014-10-15 00:00:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:00:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:01:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:01:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:01:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:01:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:01:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:01:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:01:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:01:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:01:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:01:26 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:01:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:01:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:03:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:03:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:03:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:03:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:03:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:03:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:04:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:04:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:04:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:04:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:04:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:04:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:04:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:04:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:04:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:04:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:07:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:07:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:07:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:07:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:07:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:07:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:07:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:07:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:09:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:09:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:09:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:09:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:09:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:09:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:09:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:09:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:09:43 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `rentsignals`, `images` WHERE (`location` = 'images.location' AND `rent` BETWEEN '0' AND '446' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 00:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:10:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:10:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:10:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:10:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:10:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:10:59 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:10:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:10:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:11:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:11:13 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:11:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:11:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:11:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:11:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:11:39 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `rentsignals`, `images` WHERE (`location` = 'location' AND `rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 00:11:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:11:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:11:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:12:07 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:12:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:12:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:13:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:13:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:13:37 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:13:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:13:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:13:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:13:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:13:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:14:06 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:14:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:14:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:14:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:14:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:14:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:14:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:14:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:14:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:15:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:15:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:15:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:20:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:20:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:20:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:20:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:20:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:20:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:20:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:20:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:20:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:20:49 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:20:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:20:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:21:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:21:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:21:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:21:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:21:58 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images`, `rentsignals` WHERE (`location` = 'rentsignals.location' AND `rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 00:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:22:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:22:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:22:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:22:20 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images`, `rentsignals` WHERE (`location` = 'location' AND `rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 00:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:22:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:22:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:22:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:22:53 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images`, `rentsignals` WHERE (`location` LIKE '%' AND `rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 00:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:23:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:23:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:23:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:23:17 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images`, `rentsignals` WHERE (`location` LIKE 'glebe' AND `rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 00:23:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:23:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:25:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:31:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:31:54 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:31:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:31:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:32:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:32:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:32:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:32:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:32:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:32:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:32:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:32:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:32:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:32:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:33:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:33:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:33:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:33:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 00:33:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:33:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:33:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:33:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 00:33:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 00:33:26 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 00:33:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 00:33:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 11:43:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 11:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 11:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 11:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 11:43:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 11:43:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:33:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:33:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:33:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 12:33:42 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 58
Warning - 2014-10-15 12:33:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:33:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:33:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:33:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:33:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:34:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 12:34:01 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 58
Warning - 2014-10-15 12:34:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:34:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:38:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:38:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:38:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:38:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:39:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 12:39:10 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Warning - 2014-10-15 12:39:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:39:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:50:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:50:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:50:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:50:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:50:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 12:50:44 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
Warning - 2014-10-15 12:50:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:50:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:51:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:51:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:51:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:51:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:51:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 12:51:10 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
Warning - 2014-10-15 12:51:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:51:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:51:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:51:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:51:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:51:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:51:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:51:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:51:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:51:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:51:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:54:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:54:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:54:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:54:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:54:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:54:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:54:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:54:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:54:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:54:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:58:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:58:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 12:58:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 12:58:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 12:58:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 12:58:47 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `rentsignals`, `images` WHERE (`rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') AND (`location` = 'images.location') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 19:07:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:07:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:07:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:07:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:07:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 19:07:42 --> 8 - Undefined variable: query_results in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Error - 2014-10-15 19:07:42 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Error - 2014-10-15 19:07:42 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
Warning - 2014-10-15 19:07:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:07:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:08:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:08:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:08:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:08:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:08:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 19:08:37 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
Warning - 2014-10-15 19:08:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:08:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:08:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:08:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:08:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:09:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 19:09:06 --> 1052 - Column 'location' in on clause is ambiguous [ SELECT * FROM `rentsignals` RIGHT OUTER JOIN `images` ON (`location` = `images`.`location`) WHERE (`images`.`location` = 'rentsignals.location' AND `rent` BETWEEN '0' AND '700' AND `bathrooms` LIKE '2' AND `rooms` LIKE '1') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 19:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:09:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:09:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:09:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:09:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:09:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:09:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:09:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:09:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 19:09:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 19:09:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 19:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:52:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:52:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:52:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:53:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:53:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:53:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:53:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:56:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:56:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:56:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:56:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:56:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:56:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:56:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 20:56:20 --> 1241 - Operand should contain 1 column(s) [ SELECT * FROM `images` WHERE `location` IN (('glebe', 'mascot', 'rozelle')) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 20:57:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:57:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:57:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:57:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:57:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:58:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:58:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:58:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:58:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:58:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:58:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:58:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:58:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:58:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:58:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:58:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 20:59:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:59:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:59:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:59:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:59:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 20:59:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 20:59:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:06:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:06:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:06:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:06:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:06:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:06:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:06:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:06:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:06:53 --> 8 - Undefined index: image_urls in C:\wamp\fuel\app\classes\model\mapgen.php on line 54
Warning - 2014-10-15 21:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:10:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:10:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:10:17 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 54
Warning - 2014-10-15 21:10:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:10:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:10:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:10:57 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 54
Warning - 2014-10-15 21:10:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:10:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:11:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:11:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:11:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:11:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:11:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:11:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:11:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:11:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:11:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:12:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:12:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:12:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:12:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:12:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:12:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:12:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:12:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:12:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:12:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:12:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:12:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:13:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:13:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:13:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:13:13 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 54
Warning - 2014-10-15 21:13:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:13:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:14:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:14:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:14:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:14:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:14:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:14:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:14:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:14:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:14:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:14:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:15:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:15:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:15:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:15:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:15:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:15:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:15:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:15:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:15:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:15:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:15:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:16:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:16:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:16:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:16:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:17:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:17:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:17:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:17:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:17:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:17:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:17:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:17:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:17:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:17:13 --> 2 - json_encode() expects parameter 2 to be long, object given in C:\wamp\fuel\app\classes\model\mapgen.php on line 57
Warning - 2014-10-15 21:17:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:17:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:20:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:20:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:20:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:20:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:20:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:20:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:20:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:22:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:23:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:23:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:23:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:26:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:26:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:26:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:27:10 --> Error - Call to undefined function Model\search_images() in C:\wamp\fuel\app\classes\model\mapgen.php on line 39
Warning - 2014-10-15 21:27:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:27:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:27:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:27:35 --> Error - Call to undefined function Model\search_images() in C:\wamp\fuel\app\classes\model\mapgen.php on line 39
Warning - 2014-10-15 21:31:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:31:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:31:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:31:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:31:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:31:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:33:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:33:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:33:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:33:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:33:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:33:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:33:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:33:28 --> Parsing Error - syntax error, unexpected '[', expecting ')' in C:\wamp\fuel\app\classes\model\mapgen.php on line 42
Warning - 2014-10-15 21:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:34:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:34:38 --> Error - Call to undefined function Model\search_images() in C:\wamp\fuel\app\classes\model\mapgen.php on line 39
Warning - 2014-10-15 21:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:35:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:35:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:35:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:35:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:35:40 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\mapgen.php on line 39
Error - 2014-10-15 21:35:40 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-15 21:36:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:36:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:36:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:36:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:36:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:36:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:36:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:36:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:36:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:39:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:39:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:39:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:39:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:39:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:39:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:39:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:39:43 --> Error - Call to undefined function Model\search_images() in C:\wamp\fuel\app\classes\model\mapgen.php on line 58
Warning - 2014-10-15 21:40:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:40:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:40:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:40:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:40:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:40:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:40:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:40:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:40:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-15 21:40:59 --> Error - Call to undefined function Model\search_images() in C:\wamp\fuel\app\classes\model\mapgen.php on line 58
Warning - 2014-10-15 21:43:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:43:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:43:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:43:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:43:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:43:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:43:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:43:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:44:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:44:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:44:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 21:44:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-15 21:44:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-15 21:44:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-15 22:34:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
