<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-10-13 19:26:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:26:12 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 19:26:12 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 19:26:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:26:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:26:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:26:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:26:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:26:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:26:58 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-13 19:26:58 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-13 19:26:58 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-13 19:29:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:29:39 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 19:29:39 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 19:29:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:29:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:29:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:29:58 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-13 19:29:58 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-13 19:29:58 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-13 19:30:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:30:40 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\classes\controller\showlistings.php on line 27
Warning - 2013-10-13 19:31:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:31:09 --> 8 - Undefined variable: view in C:\wamp\fuel\app\classes\controller\showlistings.php on line 27
Warning - 2013-10-13 19:35:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:35:14 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 19:35:14 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 19:35:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:35:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:35:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:35:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:35:20 --> 8 - Undefined variable: view in C:\wamp\fuel\app\classes\controller\showlistings.php on line 27
Warning - 2013-10-13 19:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:36:14 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 19:36:14 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 19:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:36:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:36:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:36:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:36:21 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 19:36:21 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 19:45:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:45:14 --> Error - Using $this when not in object context in C:\wamp\fuel\app\views\welcome\index.php on line 66
Warning - 2013-10-13 19:45:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:45:27 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR, expecting ',' or ';' in C:\wamp\fuel\app\views\welcome\index.php on line 66
Warning - 2013-10-13 19:45:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:45:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:45:42 --> 8 - Undefined variable: template in C:\wamp\fuel\app\views\welcome\index.php on line 66
Error - 2013-10-13 19:45:42 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\views\welcome\index.php on line 66
Error - 2013-10-13 19:45:42 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 19:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:49:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:49:12 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 19:49:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:49:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:49:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:49:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:49:19 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-13 19:49:19 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-13 19:49:19 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-13 19:54:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:54:56 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 142
Warning - 2013-10-13 19:54:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:55:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:55:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:55:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:55:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:55:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:55:09 --> Error - Using $this when not in object context in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
Warning - 2013-10-13 19:59:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:59:34 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR, expecting ',' or ';' in C:\wamp\fuel\app\views\welcome\index.php on line 139
Warning - 2013-10-13 19:59:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 19:59:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 19:59:57 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 142
Warning - 2013-10-13 19:59:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:00:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:00:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:00:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:00:05 --> 8 - Undefined variable: imgdata in C:\wamp\fuel\app\classes\controller\showlistings.php on line 27
Error - 2013-10-13 20:00:05 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:00:05 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:00:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:00:52 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:00:52 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:06:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:06:11 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:06:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:06:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:06:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:06:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:06:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:06:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:06:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:06:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:16:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:16:09 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:16:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:16:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:16:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:16:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:16:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:16:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:16:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:16:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:19:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:19:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:19:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:26:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:26:52 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:26:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:27:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:27:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:27:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:27:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:27:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:27:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:27:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:27:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:27:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:28:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:28:32 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:28:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:28:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:28:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:28:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:28:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:28:37 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\controller\showlistings.php on line 25
Error - 2013-10-13 20:28:37 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-13 20:28:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-13 20:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:29:16 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:29:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:29:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:29:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:29:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:29:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:29:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:29:22 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\controller\showlistings.php on line 25
Error - 2013-10-13 20:29:22 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-13 20:29:22 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-13 20:30:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:30:11 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:30:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:30:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:30:47 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 143
Warning - 2013-10-13 20:30:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:30:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:30:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:31:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:31:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:31:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:31:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:32:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:32:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:32:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:32:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:32:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:32:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:33:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:33:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:36:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:36:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-13 20:36:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-13 20:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:39:52 --> Error - View variable is not set: content in C:\wamp\fuel\core\classes\view.php on line 425
Warning - 2013-10-13 20:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:40:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:40:28 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:40:28 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:40:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:40:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:41:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:41:09 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:41:09 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:41:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:41:16 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:41:16 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:43:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:43:10 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:43:10 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:43:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:43:25 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:43:25 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:44:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:44:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:44:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:44:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:44:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:44:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:44:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:44:14 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:44:14 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 20:45:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:45:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:45:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:45:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 20:45:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 20:45:31 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 20:45:31 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 22:07:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 22:07:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 22:08:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 22:08:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 22:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 22:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-13 22:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:08:06 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-10-13 22:08:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:08:47 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-10-13 22:09:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:09:09 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Error - 2013-10-13 22:09:09 --> 8 - Undefined variable: view in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Error - 2013-10-13 22:09:09 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 22:09:09 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 22:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 22:10:09 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 22:11:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 36
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 22:11:15 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 22:12:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:12:16 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Error - 2013-10-13 22:12:16 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 22:12:16 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 22:12:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:12:45 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 22:12:45 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-13 22:34:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-13 22:34:35 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-13 22:34:35 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
