<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-05-10 11:02:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:02:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:02:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:02:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:02:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:02:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:02:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:11:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:12:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:12:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:50 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:12:50 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:12:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:12:56 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:12:56 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:13:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:13:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:13:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:13:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:13:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:13:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:13:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:14:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:14:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:21 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:14:21 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:14:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:14:34 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:14:34 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:15:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:15:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:15:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:15:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:16:42 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:42 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:16:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:17:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:17:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:17:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:27:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:27:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:42 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:33:42 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:33:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:33:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:04 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:34:04 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:34:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:35:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:35:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:36:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:36:53 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:36:53 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:37:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:37:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:37:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:37:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:37:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:37:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:37:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:38:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:38:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:39 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:38:39 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:38:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:38:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:39:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 11:39:30 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 11:39:30 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 11:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:30 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 11:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:39:54 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 11:40:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:40:52 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 11:41:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:41:00 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 11:41:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:41:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:41:28 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 11:41:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:41:44 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 11:41:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:42:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:42:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:42:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:42:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:42:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:31 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:43:31 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:43:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:43:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:44:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:44:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:44:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:44:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:45:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:45:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:45:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:45:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:45:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:45:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:45:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:48:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:48:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:49:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:51:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:51:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:51:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:52:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:52:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:52:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:53:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:59:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:59:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:59:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:59:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 11:59:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 11:59:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:00:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:00:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:00:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:00:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:00:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:00:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:01:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:01:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:01:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:02:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:02:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:02:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:02:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:03:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:04:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:04:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:04:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:04:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:04:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:04:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:05:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:05:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 12:05:27 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 12:05:27 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 12:05:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:27 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 12:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:05:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:05:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:05:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:06:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:06:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:06:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:06:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:06:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:16:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 12:16:52 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 12:16:52 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 12:16:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:16:52 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 12:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:17:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:17:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:33 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 12:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:18:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:18:51 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:18:51 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:19:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:19:50 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:19:50 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:20:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:20:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:20:12 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:20:12 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:20:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:20:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:20:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:20:30 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:20:30 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 12:20:36 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 12:20:36 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 12:20:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:20:36 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 12:20:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:21:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:21:54 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 12:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:21:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:21:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 12:22:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 12:22:06 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 12:22:06 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 12:22:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 12:22:06 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:20:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:37 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:20:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-05-10 14:20:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-05-10 14:20:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:20:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-05-10 14:20:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-05-10 14:22:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:22:18 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:22:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:22:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:22:44 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:23:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:23:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:23:25 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:25:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:25:06 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:25:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:25:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:25:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:25:47 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:26:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:10 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:26:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:26:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:26:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:27:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 14:27:06 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 14:27:06 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 14:27:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:27:06 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:27:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:27:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:27:30 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:27:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:27:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:27:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:27:39 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:27:39 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:30:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:30:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:30:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:30:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:30:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:30:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 14:30:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 14:30:50 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 14:30:50 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 14:30:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 14:30:50 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 14:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:29:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:29:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:29:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:29:09 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 16:34:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:35:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:35:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:07 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 16:56:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:32 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:32 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 16:56:38 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 16:56:38 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:01:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:01:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:01:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:01:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:01:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:14 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:14 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 17:02:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 17:02:42 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 17:02:42 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 17:02:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:02:42 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 17:03:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:03:37 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 17:04:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:04:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:04:12 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 17:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 17:05:41 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:20:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:14 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:20:14 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:20:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:20:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:20:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:20:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 20:20:35 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 20:20:35 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 20:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:20:35 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:20:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:21:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:21:05 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:21:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:36:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:36:29 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:36:42 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:38:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:38:07 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:44:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:44:54 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:45:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:45:36 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:45:51 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:45:51 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 20:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 20:46:00 --> 8 - Undefined variable: current_user in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 20:46:00 --> 8 - Trying to get property of non-object in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 20:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:46:00 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 20:46:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-05-10 20:51:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-05-10 20:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:51:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-05-10 20:51:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-05-10 20:53:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:53:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 20:53:22 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 21:22:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 21:22:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 21:22:10 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:22:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:22:47 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:24:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:24:03 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:24:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:24:52 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:25:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:26:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:26:42 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:26:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:26:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:27:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:27:11 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:29:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:29:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:29:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:29:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:29:56 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:30:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-05-10 22:30:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-05-10 22:30:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-05-10 22:30:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-05-10 22:30:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:23 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:30:33 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:30:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:31:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:08 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:45:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:15 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 22:45:15 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-10 22:45:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-10 22:45:22 --> 8 - Undefined variable: current_user in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-10 22:45:22 --> 8 - Trying to get property of non-object in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-10 22:45:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:22 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-10 22:45:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-10 22:45:54 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
