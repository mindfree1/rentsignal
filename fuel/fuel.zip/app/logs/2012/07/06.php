<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-07-06 00:04:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-07-06 00:05:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-07-06 00:05:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-07-06 00:07:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-07-06 00:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-07-06 00:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-07-06 00:12:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
