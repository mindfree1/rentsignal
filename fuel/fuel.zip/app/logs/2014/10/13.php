<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-10-13 00:01:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:01:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:01:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:01:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:01:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:02:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:02:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:02:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:15:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:15:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:15:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:17:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:17:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:17:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:17:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:17:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:17:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:17:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:17:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:17:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:18:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:18:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:18:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:18:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:18:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 00:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 00:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 00:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 13:48:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 13:48:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 13:48:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 13:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 13:51:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 13:56:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:08:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:12:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:12:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:13:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:13:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:14:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:14:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:14:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:14:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:14:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:14:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:14:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:14:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:15:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:15:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:15:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:15:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:15:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:15:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:15:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:15:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:15:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:15:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:15:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:15:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:15:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:15:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:17:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:17:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:17:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:17:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:17:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:23:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:23:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:23:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-10-13 14:23:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-10-13 14:23:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:23:32 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-10-13 14:23:32 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-10-13 14:23:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:23:32 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-13 14:23:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:23:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:24:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:24:12 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:24:44 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Error - 2014-10-13 14:24:44 --> Error - Property "title" not found for Model_Rentsignals. in C:\wamp\fuel\packages\orm\classes\model.php on line 865
Warning - 2014-10-13 14:28:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:28:58 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:29:16 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:29:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:29:24 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:29:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:29:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:29:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:29:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:29:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:29:31 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-13 14:29:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:29:38 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:29:52 --> Parsing Error - syntax error, unexpected T_ENDIF in C:\wamp\fuel\app\views\template.php on line 68
Warning - 2014-10-13 14:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:30:18 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:30:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:30:54 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 55
Error - 2014-10-13 14:30:54 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\views\template.php on line 55
Warning - 2014-10-13 14:31:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:31:56 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\fuel\app\views\template.php on line 55
Warning - 2014-10-13 14:32:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:32:14 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\fuel\app\views\template.php on line 55
Warning - 2014-10-13 14:32:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:33:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:33:32 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:34:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:39:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:39:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:39:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:39:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:39:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:39:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:39:06 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-13 14:40:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:40:34 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-13 14:41:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:41:58 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:46:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:46:30 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:46:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:46:33 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:46:36 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:48:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:48:11 --> Error - The requested view could not be found: template in C:\wamp\fuel\core\classes\view.php on line 389
Warning - 2014-10-13 14:51:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:51:56 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:54:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:54:05 --> Error - Using $this when not in object context in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:54:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:54:18 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:54:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 14:54:29 --> 8 - Undefined variable: template in C:\wamp\fuel\app\views\template.php on line 32
Error - 2014-10-13 14:54:29 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\views\template.php on line 32
Error - 2014-10-13 14:54:29 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\views\template.php on line 32
Warning - 2014-10-13 14:56:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:56:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:56:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:56:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:57:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:57:00 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-13 14:57:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:57:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:57:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 14:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 14:57:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 14:57:08 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-13 14:57:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:14:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:15:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:17:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:17:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:17:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:17:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:17:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:18:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:18:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:18:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:18:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:18:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:18:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:18:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:18:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:18:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:18:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:56:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:57:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:57:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:57:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:57:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:57:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:57:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:57:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:58:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:58:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:58:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:58:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:58:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:58:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:58:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:58:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:58:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:58:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:58:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:58:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:58:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:59:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:59:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:59:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:59:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:59:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 15:59:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 15:59:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 15:59:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:00:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:00:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:00:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:00:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:00:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:00:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:00:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:00:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:00:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:05:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:05:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:05:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:05:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:05:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:05:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:06:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:06:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:06:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:06:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:06:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:06:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:06:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:07:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:07:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:07:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:07:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:07:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:07:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:07:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:08:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:08:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:08:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:08:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:08:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:08:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:08:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:09:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:09:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:09:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:09:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:10:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:10:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:10:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:10:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:10:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:10:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:10:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:10:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:10:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:10:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:10:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:12:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:12:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:12:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:12:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:12:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:12:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:12:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:12:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:12:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:12:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:13:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:13:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:13:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:13:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:13:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 16:13:21 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2014-10-13 16:13:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:13:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:13:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:13:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:13:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:13:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:14:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 16:14:11 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2014-10-13 16:14:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:14:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:21:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:21:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:21:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:21:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:21:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:21:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:21:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:22:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:22:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:22:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:22:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:22:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:22:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:22:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:22:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:23:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:23:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:23:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:23:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:23:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:23:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:23:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:23:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 16:23:33 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 44
Warning - 2014-10-13 16:23:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:23:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:27:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:27:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:27:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:27:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:27:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:27:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:27:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:27:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:29:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:29:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:29:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:29:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:29:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 16:29:43 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '|rozelle|mascot||mascot|mascot|mascot|glebe|glebe|glebe|glebe|glebe' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-13 16:29:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:29:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:29:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:29:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:30:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:30:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:30:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:30:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:30:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:30:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 16:30:02 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '|rozelle|mascot||mascot|mascot|mascot|glebe|glebe|glebe|glebe|glebe' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-13 16:31:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:31:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:31:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:31:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:31:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:32:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:32:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-13 16:32:05 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '|rozelle|mascot||mascot|mascot|mascot|glebe|glebe|glebe|glebe|glebe' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-10-13 16:35:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:35:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:35:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:35:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:35:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:35:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:36:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:36:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:37:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:37:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:38:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:38:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:38:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:38:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:38:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:38:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:38:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:38:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:38:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:40:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:40:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:40:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:40:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:40:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:40:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:40:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:41:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:41:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:41:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-13 16:41:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-13 16:41:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-13 16:41:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
