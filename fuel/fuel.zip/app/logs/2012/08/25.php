<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-25 15:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 15:40:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 15:40:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 15:40:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 15:41:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 15:41:17 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-25 15:41:17 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 15:41:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 15:41:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 15:41:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 15:41:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 15:41:38 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 15:41:38 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 15:41:38 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 15:41:38 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 15:41:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 15:41:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 15:41:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 15:41:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 15:41:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:00:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:00:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:00:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:01:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:01:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:01:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:01:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:01:28 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 47
Error - 2012-08-25 16:01:28 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 47
Warning - 2012-08-25 16:01:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:01:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:02:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:02:42 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:02:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:02:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:02:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:02:53 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:02:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:02:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:03:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:03:03 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:03:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:03:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:03:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:03:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:03:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:07:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:07:07 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:07 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:07 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:07 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:07 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:07:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:07:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:07:25 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:25 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:25 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:25 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:25 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:07:25 --> 8 - Undefined offset: 13 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:07:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:07:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:08:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:08:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:08:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:08:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:09:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:09:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:09:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:10:06 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:10:06 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:10:06 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:10:06 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:10:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:10:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:10:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:10:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:10:12 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:10:12 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:10:12 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:10:12 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:10:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:10:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:11:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:11:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:11:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:12:06 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:06 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:06 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:06 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:12:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:12:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:12:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 40
Warning - 2012-08-25 16:12:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:12:14 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:14 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:14 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:14 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:12:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:12:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:12:21 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:21 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:21 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:12:21 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:12:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:12:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:12:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:21:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:21:08 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Warning - 2012-08-25 16:21:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:21:17 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Warning - 2012-08-25 16:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:21:19 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Warning - 2012-08-25 16:21:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:21:29 --> Parsing Error - syntax error, unexpected T_ECHO, expecting ',' or ';' in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Warning - 2012-08-25 16:21:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:21:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:21:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:22:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:22:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:22:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:33:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:33:34 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$max' at line 1 with query: "SELECT * FROM `images` order by id $max" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:33:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:33:55 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'limit 0,8' at line 1 with query: "SELECT * FROM `images` order by limit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:34:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:34:39 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'limit 0,8' at line 1 with query: "SELECT * FROM `images` order by limit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:34:40 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'limit 0,8' at line 1 with query: "SELECT * FROM `images` order by limit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:35:33 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0,8' at line 1 with query: "SELECT * FROM `images` order by idlimit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:35:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:35:52 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:35:52 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:35:52 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:35:52 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:35:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:35:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:36:40 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:36:40 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:36:40 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:36:40 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:36:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:36:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:36:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:36:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:36:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:38:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:38:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:38:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:38:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:38:32 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:38:32 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:38:32 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:38:32 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:38:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:38:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:38:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:38:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:38:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:39:52 --> Parsing Error - syntax error, unexpected ';', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\views\listings\listings.php on line 47
Warning - 2012-08-25 16:40:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:40:03 --> Parsing Error - syntax error, unexpected ';', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\views\listings\listings.php on line 47
Warning - 2012-08-25 16:40:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:40:04 --> Parsing Error - syntax error, unexpected ';', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\views\listings\listings.php on line 47
Warning - 2012-08-25 16:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:40:26 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:41:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:41:39 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:39 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:39 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:39 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:39 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:41:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:41:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:41:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:41:55 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:41:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:41:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:43:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:43:06 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:43:06 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:43:06 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:43:06 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-25 16:43:06 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:43:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:43:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:43:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:43:11 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-25 16:43:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:43:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:43:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:43:43 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:43:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:43:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:44:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:44:18 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:44:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:44:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:44:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:44:24 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:44:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:44:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:44:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:44:26 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:44:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:44:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:44:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:44:29 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:44:35 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:44:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:44:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2012-08-25 16:44:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:44:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:45:34 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2012-08-25 16:45:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:45:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:45:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:45:40 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:45:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:45:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:45:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:45:56 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:45:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:45:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:46:12 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:12 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:12 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:12 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:12 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:12 --> 8 - Undefined offset: 13 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:46:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:46:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:46:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:46:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:46:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:46:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:46:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:46:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:46:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:46:47 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:47 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:47 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:46:47 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:46:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:46:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:46:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:46:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:46:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:47:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:47:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:47:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:47:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:47:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:47:16 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:47:16 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:47:16 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:47:16 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:47:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:47:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:47:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:47:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:48:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:48:00 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 48
Error - 2012-08-25 16:48:00 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:48:00 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:48:00 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:48:00 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-25 16:48:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:48:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:48:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:48:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:48:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:48:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:48:04 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:48:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:48:04 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 16:48:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:48:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:48:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:48:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:50:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:50:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:50:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:50:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:50:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-25 16:50:27 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-25 16:50:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:50:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:52:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:52:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:52:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:52:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:52:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:52:42 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Error - 2012-08-25 16:52:42 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Error - 2012-08-25 16:52:42 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Error - 2012-08-25 16:52:42 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-25 16:52:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:52:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:52:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:52:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:52:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:52:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:53:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:53:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:53:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:53:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:53:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:55:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:55:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:55:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:55:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:55:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:55:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:55:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:55:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:55:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:55:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:55:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:55:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:57:31 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Error - 2012-08-25 16:57:31 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-25 16:57:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:57:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:58:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:58:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:58:05 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Error - 2012-08-25 16:58:05 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-25 16:58:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:58:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:59:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:59:31 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Warning - 2012-08-25 16:59:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:59:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 16:59:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 16:59:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 16:59:55 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Error - 2012-08-25 16:59:55 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-25 16:59:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 16:59:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:00:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:00:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 17:00:06 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
Warning - 2012-08-25 17:00:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:00:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:00:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:00:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:00:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:00:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:01:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:01:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:01:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:01:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:01:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 17:01:27 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-25 17:01:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:01:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:01:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:01:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:01:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:01:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:01:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:01:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:01:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:02:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:02:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:02:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:02:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:02:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:02:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:02:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:02:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:02:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:02:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:02:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:02:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:02:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:11:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:11:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:11:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:27:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:27:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:27:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:27:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:27:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:27:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:27:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:27:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:27:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:27:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-25 17:27:34 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-25 17:27:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:27:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:27:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:27:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:27:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:27:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-25 17:27:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-25 17:27:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-25 17:27:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
