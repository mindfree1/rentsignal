<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-07-21 12:20:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:20:16 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\profiler.php on line 3
Warning - 2013-07-21 12:20:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:21:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:21:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:21:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:21:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:21:34 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:21:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:21:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:22:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:22:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:22:59 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:22:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:22:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:23:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:23:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:23:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:23:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:23:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:23:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:23:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:23:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:23:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:23:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:23:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:23:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:24:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:24:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:24:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:24:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:25:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:25:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:25:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:25:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:25:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:31:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:31:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:35:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:35:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:35:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:39:37 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:39:37 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Error - 2013-07-21 12:39:37 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 39
Error - 2013-07-21 12:39:37 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
Warning - 2013-07-21 12:39:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:39:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:40:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:40:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:40:37 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:40:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:40:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:40:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:40:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:40:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:40:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:40:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:41:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:41:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:41:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:41:57 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:41:57 --> 8 - Array to string conversion in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:41:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:41:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:42:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:42:07 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:42:07 --> 8 - Array to string conversion in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:42:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:42:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:43:17 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:43:17 --> 8 - Array to string conversion in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:43:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:43:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:45:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:45:21 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:45:21 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:45:21 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe","mascot","rozelle"]"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="["glebe","mascot","rozelle"]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:45:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:45:55 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:45:55 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:45:55 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe"]"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="["glebe"]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:46:47 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:46:47 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:46:48 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe"]"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="["glebe"]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:47:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:47:32 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:47:32 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:47:32 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe"]"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="["glebe"]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:48:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:48:03 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2013-07-21 12:48:03 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
Warning - 2013-07-21 12:48:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:48:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:48:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:48:41 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Warning - 2013-07-21 12:48:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:48:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:49:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:49:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:49:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:50:00 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-07-21 12:50:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:50:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:50:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:50:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:50:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:50:06 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:50:06 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'mascot","rozelle"]"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="["mascot","rozelle"]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:51:00 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:51:00 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'mascot","rozelle"]"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="["mascot","rozelle"]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:51:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:51:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 12:51:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 12:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:53:00 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Array' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=Array" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:54:04 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Array' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=Array" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:54:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:54:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:54:16 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-21 12:54:16 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:54:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:54:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 12:54:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:54:27 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Array' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=Array" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:54:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:54:48 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Array' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=Array" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:55:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:55:00 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Array' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=Array" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 12:55:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 12:55:29 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'Array' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=Array" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:00:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:00:36 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'rozelle' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=mascot,rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:01:10 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'mascot' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=mascot OR rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:01:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:01:34 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKEmascot OR rozelle' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location LIKEmascot OR rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:01:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:01:46 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'mascot' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location LIKE mascot OR rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:02:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:02:28 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'mascot' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location LIKE mascot" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:03:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:03:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:03:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:03:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:03:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:03:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:04:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:04:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:04:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:04:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:04:45 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Error - 2013-07-21 13:04:45 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-07-21 13:04:45 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-07-21 13:04:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:04:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:05:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:08:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:08:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:08:26 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-07-21 13:08:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:08:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:08:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:08:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:08:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:08:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:08:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:08:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:08:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:08:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:09:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:09:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:09:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:09:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:09:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:09:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:09:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:09:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:11:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:11:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:11:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:12:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:12:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:12:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:13:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:13:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:13:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:14:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:14:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:17:40 --> Parsing Error - syntax error, unexpected T_AS in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-07-21 13:18:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:18:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:18:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:19:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:19:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:19:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:19:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:19:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:20:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:20:50 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-07-21 13:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:21:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:21:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:22:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:22:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:22:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:22:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:22:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:22:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:22:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:22:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:22:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:23:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:23:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:23:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:23:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:23:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:23:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:24:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:24:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:24:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:24:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:24:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:24:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:26:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:26:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:26:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:34:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:34:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:34:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:34:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:35:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:35:17 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''OR rozelle'' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location= 'glebe 'OR mascot 'OR rozelle'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:35:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:35:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:35:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:36:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:36:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:36:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:38:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:38:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:38:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:39:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:39:28 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'location= OR 'mascot' location= OR 'rozelle'' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location= 'glebe' location= OR 'mascot' location= OR 'rozelle'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:39:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:39:59 --> Error - SQLSTATE[23000]: Integrity constraint violation: 1052 Column 'location' in where clause is ambiguous with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location= 'glebe' OR location= 'mascot' OR location= 'rozelle'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:40:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:40:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:40:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:41:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:41:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:41:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:41:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:41:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:41:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:46:37 --> Parsing Error - syntax error, unexpected T_STRING, expecting ',' or ';' in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2013-07-21 13:47:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:47:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:47:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:47:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:47:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:47:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:48:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:48:50 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' OR 'rozelle' at line 1 with query: "SELECT * FROM `images` WHERE location LIKE mascot' OR 'rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:49:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:49:27 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''rozelle' at line 1 with query: "SELECT * FROM `images` WHERE location LIKE 'mascot' OR 'rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:49:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 13:49:27 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''rozelle' at line 1 with query: "SELECT * FROM `images` WHERE location LIKE 'mascot' OR 'rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 13:50:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:50:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:50:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:56:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:56:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 13:57:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 13:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 13:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:02:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:02:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:02:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:04:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:04:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:04:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:07:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:07:22 --> Parsing Error - syntax error, unexpected '(', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
Warning - 2013-07-21 14:07:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:07:53 --> Parsing Error - syntax error, unexpected '(', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
Warning - 2013-07-21 14:08:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:08:13 --> Parsing Error - syntax error, unexpected '(', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
Warning - 2013-07-21 14:09:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:09:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:09:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:09:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:09:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:09:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:10:30 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-07-21 14:10:30 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 14:10:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:10:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:10:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:11:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:11:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:12:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:12:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:12:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:12:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:12:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:12:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:13:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:13:38 --> 8 - Undefined variable: results in C:\wamp\fuel\app\classes\model\showlistings.php on line 66
Warning - 2013-07-21 14:13:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:13:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:13:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:13:57 --> 8 - Undefined variable: results in C:\wamp\fuel\app\classes\model\showlistings.php on line 66
Warning - 2013-07-21 14:13:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:13:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:14:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:14:17 --> 8 - Undefined variable: results in C:\wamp\fuel\app\classes\model\showlistings.php on line 66
Warning - 2013-07-21 14:14:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:14:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:14:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:14:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:14:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:15:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:15:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:15:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:15:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:15:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:16:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:16:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:16:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:16:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:16:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:16:51 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-07-21 14:16:51 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 14:16:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:16:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:16:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-21 14:17:20 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-07-21 14:17:20 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-21 14:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:17:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:17:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:17:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:19:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:19:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:19:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:19:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:19:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:19:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:20:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:20:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:20:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:20:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:20:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-21 14:20:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-21 14:20:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-21 14:20:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
