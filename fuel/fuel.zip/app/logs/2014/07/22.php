<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-07-22 21:20:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:20:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:20:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-22 21:29:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-22 21:29:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:29:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-22 21:29:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-22 21:33:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:43:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:43:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:43:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-22 21:43:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-22 21:43:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:43:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-22 21:43:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-22 21:44:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:44:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:45:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:45:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:46:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:48:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:50:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:51:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 21:56:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:03:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:11:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:11:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:13:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:13:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:16:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:16:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:17:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:28:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-22 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-22 22:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-22 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-22 22:42:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:43:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:44:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:45:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:45:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:47:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:50:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:50:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:50:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:51:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:52:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 22:56:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:02:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:02:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:37:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:38:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:38:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:38:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:39:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:39:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:43:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:45:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:45:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:47:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:47:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:47:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:47:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:50:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:52:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:54:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:54:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:54:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-22 23:55:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
