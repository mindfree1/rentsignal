<?php
return array(
	'crypto_key' => 'tdce10FtAG-0oJko-QVtE2ig',
	'crypto_iv' => 'ergtOIO3YeoYDeYGo4CEkR2k',
	'crypto_hmac' => 'oxw2R0FngBxM_LYLHA4t02eE',
);
