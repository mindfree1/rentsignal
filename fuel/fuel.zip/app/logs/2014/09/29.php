<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-09-29 19:27:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 19:27:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 19:27:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 19:27:52 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:27:52 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:27:52 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 19:27:52 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:27:52 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:27:52 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 19:28:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 19:28:14 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:28:14 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:28:14 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 19:28:14 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:28:14 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:28:14 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 19:29:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 19:29:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 19:29:35 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:29:35 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:29:35 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 19:29:35 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:29:35 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:29:35 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 19:29:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 19:29:52 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:29:52 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 19:29:52 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 19:29:52 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:29:52 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 19:29:52 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 19:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:24:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:24:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 20:24:35 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:24:35 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:24:35 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 20:24:35 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:24:35 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:24:35 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 20:24:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 20:24:42 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:24:42 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:24:42 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 20:24:42 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:24:42 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:24:42 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 20:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:38:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:38:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:38:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 20:38:31 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:38:31 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:38:31 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 20:38:31 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:38:31 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:38:31 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 20:38:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:39:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 20:39:06 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:39:06 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:39:06 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 20:39:06 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:39:06 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:39:06 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 20:49:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:49:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-09-29 20:49:04 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:49:04 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-09-29 20:49:04 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-09-29 20:49:04 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:49:04 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-09-29 20:49:04 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-09-29 20:49:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:49:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:49:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 20:49:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 20:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:50:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 20:50:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 20:50:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:50:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:52:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:52:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:52:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 20:52:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 20:52:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:55:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:55:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:55:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 20:55:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 20:55:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:55:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 20:55:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 20:56:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:56:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 20:56:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 20:56:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:05:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:05:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:05:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:05:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:06:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:06:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:06:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:06:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:07:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:07:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:07:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:07:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:07:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:07:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:09:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:09:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:09:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:09:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:09:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:09:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:09:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:19:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:19:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:21:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:21:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:22:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:22:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:22:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:22:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:22:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:22:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:22:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:22:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:23:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:23:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:23:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:23:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:25:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:25:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:25:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:25:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:25:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:25:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:36:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:36:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:36:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:36:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:40:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:40:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:40:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:40:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:40:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:40:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:40:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:40:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:41:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:41:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:41:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:41:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:42:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:42:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:42:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:42:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:44:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:44:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:46:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:46:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:46:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:46:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:50:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:50:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:50:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:50:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:50:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:50:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:50:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:50:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:50:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:50:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:50:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:50:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-09-29 21:51:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:51:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-29 21:51:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-09-29 21:51:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
