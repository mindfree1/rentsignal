<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-08-26 00:59:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 00:59:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 00:59:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 00:59:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 00:59:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 00:59:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 01:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 01:00:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 01:00:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 01:00:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 01:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:00:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 01:00:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 01:01:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 01:01:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 01:01:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-08-26 01:01:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-08-26 01:01:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 01:01:37 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-08-26 01:01:37 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-08-26 01:01:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:37 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-08-26 01:01:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 01:01:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 01:01:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:26:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 20:26:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:26:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 20:26:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:26:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:26:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 20:26:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:29:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:29:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 20:29:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:29:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:29:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 20:29:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:30:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:30:31 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-08-26 20:30:31 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-08-26 20:30:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:30:39 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-08-26 20:30:39 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-08-26 20:30:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:30:39 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-08-26 20:30:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:32:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:32:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:32:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-08-26 20:32:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-08-26 20:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:43:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:43:40 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:43:40 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:43:40 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:43:40 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:43:40 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:43:40 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:43:40 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-08-26 20:43:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:43:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:43:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:43:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:43:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:43:47 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:43:47 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:43:47 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:43:47 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:43:47 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:43:47 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:43:47 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-08-26 20:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:44:06 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:44:06 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:44:06 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:44:06 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:44:06 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:44:06 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:44:06 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-08-26 20:51:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:51:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:51:08 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:08 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:08 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:08 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:51:08 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:51:08 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:51:08 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-08-26 20:51:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:51:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:51:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:51:16 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:16 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:16 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:16 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:51:16 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:51:16 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:51:16 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-08-26 20:51:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:51:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:51:28 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:28 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:28 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:51:28 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:51:28 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:51:28 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:51:28 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-08-26 20:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-26 20:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-08-26 20:52:05 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:52:05 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: No such host is kn (trying to connect via tcp://https:3306) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:52:05 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-08-26 20:52:05 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-08-26 20:52:05 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:52:05 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-08-26 20:52:05 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
