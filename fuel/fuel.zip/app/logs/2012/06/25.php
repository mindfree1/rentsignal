<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-06-25 19:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:16:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:16:26 --> Error - Call to undefined function domxml_new_doc() in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-25 20:19:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:28:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:29:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:29:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:30:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:30:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:31:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:31:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:35:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:35:58 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Warning - 2012-06-25 20:36:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:36:10 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 20:36:10 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 20:36:10 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 20:36:10 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Warning - 2012-06-25 20:36:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:37:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:39:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:40:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:41:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:41:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:41:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:44:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:44:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:45:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:46:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:46:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:47:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:47:14 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-25 20:47:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:47:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:48:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:48:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:48:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:48:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:48:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:49:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:51:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:51:01 --> 8 - Undefined variable: allcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-25 20:53:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:54:04 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-25 20:54:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:54:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:54:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 20:54:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:54:55 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Error - 2012-06-25 20:54:56 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Error - 2012-06-25 20:55:00 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Error - 2012-06-25 20:55:05 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Warning - 2012-06-25 20:55:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:55:43 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 34
Warning - 2012-06-25 20:56:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: name in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: address in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: lat in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: type in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: name in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: address in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: lat in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: lng in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: type in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:08 --> 8 - Undefined index: name in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-06-25 20:56:38 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-06-25 21:01:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:01:08 --> Error - Call to undefined function eader() in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Warning - 2012-06-25 21:01:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 22
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 23
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 24
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 25
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 22
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 23
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 24
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 25
Error - 2012-06-25 21:07:25 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:07:55 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\core\classes\fuel.php on line 613
Warning - 2012-06-25 21:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 22
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 23
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 24
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 25
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 22
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 23
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 24
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 25
Error - 2012-06-25 21:08:04 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:08:34 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\core\classes\arr.php on line 60
Warning - 2012-06-25 21:09:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 22
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 23
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 24
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 25
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 22
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 23
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 24
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 25
Error - 2012-06-25 21:09:43 --> 8 - Undefined variable: rows in C:\wamp\www\rentsignal\fuel\app\views\mapgen\mapxml.php on line 21
Error - 2012-06-25 21:10:13 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\rentsignal\fuel\core\classes\arr.php on line 62
Warning - 2012-06-25 21:12:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:12:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:13:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:13:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:13:25 --> 8 - Undefined variable: item in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-25 21:13:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:13:38 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-25 21:13:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:14:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:14:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:14:49 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-25 21:14:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:14:53 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-25 21:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:16:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:16:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:16:56 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 21:16:56 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 21:16:56 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 21:16:56 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Warning - 2012-06-25 21:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:17:03 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 21:17:03 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 21:17:03 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Error - 2012-06-25 21:17:03 --> 8 - Undefined index: markers in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 22
Warning - 2012-06-25 21:17:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:18:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:18:27 --> 8 - Undefined variable: allcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Warning - 2012-06-25 21:18:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:18:40 --> 8 - Undefined variable: allcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Warning - 2012-06-25 21:19:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:22:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:22:18 --> Parsing Error - syntax error, unexpected T_ARRAY in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:22:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:22:35 --> Parsing Error - syntax error, unexpected T_VARIABLE, expecting '(' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:22:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:22:48 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:23:09 --> Parsing Error - syntax error, unexpected T_VARIABLE, expecting '(' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:23:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:23:17 --> Parsing Error - syntax error, unexpected T_VARIABLE, expecting '(' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:23:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:23:36 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:23:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:23:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:24:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:25:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:25:33 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Error - 2012-06-25 21:25:33 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Error - 2012-06-25 21:25:33 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Error - 2012-06-25 21:25:33 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:25:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:25:43 --> 8 - Undefined index: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Error - 2012-06-25 21:25:43 --> 8 - Undefined index: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Error - 2012-06-25 21:25:43 --> 8 - Undefined index: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Error - 2012-06-25 21:25:43 --> 8 - Undefined index: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-25 21:25:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:26:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:26:50 --> Parsing Error - syntax error, unexpected '.' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-25 21:27:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:01 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-25 21:27:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:27:11 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:11 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:11 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-25 21:27:11 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-25 21:27:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:28:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:29:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:29:19 --> Error - Cannot use string offset as an array in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-25 21:29:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:29:43 --> 8 - Use of undefined constant name - assumed 'name' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-25 21:30:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:38:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:38:12 --> 8 - Undefined variable: allcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-25 21:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:41:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:41:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:46:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:47:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:48:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:48:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:50:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:50:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:51:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:51:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:51:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:56:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:57:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 21:57:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 21:57:15 --> 8 - Undefined offset: 4 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 29
Warning - 2012-06-25 22:01:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:01:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:02:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:03:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:03:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:03:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:09:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:09:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:09:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:17:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 22:18:41 --> Compile Error - Cannot use [] for reading in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 31
Warning - 2012-06-25 22:18:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:19:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:26:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:26:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:27:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-25 22:27:34 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 32
Warning - 2012-06-25 22:28:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:28:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:29:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:29:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:30:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:30:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:31:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:32:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:33:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:33:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:34:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:35:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:42:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:47:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:48:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:49:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:49:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:49:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:49:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:50:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:50:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:50:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:51:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:52:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-25 22:53:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
