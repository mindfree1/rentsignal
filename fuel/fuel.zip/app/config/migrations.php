<?php
return array(
	'version' => 
	array(
		'app' => 
		array(
			'default' => 6,
		),
		'module' => 
		array(
		),
		'package' => 
		array(
		),
	),
	'folder' => 'migrations/',
	'table' => 'migration',
);
