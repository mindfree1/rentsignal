<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-23 00:00:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:00:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:00:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:00:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:00:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:00:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:00:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:00:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:00:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:02:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:02:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:02:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:04:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:05:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:05:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:05:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:05:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:05:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:05:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:06:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2012-08-23 00:06:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\views\listings\listings.php on line 26
Warning - 2012-08-23 00:06:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:06:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:06:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:06:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:06:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:06:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:07:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:07:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:07:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:07:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:07:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:07:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:07:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:07:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:08:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:08:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 00:08:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 00:08:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 00:08:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 20:30:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 20:53:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 20:53:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 20:53:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 20:53:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 5
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:35:39 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2012-08-23 22:39:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:40:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:40:18 --> Error - Class 'Model\Response' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Warning - 2012-08-23 22:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:40:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:40:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:40:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:40:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:40:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:40:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:40:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:40:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:41:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:41:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:41:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:41:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:42:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 5
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2012-08-23 22:42:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2012-08-23 22:45:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:45:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 22:45:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:45:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:45:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:46:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:46:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:46:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:46:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:46:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:46:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:46:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:46:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:46:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:46:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:46:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:46:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:46:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:46:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:46:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:47:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:47:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:47:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:47:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:47:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:47:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:47:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:47:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:47:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:48:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:48:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:48:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:48:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:48:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:48:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:48:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:48:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:49:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:49:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:49:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:49:32 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 22:50:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:50:00 --> Error - Call to undefined function forge() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 10
Warning - 2012-08-23 22:50:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:50:13 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 22:50:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:50:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:50:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:51:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:51:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:51:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:51:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:51:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:51:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:51:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:51:20 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 22:51:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:51:53 --> 8 - Undefined variable: results in C:\wamp\fuel\app\views\listings\listings.php on line 2
Warning - 2012-08-23 22:52:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:52:38 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 22:52:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 22:52:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 22:52:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 22:54:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:54:10 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 22:55:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:55:59 --> Error - Class 'Model_ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:56:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:56:14 --> Error - Class 'Model_ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:56:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:56:15 --> Error - Class 'Model_ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:56:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:56:23 --> Error - Class 'Model_ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:56:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:56:24 --> Error - Class 'Model_ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:58:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:58:24 --> Error - Class 'ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:58:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:58:25 --> Error - Class 'ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:58:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:58:33 --> Error - Class 'ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:58:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:58:33 --> Error - Class 'ShowListings' not found in C:\wamp\fuel\app\views\welcome\index.php on line 10
Warning - 2012-08-23 22:58:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2012-08-23 22:58:44 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-23 23:06:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:06:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:06:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:07:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:07:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:07:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:07:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:07:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:07:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:08:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:08:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:08:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:09:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:09:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:09:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:09:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:09:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:09:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:13:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:13:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
Error - 2012-08-23 23:13:42 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:14:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:14:13 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 24
Warning - 2012-08-23 23:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:15:03 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
Error - 2012-08-23 23:15:03 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` limit-8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:18:16 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
Error - 2012-08-23 23:18:16 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= $start,$per_page' at line 1 with query: "SELECT * FROM `images` limit = $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:19:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:19:17 --> Parsing Error - syntax error, unexpected ',' in C:\wamp\fuel\app\classes\model\showlistings.php on line 24
Warning - 2012-08-23 23:19:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:19:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
Error - 2012-08-23 23:19:42 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '=-8' at line 1 with query: "SELECT * FROM `images` limit =-8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:19:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:19:54 --> Parsing Error - syntax error, unexpected ',' in C:\wamp\fuel\app\classes\model\showlistings.php on line 24
Warning - 2012-08-23 23:20:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:20:17 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
Error - 2012-08-23 23:20:17 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:17 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:17 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:17 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:17 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:17 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Warning - 2012-08-23 23:20:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:20:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:20:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:20:36 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:36 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:36 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:36 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:36 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2012-08-23 23:20:36 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Warning - 2012-08-23 23:20:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:20:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:20:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:20:50 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 with query: "SELECT * FROM `images` limit 3," in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:20:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:20:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:20:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:21:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:21:28 --> Parsing Error - syntax error, unexpected T_LNUMBER in C:\wamp\fuel\app\classes\model\showlistings.php on line 24
Warning - 2012-08-23 23:21:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:21:43 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,12" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:22:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:22:03 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 24
Warning - 2012-08-23 23:22:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:22:52 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '12' at line 1 with query: "SELECT * FROM `images` limit3,12" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:23:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:23:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:23:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:23:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:23:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 37
Warning - 2012-08-23 23:23:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:23:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:24:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:24:18 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 37
Warning - 2012-08-23 23:24:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:24:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:24:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 37
Warning - 2012-08-23 23:24:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:24:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:24:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:24:53 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 37
Warning - 2012-08-23 23:24:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:24:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:25:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:25:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:25:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:25:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:25:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:28:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:28:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:28:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:28:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:28:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:28:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:36:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:36:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:36:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:36:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:36:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:36:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:36:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:36:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:36:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:36:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:36:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:36:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:37:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:37:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:37:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:37:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:37:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:37:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:37:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:38:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:38:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:41:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:41:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:41:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:41:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:41:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:41:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:41:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:41:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:41:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:41:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:42:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:42:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:42:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:42:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:42:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:42:30 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:42:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:42:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:46:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:46:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:46:05 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:46:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:46:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:46:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:46:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:46:44 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:46:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:46:48 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-23 23:46:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:46:49 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:46:52 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:47:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:47:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:47:02 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:47:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:47:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:47:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:47:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:47:32 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-23 23:47:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:47:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:47:39 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:47:49 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-23 23:47:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:47:56 --> Compile Error - Cannot use [] for reading in C:\wamp\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-23 23:48:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:48:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:48:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:48:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:48:25 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:48:25 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:48:25 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:48:25 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:48:25 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-23 23:48:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:48:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:49:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:49:20 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:49:20 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:49:20 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:49:20 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:49:20 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:49:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:49:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:50:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:50:17 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:17 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:17 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:17 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:17 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:50:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:50:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:50:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:50:19 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:19 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:19 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:19 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:19 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:50:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:50:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:50:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:50:58 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:58 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:58 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:58 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:50:58 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:51:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:51:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:51:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:51:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:51:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:51:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:52:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:52:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:52:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:53:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:53:33 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:53:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:53:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:55:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:55:14 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:55:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:55:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:55:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:55:30 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:55:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:55:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:55:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:55:37 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:55:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:55:45 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:55:45 --> 8 - Undefined offset: 13 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:55:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:55:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:57:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:57:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:57:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:57:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:57:45 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:57:47 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:57:47 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\app\views\listings\listings.php on line 50
Error - 2012-08-23 23:57:47 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-23 23:57:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 13 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 14 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 15 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 16 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 17 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:57:56 --> 8 - Undefined offset: 18 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:58:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-23 23:58:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 13 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 14 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 15 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 16 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 17 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:04 --> 8 - Undefined offset: 18 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:58:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 12 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 13 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 14 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 15 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 16 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 17 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:12 --> 8 - Undefined offset: 18 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-23 23:58:26 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\arr.php on line 62
Error - 2012-08-23 23:58:34 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\arr.php on line 36
Error - 2012-08-23 23:58:42 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\arr.php on line 60
Warning - 2012-08-23 23:59:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:59:22 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-23 23:59:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:59:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-23 23:59:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-23 23:59:51 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 39
Warning - 2012-08-23 23:59:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-23 23:59:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
