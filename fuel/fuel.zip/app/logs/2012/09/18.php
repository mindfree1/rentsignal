<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-09-18 18:45:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 18:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 18:46:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 18:46:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 18:46:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 18:57:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 18:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 18:57:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 18:57:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 18:57:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 18:57:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:06:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:06:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:06:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:06:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:06:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:07:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:07:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:07:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:07:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:07:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:07:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:07:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:07:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:08:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:11:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:11:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:11:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:11:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:11:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:12:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:12:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:12:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:12:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:12:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:13:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:13:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:13:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:13:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:13:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:14:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:14:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:15:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:15:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:15:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:15:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:15:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:15:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:15:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:15:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:15:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:20:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:20:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:20:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:20:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:21:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:21:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:22:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:22:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:22:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:22:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:22:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:22:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:22:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:22:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:22:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:23:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:23:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:23:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:23:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:23:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:23:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:23:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:23:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:23:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:24:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:24:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:24:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:25:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:25:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:25:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:25:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:25:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 19:25:51 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 29
Warning - 2012-09-18 19:25:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:25:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:25:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:25:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:26:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:26:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:26:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:26:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:26:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:26:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:26:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:26:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:26:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:26:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:27:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:27:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:27:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:27:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:27:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:27:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:28:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:28:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:28:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:28:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:28:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:28:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:28:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:28:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:28:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:28:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:28:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:29:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:29:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:29:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:29:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:29:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:29:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:29:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:29:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:30:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:30:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:30:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:30:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:30:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:30:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:30:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:30:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:30:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:30:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:30:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:31:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:31:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:31:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:31:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:31:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:31:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:31:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:31:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:31:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:31:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:31:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:34:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:34:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:34:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:34:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:34:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:34:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:34:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:34:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:34:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:34:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:35:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:35:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:35:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:35:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:35:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:35:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:36:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:36:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:36:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:36:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:36:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:37:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:37:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:37:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:37:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:37:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:38:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:38:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:38:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:38:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:38:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:38:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:38:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:39:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:39:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:39:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:39:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:39:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:39:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:39:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:39:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:39:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:39:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 19:39:53 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 29
Warning - 2012-09-18 19:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:39:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:39:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:39:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:40:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:40:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:40:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:40:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:40:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:40:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:40:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:40:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:40:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:43:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:43:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:43:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:43:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:43:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:43:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:43:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:43:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:43:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:43:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:43:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:43:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:43:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:43:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:44:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:44:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:44:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:44:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:44:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:44:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:44:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:44:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:45:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:45:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:45:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:46:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:46:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:46:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:46:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:46:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:49:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:49:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:49:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:49:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:49:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:49:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:49:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:50:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:50:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:50:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:50:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:50:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:50:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:50:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:50:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:51:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:51:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:52:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:52:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:52:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:53:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:53:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:53:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:53:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:53:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:53:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:53:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:53:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:53:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:53:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:53:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:54:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:54:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:54:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:54:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:54:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:54:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:54:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:54:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:54:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:56:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:56:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:56:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:56:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:56:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 19:57:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 19:57:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 19:57:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:34:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:34:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:37:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:37:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:37:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:37:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:37:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:37:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:37:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:37:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:38:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:38:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:38:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:38:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:38:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:38:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:38:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:38:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:38:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:38:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:38:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:38:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:38:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:38:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:39:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:39:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:39:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:39:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:39:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:39:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:39:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:39:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:39:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:40:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:40:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:40:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:40:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:41:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:41:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:41:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:41:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:41:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:41:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:42:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:42:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:42:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:42:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:42:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:42:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:42:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:42:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:44:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:44:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:44:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:44:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:44:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:44:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:44:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:44:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 20:44:59 --> 8 - Undefined index: rentmin in C:\wamp\fuel\app\classes\controller\showlistings.php on line 23
Error - 2012-09-18 20:44:59 --> 8 - Undefined index: rentmax in C:\wamp\fuel\app\classes\controller\showlistings.php on line 24
Error - 2012-09-18 20:44:59 --> 8 - Undefined index: rooms in C:\wamp\fuel\app\classes\controller\showlistings.php on line 25
Error - 2012-09-18 20:44:59 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\classes\controller\showlistings.php on line 26
Error - 2012-09-18 20:44:59 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN  AND" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-09-18 20:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:45:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:45:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:45:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:45:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:45:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:46:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:46:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:46:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:46:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:46:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:47:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:47:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:47:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:47:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:47:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:47:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:47:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:47:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:47:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:47:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:47:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:48:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:48:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:48:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:48:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:48:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:48:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:48:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:48:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:49:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:49:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:49:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:49:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:49:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:49:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:49:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:49:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:49:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:50:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:50:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:50:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:50:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:50:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:50:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:50:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:50:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:50:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:50:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:50:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:51:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:51:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:52:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:52:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:52:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:52:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:52:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:52:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 20:52:49 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Warning - 2012-09-18 20:52:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:52:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:53:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:53:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 20:53:03 --> Error - Cannot use [] for reading in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Warning - 2012-09-18 20:53:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:53:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:53:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:53:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:53:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:53:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:53:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:53:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:53:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:53:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 20:53:45 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Warning - 2012-09-18 20:53:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:53:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:54:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:54:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:54:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:54:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:54:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:54:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:54:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:54:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:54:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:55:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:55:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:55:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:55:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:55:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:55:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:56:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:56:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:57:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:57:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:57:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:57:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:57:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:58:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:58:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:58:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:58:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:58:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:58:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:58:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:58:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:58:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:58:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:58:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:59:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:59:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:59:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:59:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:59:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:59:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 20:59:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 20:59:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 20:59:50 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\classes\model\mapgen.php on line 29
Warning - 2012-09-18 20:59:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 20:59:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:00:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:00:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:00:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:01:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:01:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:01:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:01:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:01:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:01:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:01:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:01:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:01:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:01:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:01:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:02:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:02:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:02:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 21:02:12 --> Error - Cannot use [] for reading in C:\wamp\fuel\app\classes\model\mapgen.php on line 29
Warning - 2012-09-18 21:02:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:02:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:02:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:02:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:02:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:03:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:03:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:03:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:03:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:03:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:03:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:03:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:03:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:04:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:04:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:04:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:04:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:04:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 21:04:44 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Warning - 2012-09-18 21:05:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:05:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:05:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:05:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:05:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:05:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:05:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:05:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:07:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:07:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:07:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:07:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:07:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:07:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:07:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:07:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:08:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:08:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:08:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:08:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:08:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:08:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:08:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:08:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:08:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:08:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:08:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:08:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:09:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:09:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:09:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:09:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:09:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:09:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:09:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:09:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:09:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:09:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:10:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:10:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:10:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:10:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:10:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:10:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:11:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:11:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:11:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:11:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:11:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:11:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:11:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:11:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:12:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:12:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:12:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:12:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:12:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:12:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:12:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:12:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:16:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:16:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:16:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:16:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:16:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:16:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:16:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:16:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:18:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:18:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:18:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:18:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:18:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:18:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:18:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:18:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:18:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:18:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:18:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:18:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:19:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:19:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:19:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:19:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:19:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:19:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:19:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:19:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:19:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:19:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:19:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:20:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:20:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:20:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:20:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:20:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:20:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:20:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:20:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:21:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:21:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:21:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:21:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:21:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:22:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:22:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:22:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:22:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:22:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:23:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:23:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:23:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:23:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:23:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:23:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:23:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:23:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:23:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:23:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:23:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:24:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:24:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:24:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:25:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:25:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:25:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:25:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:25:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:25:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:25:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:25:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:28:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:28:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:28:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:28:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:28:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:29:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:29:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:29:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:29:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:29:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:29:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:29:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:29:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:29:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:29:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:29:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:29:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:30:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:30:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:30:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:30:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:30:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:30:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:30:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:31:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:31:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:31:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:31:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:31:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:31:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:31:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:32:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:32:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:32:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:32:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:32:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:32:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:33:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:33:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:33:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:33:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:33:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:33:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:33:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:33:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:33:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:33:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:34:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:34:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:34:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:34:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:34:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:35:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:35:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:35:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:35:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:35:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:36:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:36:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:36:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:36:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:36:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:36:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:36:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:36:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:38:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:38:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:38:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:38:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:38:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:38:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:38:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:38:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:40:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:40:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:40:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:40:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:40:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:41:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:41:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:41:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:41:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:41:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:41:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:41:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:41:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:41:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:55:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:55:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:55:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:55:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:55:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:55:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:55:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:55:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:55:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:56:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:56:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:56:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:56:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:56:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:56:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:56:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:56:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:56:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:58:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:58:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:58:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:58:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:58:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:58:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:58:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:58:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:58:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:58:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:59:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:59:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:59:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:59:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 21:59:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:59:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 21:59:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 21:59:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:00:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:00:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:00:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:00:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:00:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:00:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:00:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:00:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:00:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:00:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:00:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:00:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:00:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:00:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:02:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:02:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:02:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:02:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:02:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:02:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:02:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:02:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:02:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:03:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:03:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:03:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:07:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:07:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:07:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:07:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:07:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:07:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:07:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:07:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:08:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:08:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:08:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:08:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:08:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:08:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:08:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:08:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:08:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:09:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:09:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:09:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:09:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:09:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:09:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:09:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:09:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:11:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:11:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:11:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:11:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:11:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:11:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:11:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:11:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:13:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:13:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:13:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:13:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:13:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:13:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:13:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:13:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:14:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:14:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:14:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:14:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:14:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:14:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:14:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:14:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:17:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:17:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:17:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:17:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:17:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:17:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:17:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:17:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:17:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:17:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:17:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:18:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:19:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:19:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:19:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:19:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:19:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:20:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:20:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:20:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:20:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:20:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:20:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:21:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:21:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:21:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:21:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:21:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:21:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:21:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:22:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:22:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:22:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:31:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:31:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:31:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:31:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:31:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:31:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:31:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:31:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:31:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:31:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:31:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:32:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:35:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:35:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:35:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:35:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:35:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:35:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:35:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:35:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:35:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:38:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:38:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:38:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:38:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:38:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:38:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:38:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:40:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:40:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:40:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:40:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:40:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:40:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:40:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:40:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:40:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:40:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:40:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:40:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:40:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:41:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:41:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:41:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:41:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 22:42:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 22:42:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 22:42:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:03:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:03:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:03:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:03:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 23:03:53 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 32
Warning - 2012-09-18 23:03:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:03:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 23:03:54 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 32
Warning - 2012-09-18 23:03:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:03:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:03:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:03:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:03:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:04:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 23:04:01 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 32
Warning - 2012-09-18 23:04:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:04:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:07:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 23:07:35 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 32
Warning - 2012-09-18 23:07:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:07:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:07:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:07:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:07:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:07:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:07:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:07:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:10:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:10:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:10:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:10:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:10:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:11:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:11:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:11:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:11:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:11:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:11:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:11:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:11:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:11:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:11:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:12:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:12:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:12:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:14:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:14:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:14:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:14:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:14:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:15:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:15:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:15:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:15:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:15:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:17:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:17:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:17:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:17:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:17:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:17:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:18:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:18:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:20:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:20:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:20:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:20:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:20:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:22:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:22:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:22:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:22:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:22:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:22:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:22:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:22:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:22:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:22:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:23:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:23:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:23:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:23:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:23:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:23:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:23:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:23:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:23:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:23:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:23:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:24:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:24:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:24:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:24:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:24:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:24:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:24:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:24:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:24:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:24:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:25:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:25:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:25:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:26:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:26:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:26:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:30:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:30:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:30:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:30:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:30:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:30:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:30:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:30:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:31:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:31:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:32:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:32:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:32:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:32:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:32:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:32:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:32:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:32:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:34:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:34:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:34:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:34:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:34:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:34:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:34:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:34:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:34:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:34:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:34:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:34:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:34:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 23:34:46 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 32
Warning - 2012-09-18 23:34:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:34:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:34:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-18 23:34:47 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 32
Warning - 2012-09-18 23:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-09-18 23:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-09-18 23:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-18 23:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
