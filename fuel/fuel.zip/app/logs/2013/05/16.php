<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-05-16 00:10:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:10:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:10:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:10:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:10:56 --> 8 - Undefined variable: somedata in C:\wamp\fuel\app\classes\model\mapgen.php on line 42
Error - 2013-05-16 00:10:56 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:10:56 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-05-16 00:10:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:10:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:11:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:11:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:11:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:11:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:11:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:11:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:13:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:13:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:13:59 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:13:59 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location=' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location ORDER BY rentsignals.id WHERE images.location=" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:13:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:13:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:14:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:14:06 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:14:06 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location=rozelle' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location ORDER BY rentsignals.id WHERE images.location=rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:15:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:15:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:15:12 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:15:12 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location=''' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location ORDER BY rentsignals.id WHERE images.location=''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:15:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:15:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:15:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:15:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:15:18 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:15:18 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location='rozelle'' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location ORDER BY rentsignals.id WHERE images.location='rozelle'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:17:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:17:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:17:14 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:17:14 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-05-16 00:17:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:17:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:17:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:17:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:17:41 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:17:41 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location='" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:17:49 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:17:49 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''rozelle' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location='rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:18:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:18:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:18:15 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:18:15 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:18:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:18:22 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:18:22 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:19:45 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:19:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-05-16 00:19:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:19:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:20:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:20:01 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-16 00:20:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:20:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:20:52 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:20:52 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-05-16 00:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:20:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:20:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:20:59 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:20:59 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-05-16 00:22:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:22:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:22:22 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:22:22 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Warning - 2013-05-16 00:22:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:22:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:22:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:22:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:22:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:22:30 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-16 00:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:23:34 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:23:34 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 27
Error - 2013-05-16 00:23:34 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Warning - 2013-05-16 00:23:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:23:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:23:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:23:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:23:49 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:23:49 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 27
Warning - 2013-05-16 00:23:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:23:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:23:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:23:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:24:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:24:05 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:24:05 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 40
Warning - 2013-05-16 00:24:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:24:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:24:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:24:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:24:35 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:24:35 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Warning - 2013-05-16 00:24:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:24:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:24:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:24:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:25:00 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-05-16 00:25:00 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:25:00 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:25:00 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:25:00 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:25:00 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Warning - 2013-05-16 00:25:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:25:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:26:17 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-05-16 00:26:17 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:26:17 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:26:17 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:26:17 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-05-16 00:26:17 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 38
Warning - 2013-05-16 00:26:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:26:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:26:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:26:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:26:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:26:57 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 35
Error - 2013-05-16 00:26:57 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 42
Warning - 2013-05-16 00:26:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:26:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:27:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:27:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:28:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:28:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:28:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:28:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:29:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:29:02 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:29:02 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:29:02 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Warning - 2013-05-16 00:29:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:29:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:29:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:29:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:29:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:29:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:29:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:29:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:29:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:29:28 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:29:28 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:29:28 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Warning - 2013-05-16 00:29:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:29:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:29:38 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:29:38 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-16 00:29:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Warning - 2013-05-16 00:29:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:29:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:30:12 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:30:12 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
Warning - 2013-05-16 00:30:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:30:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:30:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:30:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:30:24 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-16 00:30:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:30:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:30:52 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:30:52 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:30:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:30:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:31:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:31:01 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Warning - 2013-05-16 00:31:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:31:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:31:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:31:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:31:33 --> 8 - Undefined index: rentals in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:31:34 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:31:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:31:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:31:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:31:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:32:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:32:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:32:33 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 13 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-16 00:32:33 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:32:33 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:32:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:32:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:32:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:32:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:33:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:33:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:33:54 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:33:54 --> Error - Cannot use string offset as an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 00:33:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:33:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:34:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:34:01 --> Error - Cannot use string offset as an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 00:34:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:34:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:34:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:34:37 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:34:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'rentals":{"id":"2","location":"mascot","description":"mascot eastern sydney","la' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="[{"rentals":{"id":"2","location":"mascot","description":"mascot eastern sydney","lat":"-33.931189","lng":"151.19431","rent":"500","avail_from":"2012-06-15","created_at":"1339772561","updated_at":"1340181677","rooms":"1","bathrooms":"2"}},{"rentals":{"id":"3","location":"rozelle","description":"nice new apartment, sharing with hot female","lat":"-33.863063","lng":"151.170573","rent":"700","avail_from":"2012-06-15","created_at":"1340181739","updated_at":"1340181739","rooms":"1","bathrooms":"2"}}]"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 00:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:35:11 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:35:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:35:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:35:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:35:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:35:18 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:35:18 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Error - 2013-05-16 00:35:18 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2013-05-16 00:35:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:35:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:35:51 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:35:52 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:35:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:35:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:35:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:35:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:35:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:35:59 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:35:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Error - 2013-05-16 00:35:59 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2013-05-16 00:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:36:21 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:36:21 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:36:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:36:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:36:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:37:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:37:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:37:19 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:37:19 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:37:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:37:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:37:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:37:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:37:52 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:37:52 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:37:52 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:37:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:37:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:38:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:38:21 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:38:21 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:38:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:38:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:38:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:38:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:38:39 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:38:39 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:38:39 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:38:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:38:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:38:56 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:38:56 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:38:56 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:38:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:38:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:39:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:39:07 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:39:07 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:39:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:39:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:39:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:39:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:39:17 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:39:17 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:39:17 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:39:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:39:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:39:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:39:26 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\mapgen.php on line 39
Error - 2013-05-16 00:39:26 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:39:26 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:39:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:39:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:39:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:39:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:39:34 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:39:34 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:39:34 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:40:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:40:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:40:04 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:40:04 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:40:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:40:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:40:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:40:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:40:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:40:13 --> Error - Cannot use [] for reading in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2013-05-16 00:40:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:40:24 --> 8 - Undefined variable: images in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-16 00:40:24 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:40:24 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:40:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:40:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:40:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:40:42 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:40:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:40:42 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:40:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:40:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:41:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:41:04 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Warning - 2013-05-16 00:41:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:41:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:41:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:41:18 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Warning - 2013-05-16 00:41:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:41:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:41:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:41:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:41:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Error - 2013-05-16 00:41:42 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:41:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:41:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:42:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:42:19 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
Error - 2013-05-16 00:42:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:42:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:42:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:42:25 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:42:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:42:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:42:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:42:33 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
Error - 2013-05-16 00:42:33 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:42:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:42:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:43:19 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:43:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:43:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:43:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:43:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:43:26 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 00:43:26 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
Error - 2013-05-16 00:43:26 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:43:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:43:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:43:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:43:36 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
Error - 2013-05-16 00:43:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:43:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:43:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:46:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:46:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:46:49 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:46:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:46:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:46:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:46:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:47:28 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 65
Warning - 2013-05-16 00:47:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:47:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:47:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:47:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:47:39 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
Error - 2013-05-16 00:47:39 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 65
Warning - 2013-05-16 00:47:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:47:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:47:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:47:57 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
Error - 2013-05-16 00:47:57 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 65
Warning - 2013-05-16 00:47:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:47:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:48:52 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:48:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:48:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:49:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:49:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:49:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:49:23 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
Warning - 2013-05-16 00:49:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:49:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:49:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:49:43 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Warning - 2013-05-16 00:49:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:49:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:49:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:49:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:49:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:50:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:50:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:50:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:50:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:50:35 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:50:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:50:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:50:40 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 64
Warning - 2013-05-16 00:50:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:50:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:51:30 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:51:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:51:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:51:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:51:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 63
Warning - 2013-05-16 00:51:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:51:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:52:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:52:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:52:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:52:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:52:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:52:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:52:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:52:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:53:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:53:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:53:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:53:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:53:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:53:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:53:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:53:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:53:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:54:06 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
Error - 2013-05-16 00:54:06 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-05-16 00:54:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:54:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:54:44 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 00:54:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:54:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:54:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:54:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:54:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:55:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:55:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:55:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:55:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:55:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:55:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:55:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:55:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:56:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:56:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:56:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:56:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:56:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:56:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:57:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:57:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:57:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:57:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:57:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:57:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:57:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:57:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:57:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:57:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:57:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:57:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:58:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:58:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:58:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:58:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:58:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:58:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:58:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:58:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:58:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:59:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:59:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:59:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:59:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:59:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 00:59:46 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 00:59:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 00:59:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 00:59:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 00:59:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:00:15 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:00:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:00:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:00:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:01:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:01:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:01:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:01:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:01:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:01:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:02:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:02:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:02:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:02:44 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:02:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:02:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:02:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:02:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:03:08 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:03:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:03:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:03:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:03:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:03:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:03:31 --> Error - Cannot use [] for reading in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Warning - 2013-05-16 01:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:04:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:04:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:04:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:04:45 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'imagesloc":"rozelle"}"' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location="{"imagesloc":"rozelle"}"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 01:05:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:05:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:05:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:05:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:05:38 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:05:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:05:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:06:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:06:03 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:06:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:06:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:06:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:06:22 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:06:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:06:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:06:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:06:41 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:06:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:06:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:06:53 --> 8 - Undefined index: rozelle in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:07:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:07:20 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:07:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:07:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:07:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:08:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:08:32 --> Error - Cannot use string offset as an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-05-16 01:09:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:09:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:09:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:09:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:09:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:09:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:09:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:09:38 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:09:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:09:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:10:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:10:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:10:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:10:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:10:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:11:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:11:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:11:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:11:35 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:11:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:11:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:12:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:12:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:12:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:12:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:12:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:12:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:12:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:12:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:12:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:13:55 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-05-16 01:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:14:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:14:05 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-05-16 01:14:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:14:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:14:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:14:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:14:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:14:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:15:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:15:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:15:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:15:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:15:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:16:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:16:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:16:48 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
Warning - 2013-05-16 01:16:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:16:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:16:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:16:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:17:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:17:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:17:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:17:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:17:44 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:17:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:17:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:17:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:17:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:19:14 --> 8 - Uninitialized string offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:19:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:19:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:19:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:19:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:20:16 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-16 01:20:16 --> Error - Cannot use string offset as an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:20:35 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:20:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:20:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:20:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:20:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:21:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:21:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:21:55 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Warning - 2013-05-16 01:21:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:21:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:22:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:22:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:22:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:22:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:22:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:22:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:23:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:23:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:23:12 --> 8 - Uninitialized string offset: 0 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-05-16 01:23:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:23:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:23:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:23:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:23:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:23:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:23:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:23:44 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 with query: "SELECT * FROM `images` WHERE location=" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-16 01:24:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:24:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:24:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:25:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:25:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:25:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:25:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:26:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:26:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:27:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:27:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:27:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:27:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:27:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:27:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:27:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:27:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:27:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:28:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:28:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:28:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:29:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:29:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:29:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:29:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:29:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:29:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:30:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:30:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:30:18 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-05-16 01:30:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:30:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:31:03 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Warning - 2013-05-16 01:31:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:31:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:31:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:31:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-16 01:31:22 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-05-16 01:31:22 --> 8 - Uninitialized string offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2013-05-16 01:31:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:31:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-16 01:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-16 01:31:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-16 01:31:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
