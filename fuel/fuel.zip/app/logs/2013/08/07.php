<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-08-07 21:28:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:28:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:28:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:28:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:28:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:28:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:28:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:28:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:31:31 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 67
Warning - 2013-08-07 21:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:31:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:31:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:31:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:31:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:31:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:31:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:31:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:34:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:34:12 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 67
Warning - 2013-08-07 21:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:34:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:34:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:34:58 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:34:58 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:35:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:35:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:35:32 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:35:32 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:35:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:35:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:37:58 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:37:58 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:39:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:39:00 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 6
Error - 2013-08-07 21:39:00 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 38
Warning - 2013-08-07 21:39:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:39:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:39:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:39:52 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:39:52 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:42:34 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 68
Warning - 2013-08-07 21:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:42:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:42:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:44:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:44:18 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 68
Warning - 2013-08-07 21:44:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:44:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:44:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:44:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:44:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:44:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 21:50:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:50:28 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:50:28 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:50:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:50:52 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:50:52 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-08-07 21:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:51:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:51:51 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 4
Error - 2013-08-07 21:51:51 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 37
Warning - 2013-08-07 21:51:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:51:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:51:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:53:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:53:12 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:53:12 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:53:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:53:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:53:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:53:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:53:38 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:53:38 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:53:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:53:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:53:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:54:03 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 21:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:55:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:55:22 --> 8 - Undefined variable: site_title in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 21:55:22 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 4
Error - 2013-08-07 21:55:22 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2013-08-07 21:55:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:55:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:55:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 21:59:30 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 68
Warning - 2013-08-07 21:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:59:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 21:59:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 21:59:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:00:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:00:27 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 22:00:27 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 22:00:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:00:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:00:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:00:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:00:43 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 30
Warning - 2013-08-07 22:00:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:00:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:00:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:01:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:01:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:01:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:03:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:03:41 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 22:03:41 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 22:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:09:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:09:31 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 22:09:31 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 22:09:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:09:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:09:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:09:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:09:58 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\views\welcome\index.php on line 67
Warning - 2013-08-07 22:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:10:12 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 67
Warning - 2013-08-07 22:10:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:10:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:10:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:10:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:10:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:10:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:16:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:16:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:16:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:16:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:16:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:16:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:16:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:16:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:26:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:26:45 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 67
Warning - 2013-08-07 22:26:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:26:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:30:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:30:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:30:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:31:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:31:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:31:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:32:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:32:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:32:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:32:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:32:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:32:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:32:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:34:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:34:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:34:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-08-07 22:36:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-08-07 22:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-08-07 22:36:34 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-08-07 22:36:34 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-08-07 22:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-07 22:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
