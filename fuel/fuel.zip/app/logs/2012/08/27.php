<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-27 19:09:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:09:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:09:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:09:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 19:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 19:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 19:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:01:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:01:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:01:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:01:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:01:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:01:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:01:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:01:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:01:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:01:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:02:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:02:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:02:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:03:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:03:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:04:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:04:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:04:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:05:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:05:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:05:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:05:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:05:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:05:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:05:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:05:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:05:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:05:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:05:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:05:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:05:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:05:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:05:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:05:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:05:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:12:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:12:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:12:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:12:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:12:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:12:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:12:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:12:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:12:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:12:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:13:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:13:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:13:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:13:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:13:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:14:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:14:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:14:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:14:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:14:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:16:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:16:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:16:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:16:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:16:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:16:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:16:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:16:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:16:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:16:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:18:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:18:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:18:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:18:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:18:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:18:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:18:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:18:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:27:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:27:45 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:27:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:27:46 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:27:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:27:47 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:27:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:27:52 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:27:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:27:52 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:27:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:27:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:27:53 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:27:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:28:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:28:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:28:00 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:28:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:28:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:28:19 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:28:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:28:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:28:27 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:28:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:29:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:29:19 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:29:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:11 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:15 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:16 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:17 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:17 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:33 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:55:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:55:34 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:55:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:56:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:56:43 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:56:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:57:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:57:16 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:57:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:57:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:57:17 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:57:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:57:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:57:41 --> Parsing Error - syntax error, unexpected ';', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 29
Warning - 2012-08-27 21:57:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:57:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:57:58 --> 8 - Undefined property: Fuel\Core\Database_Query::$execute in C:\wamp\fuel\app\classes\model\showlistings.php on line 29
Warning - 2012-08-27 21:57:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:57:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:57:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:58:13 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column '$rentrange' in 'where clause' with query: "SELECT * FROM `rentsignals` WHERE rent LIKE $rentrange" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-27 21:58:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:58:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:58:53 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '["rentmind","rentmax"]' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent LIKE $rentrange["rentmind","rentmax"]" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-27 21:58:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:59:14 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '["rentmin","rentmax"]' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent LIKE $rentrange["rentmin","rentmax"]" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-27 21:59:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:59:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:59:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:59:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:59:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 21:59:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 21:59:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 21:59:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 21:59:49 --> Parsing Error - syntax error, unexpected '(', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 21:59:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 22:00:08 --> Parsing Error - syntax error, unexpected '(', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 22:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:00:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 22:00:54 --> Parsing Error - syntax error, unexpected '(', expecting T_VARIABLE or '$' in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 22:00:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:01:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 22:01:26 --> Error - Call to undefined function Model\jQuery() in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2012-08-27 22:01:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 22:28:20 --> 2 - Missing argument 1 for Controller_ShowListings::action_getListings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 7
Error - 2012-08-27 22:28:20 --> 2 - Missing argument 2 for Controller_ShowListings::action_getListings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 7
Error - 2012-08-27 22:28:20 --> 2 - Missing argument 3 for Controller_ShowListings::action_getListings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 7
Error - 2012-08-27 22:28:20 --> 2 - Missing argument 4 for Controller_ShowListings::action_getListings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 7
Error - 2012-08-27 22:28:20 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-27 22:28:20 --> 8 - Undefined variable: rentmax in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2012-08-27 22:28:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:28:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:29:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 22:29:18 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-27 22:29:18 --> 8 - Undefined variable: rentmax in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-27 22:29:18 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-27 22:29:18 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-27 22:29:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:29:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-27 22:29:46 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2012-08-27 22:29:46 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2012-08-27 22:29:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:30:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:30:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:30:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:30:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:30:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:30:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:30:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:30:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:52:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:52:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:52:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:52:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:52:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:52:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:52:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:52:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 22:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 22:52:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 22:52:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:46:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:46:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:46:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:46:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:46:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:46:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:46:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:46:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:47:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:47:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:47:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:47:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:47:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:47:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:47:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:47:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:47:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:47:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:48:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:48:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:48:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:48:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:48:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-27 23:48:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-27 23:48:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-27 23:48:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
