<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-01-30 13:19:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
