<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-08-10 10:21:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-10 10:22:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-10 10:22:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-10 10:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-10 10:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-08-10 10:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
