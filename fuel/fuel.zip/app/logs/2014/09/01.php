<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-09-01 23:14:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-01 23:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-09-01 23:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
