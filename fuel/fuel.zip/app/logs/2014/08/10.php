<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-08-10 22:14:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-10 22:15:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-08-10 22:20:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
