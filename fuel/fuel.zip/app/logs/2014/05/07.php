<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-05-07 00:00:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:00:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:00:17 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 00:00:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:00:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:00:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:00:24 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:00:24 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:02:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:02:55 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:02:55 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:03:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:03:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:03:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:03:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:03:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:03:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:03:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:03:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:05:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:05:00 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:05:00 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:05:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:05:18 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 00:05:18 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 00:05:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:05:18 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 00:05:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:05:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:05:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:05:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:05:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:06:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:06:01 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '$' in C:\wamp\fuel\app\views\admin\login.php on line 49
Warning - 2014-05-07 00:06:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:06:11 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '$' in C:\wamp\fuel\app\views\admin\login.php on line 49
Warning - 2014-05-07 00:06:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:06:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:06:16 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '$' in C:\wamp\fuel\app\views\admin\login.php on line 49
Warning - 2014-05-07 00:06:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:06:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:06:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:09:37 --> 4096 - Argument 3 passed to Fuel\Core\Form::input() must be an array, null given, called in C:\wamp\fuel\app\views\admin\login.php on line 49 and defined in C:\wamp\fuel\core\classes\form.php on line 179
Warning - 2014-05-07 00:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:10:24 --> 4096 - Argument 3 passed to Fuel\Core\Form::input() must be an array, null given, called in C:\wamp\fuel\app\views\admin\login.php on line 49 and defined in C:\wamp\fuel\core\classes\form.php on line 179
Warning - 2014-05-07 00:10:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:10:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:10:28 --> 4096 - Argument 3 passed to Fuel\Core\Form::input() must be an array, null given, called in C:\wamp\fuel\app\views\admin\login.php on line 49 and defined in C:\wamp\fuel\core\classes\form.php on line 179
Warning - 2014-05-07 00:11:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:11:28 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW in C:\wamp\fuel\app\views\admin\login.php on line 49
Warning - 2014-05-07 00:11:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:11:38 --> 4096 - Argument 3 passed to Fuel\Core\Form::input() must be an array, null given, called in C:\wamp\fuel\app\views\admin\login.php on line 49 and defined in C:\wamp\fuel\core\classes\form.php on line 179
Warning - 2014-05-07 00:12:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:12:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:12:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:13:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:13:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:13:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:14:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:14:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:14:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:16:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:16:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:16:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:20:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:20:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:20:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:21:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:21:52 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:21:52 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:22:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:22:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:22:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:23:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:23:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:23:23 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:24:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:24:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:24:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:24:24 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:24:24 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:25:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:25:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:26:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:26:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:26:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:28:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:28:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:28:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:28:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:28:26 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:28:26 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:29:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:29:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:29:22 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:30:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:30:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:30:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:31:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:31:30 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:31:30 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:33:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:33:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:33:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:35:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:35:04 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:35:04 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:36:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:36:15 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:36:15 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:36:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:36:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:36:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:36:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:36:47 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:36:47 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:37:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:37:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:37:29 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:37:29 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:37:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:37:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:37:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:37:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:39:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:39:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:39:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:39:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:39:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:40:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:40:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:40:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:41:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:41:33 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:41:33 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:41:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:41:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:41:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:41:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:42:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:42:01 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 00:42:01 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 00:42:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:01 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 00:42:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:25 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 00:42:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:43 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 00:42:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:42:47 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:42:47 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:43:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:43:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:43:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:43:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:43:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:43:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:44:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:44:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:44:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:44:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:44:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:44:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:44:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:44:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:44:59 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:46:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:46:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:46:02 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:46:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 00:46:14 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\fuel\app\views\admin\login.php on line 22
Warning - 2014-05-07 00:46:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:46:25 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:46:25 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:46:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:46:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:46:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:47:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:47:14 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:47:14 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:48:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:48:25 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:48:25 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:48:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:48:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:48:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:49:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:49:25 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:49:25 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:49:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:49:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:49:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:49:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:49:55 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:49:55 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:50:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:50:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:50:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:50:56 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Error - 2014-05-07 00:50:56 --> Error - Call to undefined method Fuel\Core\Form::post() in C:\wamp\fuel\app\views\admin\login.php on line 22
Warning - 2014-05-07 00:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 00:51:04 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 00:51:04 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:51:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:51:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:51:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:52:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:52:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:52:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:52:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:54:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:54:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:57:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:57:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:57:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:58:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:58:15 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:58:15 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:58:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 19:58:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 19:58:36 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:00:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:00:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:00:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:03:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:03:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:03:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:04:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:04:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:04:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:04:32 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:04:32 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:04:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:04:34 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:04:34 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:05:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:05:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:05:17 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:06:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:06:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:06:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:09:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:09:12 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:09:12 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:09:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:09:55 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:09:55 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:10:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:03 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:10:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:10:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:10:53 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:10:53 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:11:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:11:08 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:11:08 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:12:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:12:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:12:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:13:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:13:21 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:13:21 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:13:31 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:13:31 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:14:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:14:12 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Error - 2014-05-07 20:14:12 --> Error - Call to undefined method Fuel\Core\Form::post() in C:\wamp\fuel\app\views\admin\login.php on line 20
Warning - 2014-05-07 20:14:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:14:32 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:14:32 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:14:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:14:50 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:14:50 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:17:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:17:20 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:19:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:19:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:19:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:19:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:19:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:19:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:20:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:20:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:20:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:20:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:21:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:21:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:21:06 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:21:06 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:26:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:26:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:26:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:27:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:27:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:27:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:29:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:29:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:29:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:29:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 20:29:40 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 20:29:40 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 20:29:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:29:40 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 20:29:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:29:54 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 20:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:30:52 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 20:30:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:30:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:30:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:30:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:30:57 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:31:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 20:31:04 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 20:31:04 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 20:31:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:31:04 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 20:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:31:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:31:44 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 20:31:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 20:31:50 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 20:31:50 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 20:31:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 20:31:50 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Error - 2014-05-07 20:31:50 --> 8 - Undefined variable: section_segment in C:\wamp\fuel\app\views\admin\template.php on line 45
Error - 2014-05-07 20:31:50 --> 8 - Undefined variable: section_segment in C:\wamp\fuel\app\views\admin\template.php on line 46
Error - 2014-05-07 20:31:50 --> 8 - Undefined variable: section_title in C:\wamp\fuel\app\views\admin\template.php on line 46
Warning - 2014-05-07 21:38:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:38:27 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Error - 2014-05-07 21:38:27 --> 8 - Undefined variable: section_segment in C:\wamp\fuel\app\views\admin\template.php on line 45
Error - 2014-05-07 21:38:27 --> 8 - Undefined variable: section_segment in C:\wamp\fuel\app\views\admin\template.php on line 46
Error - 2014-05-07 21:38:27 --> 8 - Undefined variable: section_title in C:\wamp\fuel\app\views\admin\template.php on line 46
Warning - 2014-05-07 21:38:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:38:36 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Error - 2014-05-07 21:38:36 --> 8 - Undefined variable: section_segment in C:\wamp\fuel\app\views\admin\template.php on line 45
Error - 2014-05-07 21:38:36 --> 8 - Undefined variable: section_segment in C:\wamp\fuel\app\views\admin\template.php on line 46
Error - 2014-05-07 21:38:36 --> 8 - Undefined variable: section_title in C:\wamp\fuel\app\views\admin\template.php on line 46
Warning - 2014-05-07 21:38:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:38:48 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 21:38:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:38:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:38:54 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 21:39:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:39:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 21:39:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 21:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 21:39:46 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 21:39:46 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 21:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 21:39:46 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 22:48:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:03 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 22:48:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:48:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:48:13 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:48:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:48:19 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 22:48:24 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 22:48:24 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 22:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:48:24 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 22:50:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:50:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:50:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:50:38 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:50:38 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:50:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 22:50:43 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 22:50:43 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 22:50:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:50:43 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 22:56:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:56:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:56:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:56:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:56:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 22:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 22:56:22 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 22:56:22 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 22:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 22:56:22 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:03:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:03:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:04:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:05:40 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:05:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:06:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:07:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:07:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:07:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:07:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:07:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:07:37 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:07:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:07:49 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:07:49 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:07:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:07:49 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:07:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:08:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:08:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:08:00 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:08:00 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:13:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:13:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:14:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:14:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:14:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:14:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:15:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:15:49 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:15:49 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:15:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:15:49 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:20:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:15 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:20:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:20:28 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:20:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:20:38 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:20:38 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:20:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:38 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:20:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:20:55 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:21:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:21:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:21:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:21:26 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:21:26 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:21:33 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:21:33 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:21:33 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:29:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:29:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:29:35 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:29:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:30:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:30:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:30:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:30:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:30:59 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:30:59 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:30:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:30:59 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:31:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:31:18 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:32:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:32:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:32:08 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:32:08 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:32:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:32:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:32:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:33:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:34:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:34:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:34:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:34:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:34:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:34:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:34:49 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:34:49 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:34:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:34:49 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:35:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:35:05 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:35:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:35:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:35:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:35:09 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:37:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:37:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:37:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:37:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:37:11 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:37:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:37:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:37:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:37:41 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:39:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:39:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:39:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:39:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:39:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:39:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:39:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:39:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:39:35 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:39:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:40:46 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:40:46 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:44:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:44:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:44:54 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:49:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:49:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:49:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:49:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:49:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:49:47 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:49:47 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:51:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:51:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:51:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:51:26 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:51:26 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:51:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:51:32 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:51:32 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:51:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:51:32 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:53:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:54:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:54:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:54:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:54:13 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:54:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:57:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:57:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:57:47 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:58:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:58:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:58:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:58:01 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:58:01 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:59:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:59:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:59:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:59:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:59:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-05-07 23:59:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-05-07 23:59:25 --> 8 - Undefined variable: current_user in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Error - 2014-05-07 23:59:25 --> 8 - Trying to get property of non-object in C:\wamp\www\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-05-07 23:59:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:59:25 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-05-07 23:59:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:59:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-05-07 23:59:58 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
