<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-01-09 12:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:27:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:27:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:27:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:27:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:29:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:29:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:29:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:29:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:29:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:29:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:36:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:36:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 12:41:15 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
Warning - 2013-01-09 12:41:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:41:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:41:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:41:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:41:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:41:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:42:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:42:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 12:42:14 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0,8' at line 1 with query: "SELECT * FROM `images` order by idlimit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 12:42:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:42:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:42:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:42:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 12:42:36 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0,8' at line 1 with query: "SELECT * FROM `images` order by idlimit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 12:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:42:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:42:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 12:42:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 12:42:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:43:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 12:43:20 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
Warning - 2013-01-09 12:43:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 12:43:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 12:43:41 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
Warning - 2013-01-09 12:43:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:23:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 14:23:53 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-01-09 14:23:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:48:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 14:48:17 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-01-09 14:48:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:48:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:48:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 14:48:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 14:48:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 14:48:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:07:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:07:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:07:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:07:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:07:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:07:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:07:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:07:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:07:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:08:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:08:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:08:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:09:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:09:00 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:09:00 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:09:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:09:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:09:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:09:04 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:09:04 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:09:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:09:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:09:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:09:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:09:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:09:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:09:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:09:37 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:09:37 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:09:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:09:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:10:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:10:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:10:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:23 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:10:23 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:25 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:10:25 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:26 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:10:26 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:39 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:10:39 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:10:39 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:43 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:51 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:51 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:10:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:10:56 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:10:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:10:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:11:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:11:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:11:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:11:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:11:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:12:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:12:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:07 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:07 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:08 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:08 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:08 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:08 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:08 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:08 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:18 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:18 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:18 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:19 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:19 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:19 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:25 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:25 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:25 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:30 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:30 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:30 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:12:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:12:33 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:33 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:12:33 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:12:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:12:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:15:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:15:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:15:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:15:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:15:56 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:15:56 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:15:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:15:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:15:59 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:15:59 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:15:59 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:15:59 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:15:59 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:15:59 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:15:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:16:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:16:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:16:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:16:21 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Error - 2013-01-09 15:16:21 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\mapgen.php on line 36
Warning - 2013-01-09 15:16:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:16:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:16:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:16:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:16:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:17:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:17:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:17:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:17:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:18:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:18:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:18:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:18:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:18:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:18:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:18:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:18:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:18:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:46:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:46:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:46:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:46:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:46:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:46:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:46:48 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:46:48 --> Error - Undefined class constant 'Select' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Warning - 2013-01-09 15:47:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:47:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:47:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:47:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:47:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:47:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:47:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:47:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:47:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:47:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:48:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:48:04 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:48:04 --> Error - Undefined class constant 'Select' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Warning - 2013-01-09 15:49:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:49:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:49:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:49:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:49:45 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:49:45 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location= rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 15:51:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:51:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:51:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:51:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:51:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:51:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:51:48 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:51:48 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location=rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 15:51:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:51:51 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:51:51 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location=rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 15:53:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:53:30 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:53:30 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location=rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 15:54:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:54:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:54:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:54:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:54:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:57:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:57:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:57:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:57:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:57:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:58:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:58:00 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:58:00 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location LIKE rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 15:58:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:58:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:58:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 15:58:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 15:58:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:58:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:58:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 15:58:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 15:58:19 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 15:58:19 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location LIKE rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:02:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:02:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:02:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:02:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:02:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:02:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:02:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:02:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:02:54 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:02:54 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE location LIKE rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:03:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:03:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:03:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:03:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:03:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:03:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:03:55 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:03:55 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'glebe' in 'where clause' with query: "SELECT * FROM `images` WHERE location LIKE glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:04:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:04:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:04:36 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:04:36 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'glebe' in 'where clause' with query: "SELECT * FROM images WHERE location LIKE glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:07:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:07:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:07:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:07:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:07:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:07:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:07:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:07:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:07:24 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:07:24 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'glebe' in 'where clause' with query: "SELECT * FROM `images` WHERE `location` LIKE glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:08:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:08:10 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:08:10 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
Error - 2013-01-09 16:08:10 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
Error - 2013-01-09 16:08:10 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 87
Warning - 2013-01-09 16:08:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:08:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:08:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:08:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:08:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:09:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:09:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:09:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:09:12 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:09:12 --> 8 - Undefined index: "location" in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Error - 2013-01-09 16:09:12 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 with query: "SELECT * FROM `images` WHERE `location` LIKE" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:10:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:10:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:10:17 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:10:17 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE `location` LIKE rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:10:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:10:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:10:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:10:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:10:41 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:10:41 --> 8 - Undefined index: 'location' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Error - 2013-01-09 16:10:41 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 with query: "SELECT * FROM `images` WHERE `location` LIKE" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:11:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:11:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:11:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:11:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:11:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:11:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:11:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:11:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:11:22 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:11:22 --> 8 - Use of undefined constant location - assumed 'location' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Error - 2013-01-09 16:11:22 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'rozelle' in 'where clause' with query: "SELECT * FROM `images` WHERE `location` LIKE rozelle" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 16:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:12:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:12:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:12:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:12:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:12:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:12:06 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 47
Error - 2013-01-09 16:12:06 --> 8 - Use of undefined constant location - assumed 'location' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
Error - 2013-01-09 16:12:06 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
Error - 2013-01-09 16:12:06 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
Error - 2013-01-09 16:12:06 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 87
Warning - 2013-01-09 16:12:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:12:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:14:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:14:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:14:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:14:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:14:38 --> 8 - Use of undefined constant location - assumed 'location' in C:\wamp\fuel\app\classes\model\mapgen.php on line 56
Error - 2013-01-09 16:14:38 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 75
Error - 2013-01-09 16:14:38 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 75
Error - 2013-01-09 16:14:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 80
Warning - 2013-01-09 16:14:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:14:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:15:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:15:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:15:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 16:15:16 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 75
Error - 2013-01-09 16:15:16 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 75
Error - 2013-01-09 16:15:16 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 80
Warning - 2013-01-09 16:15:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:15:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:15:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:15:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:15:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:15:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:15:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:18:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:18:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:18:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:18:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:18:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:18:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:18:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:18:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:18:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:18:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:19:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:19:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:19:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:19:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:19:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:19:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:19:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:19:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:19:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:23:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:23:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:23:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:23:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:23:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:23:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:23:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:37:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:37:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:37:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:37:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:37:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:42:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:42:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:42:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:42:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:44:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:44:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:44:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:44:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:44:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:45:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:45:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:46:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:46:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:46:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:46:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:46:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:46:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:46:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:46:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:48:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:48:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:48:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:48:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:48:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:48:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:48:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:49:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:49:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:49:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:49:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:49:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:49:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:49:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:49:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:50:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:50:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:50:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:51:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:51:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:51:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:51:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:51:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:52:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:52:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:52:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:52:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:52:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:52:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:52:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:52:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:52:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:52:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:52:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:53:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:53:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:53:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:53:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:53:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:53:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:53:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:53:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:53:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:54:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:54:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:54:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:54:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:54:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:54:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:54:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:54:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:54:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:54:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:54:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:55:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:55:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:55:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:55:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:55:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:55:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:57:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:57:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:57:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:57:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:57:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:57:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:57:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:57:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:57:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:57:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:57:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:57:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:57:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:57:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:58:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:58:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:58:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:58:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:58:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:58:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:58:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:58:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:58:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:58:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:58:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 16:59:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 16:59:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 16:59:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:00:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:00:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:00:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:00:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:00:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:00:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:00:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:00:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:02:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:02:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:02:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:02:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:02:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:02:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:02:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:02:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:03:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:03:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:03:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:03:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:03:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:03:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:03:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:03:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:04:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:04:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:04:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:04:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:04:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:04:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:04:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:04:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:05:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:05:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:05:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:05:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:05:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:05:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:05:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:05:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:05:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:05:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:21:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 17:21:47 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-01-09 17:21:47 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 32
Error - 2013-01-09 17:21:47 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
Warning - 2013-01-09 17:21:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:21:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:21:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 17:22:51 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-01-09 17:22:51 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'glebe' in 'where clause' with query: "SELECT * FROM `images` WHERE `location`=glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 17:22:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 17:23:19 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Warning - 2013-01-09 17:23:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:23:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:23:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:23:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:23:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:23:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:23:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:23:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:23:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:25:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:25:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:25:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:36:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:36:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:36:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:36:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:36:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:37:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:37:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:38:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:38:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:38:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:38:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 17:49:38 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-01-09 17:49:38 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-01-09 17:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:51:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:51:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:52:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:52:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:52:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:52:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:52:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:52:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:52:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 17:52:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 17:52:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 17:52:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:07:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:07:25 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-01-09 18:07:25 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:07:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:08:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:08:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:08:10 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-01-09 18:08:10 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:08:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:09:35 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-01-09 18:09:35 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:09:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:09:37 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-01-09 18:09:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:12:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:12:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:12:12 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0,8' at line 1 with query: "SELECT * FROM `images` order by idlimit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:12:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:12:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:12:27 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0,8' at line 1 with query: "SELECT * FROM `images` order by idlimit 0,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:12:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:13:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:13:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:13:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:13:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:13:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:13:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:13:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:13:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:14:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:14:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:14:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:14:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:14:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:14:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:14:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:14:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:14:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:16:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:16:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:16:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:16:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:16:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:16:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:16:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:16:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:17:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:17:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:18:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:18:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:18:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:19:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:19:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:19:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:19:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:19:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:19:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:22:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:22:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:27:41 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:27:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:27:55 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:27:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:28:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:28:16 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe'' at line 1 with query: "SELECT * FROM `images` WHERE `location`="glebe'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:28:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:28:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:28:46 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Error - 2013-01-09 18:28:46 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Error - 2013-01-09 18:28:46 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Warning - 2013-01-09 18:28:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:28:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:28:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:29:01 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Error - 2013-01-09 18:29:01 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Error - 2013-01-09 18:29:01 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Warning - 2013-01-09 18:29:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:29:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:29:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:29:07 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Error - 2013-01-09 18:29:07 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Error - 2013-01-09 18:29:07 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 39
Warning - 2013-01-09 18:29:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:29:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:34:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:34:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:34:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:39:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:39:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:40:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:40:07 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 42
Error - 2013-01-09 18:40:07 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 51
Error - 2013-01-09 18:40:07 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
Error - 2013-01-09 18:40:07 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
Error - 2013-01-09 18:40:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 58
Warning - 2013-01-09 18:40:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:40:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:40:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:40:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:40:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:40:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:40:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:40:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:40:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:41:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:41:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:41:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:41:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:42:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:42:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:42:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:43:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:43:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:43:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:43:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:43:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:43:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:43:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:43:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:43:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:43:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:44:42 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:44:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:44:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:44:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:44:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:45:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:45:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:45:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 18:46:37 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2013-01-09 18:46:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-01-09 18:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:46:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:46:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:46:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:50:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:50:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:50:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:51:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:51:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 18:57:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 18:57:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 18:57:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:06:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:06:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:06:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:06:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:06:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:06:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:06:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:06:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:07:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:07:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:07:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:07:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:12:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:12:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:12:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:12:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:12:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:12:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:12:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:12:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:12:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:12:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:12:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:13:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:13:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:13:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:13:32 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Warning - 2013-01-09 19:13:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:13:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:13:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:13:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:13:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:13:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:13:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:14:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:14:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Error - 2013-01-09 19:14:21 --> 8 - Undefined offset: 11 in C:\wamp\fuel\app\views\listings\listings.php on line 38
Warning - 2013-01-09 19:14:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:14:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:14:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:14:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:14:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:14:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:14:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:15:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:15:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:15:13 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Warning - 2013-01-09 19:15:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:15:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:15:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:15:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:15:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:15:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:16:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:16:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:16:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:16:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:16:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:16:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:16:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:17:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:17:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:17:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
Warning - 2013-01-09 19:17:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:17:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:17:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:17:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:17:29 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
Warning - 2013-01-09 19:17:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:17:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:17:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:28:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:28:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:28:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:28:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:28:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:28:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:50:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:50:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:50:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:50:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:50:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:50:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:50:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:50:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:50:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:50:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:50:29 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
Warning - 2013-01-09 19:50:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:50:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:50:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:51:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:51:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:51:33 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 37
Warning - 2013-01-09 19:51:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:51:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-09 19:51:45 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 37
Warning - 2013-01-09 19:51:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:52:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:52:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:52:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:52:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:52:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:52:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:52:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:52:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:53:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:53:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:53:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:53:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:53:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:53:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:53:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:53:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:53:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 19:53:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 19:53:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 19:53:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 20:16:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:16:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:16:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 20:16:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 20:16:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:16:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:16:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 20:16:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 20:16:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:16:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 20:16:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 20:33:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:33:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-09 20:33:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-09 20:33:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-09 20:33:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
