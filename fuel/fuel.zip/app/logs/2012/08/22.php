<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-22 00:04:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 00:10:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 19:32:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 19:34:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 19:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 19:35:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 19:40:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 19:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:21:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 20:21:50 --> Error - The requested view could not be found: about in C:\wamp\fuel\core\classes\view.php on line 389
Warning - 2012-08-22 20:22:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 20:22:10 --> 2 - The use statement with non-compound name 'Model' has no effect in C:\wamp\fuel\app\classes\controller\showlistings.php on line 3
Error - 2012-08-22 20:22:10 --> Parsing Error - syntax error, unexpected '/', expecting ',' or ';' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 3
Warning - 2012-08-22 20:22:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 20:22:15 --> 2 - The use statement with non-compound name 'Model' has no effect in C:\wamp\fuel\app\classes\controller\showlistings.php on line 3
Error - 2012-08-22 20:22:15 --> Parsing Error - syntax error, unexpected '/', expecting ',' or ';' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 3
Warning - 2012-08-22 20:22:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 20:22:34 --> Parsing Error - syntax error, unexpected T_CLASS, expecting ',' or ';' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 5
Warning - 2012-08-22 20:25:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:26:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:26:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:26:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:26:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:27:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 20:27:03 --> Error - The requested view could not be found: about in C:\wamp\fuel\core\classes\view.php on line 389
Warning - 2012-08-22 20:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:27:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:32:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:36:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:40:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:46:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:47:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:47:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:47:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:47:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:48:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 20:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:21:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:21:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:21:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:22:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:22:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:23:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:27:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 21:27:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:27:20 --> Error - Class 'Controller_ShowListings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 21:28:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:28:00 --> Error - Class 'Controller_showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 21:28:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:28:27 --> Error - Class 'Controller_showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 21:28:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:28:29 --> Error - Class 'Controller_showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 21:28:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:28:30 --> Error - Class 'Controller_showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 21:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:28:41 --> Error - Class 'Controller_Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 21:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 21:28:42 --> Error - Class 'Controller_Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 22:25:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 22:25:10 --> Error - Class 'Controller_Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 22:25:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 22:25:11 --> Error - Class 'Controller_Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 22:25:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 22:25:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 22:25:23 --> Error - Class 'Controller_Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 22:25:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 22:25:28 --> Error - Class 'Controller_Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 6
Warning - 2012-08-22 22:27:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 22:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 22:27:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 22:27:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:10:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:11:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:11:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:11:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:11:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:12:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:12:53 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:12:53 --> Error - Class 'Model\showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:09 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:09 --> Error - Class 'Model\showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:11 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:11 --> Error - Class 'Model\showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:11 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:11 --> Error - Class 'Model\showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:54 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:54 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:55 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:55 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:55 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:55 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:13:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:13:56 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:13:56 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:21:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:21:39 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:21:39 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:21:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:21:40 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:21:40 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:22:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:22:40 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:22:40 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:22:41 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:22:41 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:22:41 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:22:41 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:24:59 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:24:59 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:25:00 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:25:00 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:25:00 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:25:00 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:25:01 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:25:01 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:25:01 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:25:01 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:25:01 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:25:01 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:26:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:26:27 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:26:27 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:26:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:26:28 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:26:28 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:26:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:26:28 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:26:28 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:26:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:28:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:28:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:28:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:28:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:30:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:30:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:30:08 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:30:08 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:30:08 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:30:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:30:27 --> Parsing Error - syntax error, unexpected T_NS_SEPARATOR in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:30:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:30:36 --> Parsing Error - syntax error, unexpected '.' in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:30:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:30:44 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:31:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:31:00 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:31:00 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:31:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:31:06 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:31:06 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:31:06 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:32:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:32:49 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:32:49 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:32:49 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:32:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:32:50 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:32:50 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:32:50 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:32:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:32:51 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:32:51 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:32:51 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:32:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:32:59 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:32:59 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:32:59 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:33:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:33:00 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:33:00 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:33:00 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:33:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:33:00 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:33:00 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:33:00 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:33:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:33:00 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:33:00 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:33:00 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:33:01 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:33:01 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:33:01 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:33:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:33:50 --> Error - Undefined constant 'Model\Orm\Model' in C:\wamp\fuel\app\classes\model\showlistings.php on line 4
Warning - 2012-08-22 23:34:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:34:15 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:34:15 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:34:29 --> Error - Undefined constant 'Model\Orm\Model' in C:\wamp\fuel\app\classes\model\showlistings.php on line 4
Warning - 2012-08-22 23:34:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:34:45 --> Error - Class 'Orm' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:34:53 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:34:53 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:34:53 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:36:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:36:12 --> Error - Class 'Model\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:36:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:36:13 --> Error - Class 'Model\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:36:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:36:24 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:36:24 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:37:13 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:37:13 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:37:16 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:37:16 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:37:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:37:17 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:37:17 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:37:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:37:17 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Error - 2012-08-22 23:37:17 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:38:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:11 --> Parsing Error - syntax error, unexpected '/', expecting T_NS_SEPARATOR or ';' or '{' in C:\wamp\fuel\app\classes\model\showlistings.php on line 3
Warning - 2012-08-22 23:38:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:12 --> Parsing Error - syntax error, unexpected '/', expecting T_NS_SEPARATOR or ';' or '{' in C:\wamp\fuel\app\classes\model\showlistings.php on line 3
Warning - 2012-08-22 23:38:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:28 --> Error - Class 'Orm\Model\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:38:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:29 --> Error - Class 'Orm\Model\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:38:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:44 --> Parsing Error - syntax error, unexpected '{', expecting T_STRING or T_NAMESPACE or T_NS_SEPARATOR in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:38:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:52 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:38:52 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:38:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:38:54 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:38:54 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:39:22 --> Error - Class 'Orm\Model\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:39:30 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:39:30 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:39:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:39:42 --> Error - Class 'Model\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:40:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:40:02 --> Parsing Error - syntax error, unexpected '{', expecting T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:40:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:40:08 --> Error - Class 'Model\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 6
Warning - 2012-08-22 23:40:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:40:19 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2012-08-22 23:40:19 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2012-08-22 23:40:19 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Warning - 2012-08-22 23:40:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:40:30 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:40:30 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:40:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:40:44 --> Error - Undefined constant 'Model' in C:\wamp\fuel\app\classes\model\showlistings.php on line 3
Warning - 2012-08-22 23:41:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:41:02 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:41:02 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:41:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:41:09 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:41:09 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2012-08-22 23:41:09 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:42:49 --> Error - Class 'Orm\Orm\Model' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 7
Warning - 2012-08-22 23:42:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:42:59 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:42:59 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:43:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:43:01 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:43:01 --> Error - Class 'Model\Showlistings' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 9
Warning - 2012-08-22 23:43:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:43:10 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 27
Error - 2012-08-22 23:43:10 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Error - 2012-08-22 23:43:10 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 18
Warning - 2012-08-22 23:44:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:44:30 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:44:30 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2012-08-22 23:44:30 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:44:32 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:44:32 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2012-08-22 23:44:32 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:44:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:44:45 --> Parsing Error - syntax error, unexpected T_PAAMAYIM_NEKUDOTAYIM in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:44:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:44:53 --> Parsing Error - syntax error, unexpected '.' in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:45:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:45:02 --> Parsing Error - syntax error, unexpected '/' in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:45:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:45:08 --> Parsing Error - syntax error, unexpected T_NS_SEPARATOR, expecting T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:45:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:45:13 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2012-08-22 23:45:13 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2012-08-22 23:45:13 --> Error - Class 'Model\DB' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 17
Warning - 2012-08-22 23:45:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:45:26 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 27
Error - 2012-08-22 23:45:26 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
Error - 2012-08-22 23:45:26 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-22 23:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:45:43 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 27
Error - 2012-08-22 23:45:43 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-22 23:45:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:45:46 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 27
Error - 2012-08-22 23:45:46 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-22 23:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:46:13 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:46:13 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-22 23:46:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:46:14 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:46:14 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1327 Undeclared variable: $start with query: "SELECT * FROM `images` limit $start,$per_page" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-22 23:46:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:46:51 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 29
Error - 2012-08-22 23:46:51 --> Error - Class 'Model\View' not found in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
Warning - 2012-08-22 23:47:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:47:08 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 31
Error - 2012-08-22 23:47:08 --> Error - The requested view could not be found: showlistings/showlistings in C:\wamp\fuel\core\classes\view.php on line 389
Warning - 2012-08-22 23:47:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:47:24 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 31
Warning - 2012-08-22 23:47:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-22 23:47:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-22 23:50:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:46 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Warning - 2012-08-22 23:50:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:50:59 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:51:16 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\arr.php on line 58
Warning - 2012-08-22 23:51:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:51:27 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2012-08-22 23:51:27 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:51:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Warning - 2012-08-22 23:51:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-22 23:51:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Error - 2012-08-22 23:51:29 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\config.php on line 170
Warning - 2012-08-22 23:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:55:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:55:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:56:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-22 23:59:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-22 23:59:36 --> 8 - Undefined variable: i in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Error - 2012-08-22 23:59:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 28
Warning - 2012-08-22 23:59:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-22 23:59:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
