<?php
/**
 * The development database settings.
 */

return array(
	'default' => array(
		'connection'  => array(
			'dsn'        => 'mysql:host=localhost;dbname=rentsignal',
			'username'   => 'root',
			'password'   => 'pass',
		),
	),
);
