<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-02-12 21:33:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-02-12 21:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
