<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2014-11-22 22:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-22 23:13:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-22 23:52:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-22 23:52:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-22 23:52:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-22 23:59:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
