<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-07-28 21:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 21:44:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 21:44:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 21:44:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 21:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-07-28 21:44:45 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-07-28 21:44:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:49 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-07-28 21:44:49 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-07-28 21:44:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 21:44:57 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-07-28 21:44:57 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-07-28 21:44:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:44:57 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-07-28 21:47:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 21:47:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:25:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:25:46 --> Parsing Error - syntax error, unexpected T_STRING, expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:27:04 --> Parsing Error - syntax error, unexpected T_STRING, expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:28:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:28:06 --> Parsing Error - syntax error, unexpected T_STRING, expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:28:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:28:15 --> Parsing Error - syntax error, unexpected T_STRING, expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:29:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:29:43 --> Parsing Error - syntax error, unexpected T_STRING, expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:30:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:30:03 --> Error - Call to undefined method Model\ShowListings::favpop_results() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 33
Warning - 2014-07-28 22:30:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:30:56 --> Error - Call to undefined function Model\return_imagedata() in C:\wamp\fuel\app\classes\model\showlistings.php on line 104
Warning - 2014-07-28 22:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:31:46 --> Error - Call to undefined function Model\return_imagedata() in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:32:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:32:07 --> Error - Call to undefined function Model\return_imagedata() in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:32:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:32:26 --> 8 - Use of undefined constant return_imagedata - assumed 'return_imagedata' in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:32:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:32:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:32:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:32:49 --> Parsing Error - syntax error, unexpected ';', expecting '{' in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:32:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:32:58 --> Parsing Error - syntax error, unexpected ';', expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:33:01 --> Parsing Error - syntax error, unexpected ';', expecting '(' in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:33:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:33:14 --> 8 - Use of undefined constant return_imagedata - assumed 'return_imagedata' in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:33:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:33:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:36:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:36:24 --> Error - Call to undefined function Model\return_imagedata() in C:\wamp\fuel\app\classes\model\showlistings.php on line 104
Warning - 2014-07-28 22:36:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:36:37 --> 8 - Use of undefined constant return_imagedata - assumed 'return_imagedata' in C:\wamp\fuel\app\classes\model\showlistings.php on line 104
Error - 2014-07-28 22:36:37 --> 8 - Undefined variable: returnfavs in C:\wamp\fuel\app\classes\model\showlistings.php on line 105
Warning - 2014-07-28 22:36:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:36:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:37:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:37:50 --> Error - Call to undefined function Model\return_imagedata() in C:\wamp\fuel\app\classes\model\showlistings.php on line 80
Warning - 2014-07-28 22:40:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\showlistings.php on line 81
Error - 2014-07-28 22:40:18 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 81
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 87
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 88
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 89
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 91
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 92
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 92
Error - 2014-07-28 22:40:18 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 103
Warning - 2014-07-28 22:40:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:40:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:40:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:40:57 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 81
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 85
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 86
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\classes\model\showlistings.php on line 88
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 89
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:40:57 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:40:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:40:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:41:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:41:02 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 81
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 85
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 86
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\classes\model\showlistings.php on line 88
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 89
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:41:02 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:41:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:41:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:41:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:41:33 --> 1054 - Unknown column 'favstars' in 'where clause' [ SELECT * FROM `images` WHERE favstars BETWEEN  5  AND  10 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-07-28 22:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 85
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 86
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\classes\model\showlistings.php on line 88
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 89
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 90
Error - 2014-07-28 22:42:35 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 101
Warning - 2014-07-28 22:42:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:42:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 85
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\classes\model\showlistings.php on line 87
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 88
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 89
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 89
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2014-07-28 22:43:22 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 29
Warning - 2014-07-28 22:43:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:43:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:44:27 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2014-07-28 22:44:27 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 23
Error - 2014-07-28 22:44:27 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 29
Warning - 2014-07-28 22:44:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:44:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:44:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:44:31 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2014-07-28 22:44:31 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 23
Error - 2014-07-28 22:44:31 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 29
Warning - 2014-07-28 22:44:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:44:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:44:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:44:33 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2014-07-28 22:44:33 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 23
Error - 2014-07-28 22:44:33 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 29
Warning - 2014-07-28 22:44:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:44:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:48:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:48:41 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\classes\model\showlistings.php on line 92
Error - 2014-07-28 22:48:41 --> 8 - Undefined index:  in C:\wamp\fuel\app\classes\model\showlistings.php on line 92
Error - 2014-07-28 22:48:41 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2014-07-28 22:48:41 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 23
Warning - 2014-07-28 22:48:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:48:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:50:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:50:57 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2014-07-28 22:50:57 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 23
Error - 2014-07-28 22:50:57 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2014-07-28 22:50:57 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2014-07-28 22:50:57 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 31
Error - 2014-07-28 22:50:57 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\views\listings\listings.php on line 31
Warning - 2014-07-28 22:50:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:50:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:52:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:52:07 --> Parsing Error - syntax error, unexpected T_LNUMBER, expecting ',' or ';' in C:\wamp\fuel\app\views\listings\favourites.php on line 31
Warning - 2014-07-28 22:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-07-28 22:53:05 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\favourites.php on line 3
Warning - 2014-07-28 22:53:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:53:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:56:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:56:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:56:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:56:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:56:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:56:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:56:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:56:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:56:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:57:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:57:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:57:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:57:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:57:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:57:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:57:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 22:57:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 22:57:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 22:57:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:01:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:01:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:01:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:02:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:02:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:03:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:03:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:05:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:05:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:05:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:05:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:05:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:05:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:05:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:05:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:05:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:05:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:05:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:05:44 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-07-28 23:05:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:06:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:06:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:06:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:06:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:06:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:06:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:06:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:06:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:08:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:09:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:09:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:09:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:09:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:09:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:09:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:09:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:10:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:10:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:10:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:11:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:11:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:11:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:11:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:12:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:12:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:12:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:12:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:13:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:13:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:13:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:13:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:13:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:13:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:13:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:13:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:13:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:13:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:17:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:17:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:17:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:17:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:17:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:18:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:18:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-07-28 23:18:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-07-28 23:18:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-07-28 23:18:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
