<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-10-23 20:38:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:38:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:40:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:40:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:40:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:40:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:42:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:42:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:42:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:42:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:42:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:42:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:42:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:42:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:43:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:43:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:43:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:43:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:45:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:45:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:45:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:45:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:45:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:46:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:46:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:46:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:46:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:46:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:47:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:47:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:47:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:47:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:47:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:50:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:50:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:50:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:50:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:50:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:51:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:51:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:51:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:51:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:51:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:51:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:52:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:52:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:52:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:52:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:52:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:53:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:53:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:53:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:53:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:53:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:57:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:57:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:57:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:57:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:57:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:57:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 20:57:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 20:57:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 20:58:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:02:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:02:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:03:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:03:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:04:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:04:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:04:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:04:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:04:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:05:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:05:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:05:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:05:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:05:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:11:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:11:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:11:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:11:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:11:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:12:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:12:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:17:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:17:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:17:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:17:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:19:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:19:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:19:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:19:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:19:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:19:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:20:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:20:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:20:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:20:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:20:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:20:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:20:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:20:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:21:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:21:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:21:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:21:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:22:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:22:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:22:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:22:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:24:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:24:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:25:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:25:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:25:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:25:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:25:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:25:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:25:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:25:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:26:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:26:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:26:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:26:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:26:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:27:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:27:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:27:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:27:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:29:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:29:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:29:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:29:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:29:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:30:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:30:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:30:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:30:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:30:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:30:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:30:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:30:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:31:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:31:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:31:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:31:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:32:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:32:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:32:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:32:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:32:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:32:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:32:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:32:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:32:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:35:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:35:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:35:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:35:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:35:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:35:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:35:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:36:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:36:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:36:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:37:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:37:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:37:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:40:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:40:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:40:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:40:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:40:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:41:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:41:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:42:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:42:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:42:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:43:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:43:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:43:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:43:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:43:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:44:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:44:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:44:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:44:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:45:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:45:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:45:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:45:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:45:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:47:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:47:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:47:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:47:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:47:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:47:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:48:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:48:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:48:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:48:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 21:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 21:49:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 21:49:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:04:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:04:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:04:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:09:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:09:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:09:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:10:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:10:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:10:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:16:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:16:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:16:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:16:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:16:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:17:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:17:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:17:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:17:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:17:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:19:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:19:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:19:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:19:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:19:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:19:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:21:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:21:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:21:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:21:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:21:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:21:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:21:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:22:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:22:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:22:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:22:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:22:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:30:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:30:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:30:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:30:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:30:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:31:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:31:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:31:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:31:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:31:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:32:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:32:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:32:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:32:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:32:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:33:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:33:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:33:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:33:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:33:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:33:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:33:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:33:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:38:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:51:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:51:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:51:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:51:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:51:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:51:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:53:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:53:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:53:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:53:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:53:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:54:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:54:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:54:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:54:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:54:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:54:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:54:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:54:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 22:54:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 22:57:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 22:57:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:01:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:01:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:02:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:02:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:02:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:02:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:02:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:02:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:02:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:02:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:02:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:03:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:04:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:04:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:04:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:06:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:06:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:06:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:08:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:08:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:09:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:09:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:10:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:10:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:10:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:10:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:10:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:10:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:10:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:10:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:11:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:11:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:11:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:11:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:11:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:12:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:12:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:20:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:20:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:20:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:20:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:21:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:21:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:21:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:21:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:21:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:22:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:22:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:22:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:22:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:22:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:23:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:23:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:23:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:23:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:23:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:23:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:23:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:23:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:23:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:23:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:23:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:23:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:24:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:24:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:24:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:24:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:24:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:25:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:25:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:25:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:25:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:25:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:26:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:26:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:26:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:26:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:26:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:27:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:27:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:27:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:27:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:27:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:30:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:30:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:30:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:30:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:30:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:30:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:30:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:30:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:30:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:31:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:34:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:34:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:34:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:35:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:35:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:38:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:38:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:39:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:39:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:39:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:41:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:41:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:41:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:42:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:42:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:42:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:42:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:42:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:43:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:43:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:43:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:43:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:47:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:47:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:47:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:47:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:47:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:47:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:48:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:48:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:48:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:48:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:49:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:49:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:49:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:49:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:49:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:51:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:51:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:51:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:51:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:51:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:52:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:52:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:52:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:52:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:52:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:54:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:54:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:54:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:54:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:54:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:55:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:55:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:55:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:55:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:55:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:55:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:55:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:55:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:55:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:56:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:56:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:56:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:56:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:56:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:56:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-23 23:57:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-23 23:57:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-23 23:57:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
