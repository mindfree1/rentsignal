<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-05-15 21:58:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:58:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:58:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 21:58:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 21:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:58:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:58:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 21:59:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 21:59:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 21:59:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 21:59:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:24:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:24:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:24:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:24:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:24:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:24:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:24:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:24:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:24:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:24:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:25:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:25:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:25:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:26:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:26:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:26:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:26:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:26:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:31:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:20 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:20 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:40 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:40 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:42 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:42 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:42 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:42 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:43 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:43 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:31:43 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:31:43 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:31:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:33:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:33:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:33:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:33:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:33:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:33:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:33:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:33:25 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Error - 2013-05-15 22:33:25 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
Warning - 2013-05-15 22:33:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:33:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:35:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:35:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:35:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:35:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:37:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:37:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:38:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:38:05 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Error - 2013-05-15 22:38:05 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Warning - 2013-05-15 22:38:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:38:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:39:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:39:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:39:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:39:16 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 45
Warning - 2013-05-15 22:39:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:39:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:39:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:39:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:39:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:39:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:40:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:40:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:40:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:40:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:40:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:40:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:40:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:40:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:40:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:40:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:41:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:41:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:41:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:41:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:41:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:42:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:42:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:43:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:43:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:43:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:43:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:44:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:44:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:44:10 --> Error - SQLSTATE[23000]: Integrity constraint violation: 1052 Column 'location' in where clause is ambiguous with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE `location`="glebe"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-15 22:44:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:44:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:45:04 --> Error - SQLSTATE[23000]: Integrity constraint violation: 1052 Column 'location' in where clause is ambiguous with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE `location`=glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-15 22:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:47:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:47:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:47:33 --> Error - SQLSTATE[23000]: Integrity constraint violation: 1052 Column 'location' in where clause is ambiguous with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE `location`="glebe"" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-15 22:47:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:47:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:48:13 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"glebe' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE `location`="glebe" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-15 22:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:48:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:48:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:48:56 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"'glebe'' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE `location`="'glebe'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-15 22:48:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:48:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:49:32 --> Error - SQLSTATE[23000]: Integrity constraint violation: 1052 Column 'location' in where clause is ambiguous with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE `location`='glebe'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-05-15 22:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:50:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:50:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:50:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:50:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:50:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:50:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:53:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:53:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:53:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:53:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:53:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:53:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:54:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:54:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:54:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:54:53 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Warning - 2013-05-15 22:54:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:54:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:55:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:55:06 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Warning - 2013-05-15 22:55:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:55:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:55:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:55:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:55:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:56:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 22:56:01 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\mapgen.php on line 50
Warning - 2013-05-15 22:56:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:56:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:57:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:57:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:57:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:57:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 22:57:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:57:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:57:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 22:57:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 22:57:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:01:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:01:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:01:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:01:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:01:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:01:15 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\mapgen.php on line 46
Warning - 2013-05-15 23:01:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:01:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:02:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:02:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:02:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:02:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:02:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:02:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:03:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:03:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:03:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:03:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:04:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:04:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:10:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:10:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:10:58 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 38
Error - 2013-05-15 23:10:58 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 38
Error - 2013-05-15 23:10:58 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 43
Warning - 2013-05-15 23:10:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:10:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:11:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:11:05 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\mapgen.php on line 38
Error - 2013-05-15 23:11:05 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\mapgen.php on line 38
Error - 2013-05-15 23:11:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 43
Warning - 2013-05-15 23:11:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:11:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:12:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:12:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:12:14 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 33
Error - 2013-05-15 23:12:14 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 33
Warning - 2013-05-15 23:12:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:12:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:13:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:13:11 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 33
Error - 2013-05-15 23:13:11 --> 8 - Undefined index: url in C:\wamp\fuel\app\classes\model\mapgen.php on line 33
Warning - 2013-05-15 23:13:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:13:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:13:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:13:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:13:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:13:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:19:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:19:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:19:21 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:19:21 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:19:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:19:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:19:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:19:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:19:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:21:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:21:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:21:07 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Error - 2013-05-15 23:21:07 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-15 23:21:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:21:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:21:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:21:59 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:21:59 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:21:59 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:21:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:21:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:22:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:22:08 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Error - 2013-05-15 23:22:08 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-15 23:22:08 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:22:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:22:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:23:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:23:03 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:23:03 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:23:03 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:23:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:23:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:23:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:23:13 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-15 23:23:13 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:23:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:23:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:24:51 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:24:51 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:24:51 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:24:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:24:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:26:04 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:26:04 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:26:04 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:26:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:26:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:26:11 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-15 23:26:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:26:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:26:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:26:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:26:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:26:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:29:52 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:29:52 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:29:52 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 59
Warning - 2013-05-15 23:29:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:29:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:30:45 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:30:45 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-05-15 23:30:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-05-15 23:30:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:30:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:30:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:30:57 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-05-15 23:30:57 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-05-15 23:30:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:30:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:32:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:32:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:32:01 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:32:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Warning - 2013-05-15 23:32:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:32:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:32:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:32:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:33:01 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:01 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Warning - 2013-05-15 23:33:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:33:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:33:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:33:29 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:33:29 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Warning - 2013-05-15 23:33:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:33:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:36:42 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Error - 2013-05-15 23:36:42 --> 8 - Undefined variable: newdata in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
Warning - 2013-05-15 23:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:36:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:36:52 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-15 23:36:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:36:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:37:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:37:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:37:31 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-05-15 23:37:31 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-05-15 23:37:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:37:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:38:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:38:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:38:15 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2013-05-15 23:38:15 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-05-15 23:38:15 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-05-15 23:38:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:38:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:39:57 --> 8 - Undefined variable: somedata in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2013-05-15 23:39:57 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-05-15 23:39:57 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-05-15 23:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:40:16 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Error - 2013-05-15 23:40:16 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-05-15 23:40:16 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2013-05-15 23:40:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:40:27 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 12
Warning - 2013-05-15 23:40:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:40:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:40:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:40:53 --> 8 - Undefined variable: somedata in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Warning - 2013-05-15 23:40:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:40:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:40:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:42:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:42:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:42:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:42:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:42:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:42:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:42:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:42:26 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 37
Error - 2013-05-15 23:42:26 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 37
Error - 2013-05-15 23:42:26 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-15 23:42:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:42:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:42:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:42:40 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 37
Error - 2013-05-15 23:42:40 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\mapgen.php on line 37
Error - 2013-05-15 23:42:40 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-15 23:42:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:42:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:44:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:44:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:44:39 --> 8 - Undefined variable: somedata in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Error - 2013-05-15 23:44:39 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-05-15 23:44:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:44:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:45:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:45:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-05-15 23:45:51 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 60
Warning - 2013-05-15 23:45:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:45:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:45:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:46:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-05-15 23:46:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-05-15 23:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-05-15 23:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
