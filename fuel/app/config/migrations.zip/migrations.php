<?php
return array(
	'version' => 
	array(
		'app' => 
		array(
			'default' => 1,
		),
		'module' => 
		array(
		),
		'package' => 
		array(
		),
	),
	'folder' => 'migrations/',
	'table' => 'migration',
);
