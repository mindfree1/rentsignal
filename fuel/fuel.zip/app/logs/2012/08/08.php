<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-08 11:30:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 11:30:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 11:31:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 11:34:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 11:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 12:21:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 12:53:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:53:34 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Warning - 2012-08-08 12:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:54:03 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:03 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:03 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:03 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:03 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-08-08 12:54:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:54:07 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:07 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:07 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:07 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:07 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:33 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\bootstrap.php on line 45
Error - 2012-08-08 12:54:37 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\classes\arr.php on line 59
Warning - 2012-08-08 12:54:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:54:46 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:46 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:46 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:54:46 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:54:46 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:16 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\classes\error.php on line 119
Warning - 2012-08-08 12:55:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:55:48 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:48 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:48 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:55:48 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:55:48 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-08-08 12:56:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:56:04 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Warning - 2012-08-08 12:56:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:56:06 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\wamp\www\fuel\app\views\listings\listings.php on line 15
Error - 2012-08-08 12:56:18 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\classes\config.php on line 170
Warning - 2012-08-08 12:58:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:58:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-08-08 12:59:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:59:22 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\fuel\app\views\listings\listings.php on line 16
Error - 2012-08-08 12:59:25 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\classes\arr.php on line 41
Warning - 2012-08-08 12:59:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:40 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-08-08 12:59:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 12:59:55 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:10 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\classes\fuel.php on line 611
Error - 2012-08-08 13:00:24 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\bootstrap.php on line 45
Warning - 2012-08-08 13:00:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: urm in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 13:00:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-08-08 13:00:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 13:01:07 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\www\fuel\core\classes\config.php on line 176
Warning - 2012-08-08 13:01:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:02:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:03:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:06:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:07:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:07:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 13:12:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:03:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:03:01 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Error - 2012-08-08 15:03:01 --> 8 - Undefined index: url in C:\wamp\www\fuel\core\classes\database\result\cached.php on line 48
Warning - 2012-08-08 15:04:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:04:13 --> Parsing Error - syntax error, unexpected '}' in C:\wamp\www\fuel\app\views\listings\listings.php on line 20
Warning - 2012-08-08 15:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:04:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:05:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:06:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:06:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:06:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:07:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Error - 2012-08-08 15:07:23 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 10
Warning - 2012-08-08 15:07:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:08:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:17:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:18:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:18:48 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\fuel\app\views\listings\listings.php on line 18
Warning - 2012-08-08 15:19:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:22:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:23:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:23:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:25:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:26:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:31:57 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\www\fuel\app\views\listings\listings.php on line 45
Warning - 2012-08-08 15:32:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:32:08 --> Error - Call to undefined method Fuel\Core\Database_Result_Cached::limit() in C:\wamp\www\fuel\app\views\listings\listings.php on line 45
Warning - 2012-08-08 15:32:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:32:47 --> Error - Call to undefined method Fuel\Core\Database_Result_Cached::limit() in C:\wamp\www\fuel\app\views\listings\listings.php on line 45
Warning - 2012-08-08 15:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:34:02 --> Error - Call to undefined method Fuel\Core\Database_Query::limit() in C:\wamp\www\fuel\app\views\listings\listings.php on line 45
Warning - 2012-08-08 15:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:35:44 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1103 Incorrect table name '' with query: "SELECT * FROM ``images`` LIMIT 8 OFFSET 0" in C:\wamp\www\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-08 15:36:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:36:06 --> Error - Using $this when not in object context in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 15:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:37:12 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 15:37:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:37:26 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 15:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:37:27 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 15:37:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:37:33 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 15:37:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:37:48 --> Error - Maximum function nesting level of '100' reached, aborting! in C:\wamp\www\fuel\core\classes\asset.php on line 319
Warning - 2012-08-08 15:38:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:38:02 --> Error - Maximum function nesting level of '100' reached, aborting! in C:\wamp\www\fuel\core\classes\asset.php on line 319
Warning - 2012-08-08 15:38:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:38:13 --> Error - Using $this when not in object context in C:\wamp\www\fuel\app\views\listings\listings.php on line 52
Warning - 2012-08-08 15:38:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:38:21 --> Error - Maximum function nesting level of '100' reached, aborting! in C:\wamp\www\fuel\core\classes\request.php on line 76
Warning - 2012-08-08 15:38:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:39:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:39:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:40:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:43:37 --> 8 - Undefined index: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:43:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:44:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:44:14 --> 8 - Undefined offset: 3 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:44:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:45:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:45:14 --> 8 - Undefined variable: per_page in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:45:14 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:45:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:45:36 --> 8 - Undefined offset: 8 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:45:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:45:47 --> 8 - Undefined offset: 8 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:45:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:45:59 --> 8 - Undefined offset: 2 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:46:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:46:08 --> 8 - Undefined index: 2 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:46:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:46:18 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:47:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:47:50 --> 8 - Undefined offset: 2 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:47:50 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:48:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:48:00 --> 8 - Undefined index: 2 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:48:00 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:48:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:48:10 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:49:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:49:10 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:49:10 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:49:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:49:53 --> Parsing Error - syntax error, unexpected '.' in C:\wamp\www\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-08 15:50:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:50:02 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-08 15:50:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:50:14 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:50:14 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:50:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:50:34 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:50:34 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:50:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:50:43 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:50:43 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:50:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:50:54 --> 8 - Undefined index: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:51:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:51:07 --> 8 - Undefined offset: 1 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:51:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:51:17 --> 8 - Undefined index: 1 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:51:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:51:32 --> 8 - Undefined index: 1 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:51:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:51:43 --> 8 - Undefined offset: 1 in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:52:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:52:00 --> Compile Error - Cannot use [] for reading in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:52:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:52:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:52:59 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:52:59 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:53:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:53:27 --> 8 - Undefined variable: print_r in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:53:27 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:54:06 --> Parsing Error - syntax error, unexpected T_RETURN in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:54:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:54:14 --> Parsing Error - syntax error, unexpected T_RETURN in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:54:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:54:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:54:57 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:56:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:56:14 --> 8 - Array to string conversion in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:56:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:56:37 --> 8 - Array to string conversion in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:58:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 15:58:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:58:24 --> 8 - Undefined index: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:58:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:58:35 --> 8 - Undefined variable: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:58:35 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:58:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 15:58:42 --> 8 - Use of undefined constant url - assumed 'url' in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 15:58:42 --> 8 - Undefined index: url in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 15:59:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:00:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:00:32 --> 8 - Undefined index: id in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Warning - 2012-08-08 16:01:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:01:42 --> 2 - mysql_fetch_array() expects parameter 1 to be resource, array given in C:\wamp\www\fuel\app\views\listings\listings.php on line 50
Warning - 2012-08-08 16:13:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:13:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:41 --> 2 - Illegal offset type in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 16:13:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:13:52 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined index:  in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Error - 2012-08-08 16:13:52 --> 8 - Undefined variable: i in C:\wamp\www\fuel\app\views\listings\listings.php on line 51
Warning - 2012-08-08 16:15:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:15:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:15:39 --> 8 - Use of undefined constant value - assumed 'value' in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:16:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:16:00 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Error - 2012-08-08 16:16:00 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:18:17 --> 8 - Undefined variable: var_dump in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Error - 2012-08-08 16:18:17 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:18:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:18:29 --> 8 - Undefined variable: print_r in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Error - 2012-08-08 16:18:29 --> Error - Function name must be a string in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:20:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:20:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:20:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:20:44 --> 8 - Undefined offset: 3 in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:21:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:21:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:21:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:22:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:24:13 --> 8 - Undefined variable: result in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 16:24:13 --> 2 - Invalid argument supplied for foreach() in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 16:24:13 --> Error - Call to undefined function length() in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:24:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:24:25 --> 8 - Undefined variable: result in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 16:24:25 --> 2 - Invalid argument supplied for foreach() in C:\wamp\www\fuel\app\views\listings\listings.php on line 49
Error - 2012-08-08 16:24:25 --> 8 - Use of undefined constant length - assumed 'length' in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:24:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 16:24:37 --> 8 - Use of undefined constant length - assumed 'length' in C:\wamp\www\fuel\app\views\listings\listings.php on line 53
Warning - 2012-08-08 16:25:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 16:28:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 18:37:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 18:52:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:20:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-08 19:20:14 --> 8 - Undefined variable: data in C:\wamp\www\fuel\app\views\listings\listings.php on line 27
Error - 2012-08-08 19:20:14 --> 2 - Invalid argument supplied for foreach() in C:\wamp\www\fuel\app\views\listings\listings.php on line 27
Error - 2012-08-08 19:20:14 --> 8 - Undefined variable: data in C:\wamp\www\fuel\app\views\listings\listings.php on line 32
Warning - 2012-08-08 19:22:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:23:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:23:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:24:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:24:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:26:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:33:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:33:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:33:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:41:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:42:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:42:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:43:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:56:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:57:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:59:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:59:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:59:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:59:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:59:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 19:59:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 20:04:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 20:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-08 20:12:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
