<div class="hero-unit">
	<h1>Rentsignal Dashboard</h1>
</div>
<div class="row">
	<div class="span-one-third">

	</div>
	<div class="span-one-third">
	</div>
	<div class="span-one-third">
		<ul>
			<p>Content to go here for each indivduals dashboard, could I guess show properties favourited, rental history / payments / budget management for </br>
				utilities as well as enquiries made for properties and responses back from tenants / landlords. </br></br> For landlords it could show info such as 
				rental payments made, enquires sent and any other valuable information for landlords to manage their proeprty and/or properties.
			</p>
		</ul>
	</div>
</div>