<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-07-23 00:01:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-23 00:01:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-23 00:01:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-23 00:01:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-23 00:01:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-23 00:01:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-23 00:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-23 00:02:20 --> Error - Using $this when not in object context in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2013-07-23 00:02:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-23 00:02:38 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR, expecting ',' or ';' in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2013-07-23 00:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-23 00:03:14 --> Error - Using $this when not in object context in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2013-07-23 00:04:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-23 00:04:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-23 00:04:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-23 00:05:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-23 00:05:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-23 00:05:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-23 00:05:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
