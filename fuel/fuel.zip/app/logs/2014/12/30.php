<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2014-12-30 15:52:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 15:52:27 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
WARNING - 2014-12-30 15:52:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 15:52:28 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN ((null)) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 15:52:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 15:52:32 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
WARNING - 2014-12-30 15:52:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 15:52:32 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN ((null)) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 15:52:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 15:52:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 15:52:57 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (('rozelle')) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 15:53:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 15:53:01 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (('glebe')) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 16:05:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 16:06:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 16:06:00 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
WARNING - 2014-12-30 16:06:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 16:06:00 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN ((null)) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:34:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 18:34:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 18:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:52:50 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 18:52:50 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:52:50 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 18:52:50 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:52:50 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:52:50 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:52:50 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 [ 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:52:50 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 18:52:50 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:52:50 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 18:52:50 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:52:50 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:52:50 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:52:51 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 [ 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:52:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:52:58 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 18:52:58 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:52:58 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 18:52:58 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:52:58 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:52:58 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:52:58 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 [ 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:53:05 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:53:05 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 18:53:05 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:53:05 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:53:05 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:53:05 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 [ 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:53:05 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:53:05 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 18:53:05 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:53:05 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:53:05 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:53:05 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 [ 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:53:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:53:09 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:53:09 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 18:53:09 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:53:09 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:53:09 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2014-12-30 18:53:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 [ 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:55:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:55:52 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:55:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:55:52 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:55:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:55:59 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:56:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:56:55 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:56:55 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:56:55 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''AND images.propimg_id =1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:56:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:56:55 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:56:55 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:56:55 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''AND images.propimg_id =1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:56:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:56:59 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:56:59 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:56:59 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''AND images.propimg_id =1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:57:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:57:34 --> Parsing Error - syntax error, unexpected T_LOGICAL_AND in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:57:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:57:34 --> Parsing Error - syntax error, unexpected T_LOGICAL_AND in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:57:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:57:38 --> Parsing Error - syntax error, unexpected T_LOGICAL_AND in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:57:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:57:45 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:57:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:57:45 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 18:58:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:58:43 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:58:43 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:58:43 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'images.location REGEXP ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.propimg_id =1AND images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:58:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:58:43 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:58:43 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:58:43 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'images.location REGEXP ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.propimg_id =1AND images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:59:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:59:15 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:59:15 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:59:15 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.propimg_id =1 AND images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:59:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:59:15 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:59:15 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:59:15 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.propimg_id =1 AND images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:59:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:59:33 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:59:33 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:59:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$id AND images.location REGEXP ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.propimg_id $id AND images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 18:59:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 18:59:34 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 18:59:34 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 18:59:34 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$id AND images.location REGEXP ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.propimg_id $id AND images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:00:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:00:35 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 19:00:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:00:36 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
WARNING - 2014-12-30 19:01:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:02 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:02 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:02 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:02 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:02 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:02 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:36 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:36 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:36 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:36 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:36 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:36 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:39 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:39 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:39 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:40 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:40 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:40 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:54 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:54 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:54 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:01:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:01:54 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:01:54 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:01:54 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:21 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:02:21 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:02:21 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:22 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:02:22 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:02:22 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:25 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:02:25 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:02:25 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:26 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:02:26 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:02:26 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:32 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-30 19:02:32 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 16
WARNING - 2014-12-30 19:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:32 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (null) AND (`rentsignals`.`id` = 'images.propimg_id') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:02:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:43 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:02:43 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:02:43 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:02:43 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:02:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:02:47 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN ('rozelle') AND (`rentsignals`.`id` = 'images.propimg_id') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:03:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:03:17 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:03:17 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:03:17 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:03:17 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:03:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:03:17 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:03:17 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:03:17 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:03:17 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:03:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:03:47 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:03:48 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:03:48 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:03:48 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:03:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:03:48 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:03:48 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:03:48 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:03:48 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:03:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:03:53 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:03:53 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2014-12-30 19:03:53 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
ERROR - 2014-12-30 19:03:53 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:04:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:04:07 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:04:07 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle|' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:04:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:04:07 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:04:07 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle|' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:04:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:04:30 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:04:30 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle|' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:04:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:04:30 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\showlistings.php on line 56
ERROR - 2014-12-30 19:04:30 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle|' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:14:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:15:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:15:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:16:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:16:07 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-30 19:16:07 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = NULL) WHERE `location` LIKE 'glebe' AND `imgprop_id` IS null GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:16:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:16:08 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-30 19:16:08 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = NULL) WHERE `location` LIKE 'glebe' AND `imgprop_id` IS null GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:16:29 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `1`) WHERE `location` LIKE 'glebe' AND `imgprop_id` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:16:29 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `1`) WHERE `location` LIKE 'glebe' AND `imgprop_id` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:17:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:17:35 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`imgprop_id`) WHERE `location` = 'glebe' AND `imgprop_id` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:17:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:17:35 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`imgprop_id`) WHERE `location` = 'glebe' AND `imgprop_id` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:41:08 --> 1054 - Unknown column 'imgprop_id' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`imgprop_id`) WHERE `images`.`location` = 'glebe' AND `imgprop_id` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:41:09 --> 1054 - Unknown column 'imgprop_id' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`imgprop_id`) WHERE `images`.`location` = 'glebe' AND `imgprop_id` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:41:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:41:53 --> 1054 - Unknown column 'images.propimg_id ' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id `) WHERE `images`.`location` = 'glebe' AND `images`.`propimg_id ` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:41:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:41:53 --> 1054 - Unknown column 'images.propimg_id ' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id `) WHERE `images`.`location` = 'glebe' AND `images`.`propimg_id ` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:41:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:41:58 --> 1054 - Unknown column 'images.propimg_id ' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id `) WHERE `images`.`location` = 'glebe' AND `images`.`propimg_id ` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:41:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:41:59 --> 1054 - Unknown column 'images.propimg_id ' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id `) WHERE `images`.`location` = 'glebe' AND `images`.`propimg_id ` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:42:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:42:14 --> 1054 - Unknown column 'images.propimg_id ' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id `) WHERE `images`.`location` = 'glebe' AND `images`.`propimg_id ` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:42:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:42:15 --> 1054 - Unknown column 'images.propimg_id ' in 'where clause' [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id `) WHERE `images`.`location` = 'glebe' AND `images`.`propimg_id ` = '1' GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 19:42:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:42:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:43:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:43:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:43:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:43:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:44:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:44:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:50:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:50:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:50:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:50:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:50:24 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:50:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:50:24 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:51:20 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:51:21 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:51:37 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:51:37 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:51:53 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:51:54 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:51:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:51:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:52:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:52:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:52:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:52:12 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:52:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:52:13 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 85
WARNING - 2014-12-30 19:53:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:53:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:53:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:53:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:54:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:54:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 19:55:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:55:04 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 19:55:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:55:04 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 19:55:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:55:36 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 19:55:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:55:36 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 19:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:56:11 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 19:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 19:56:11 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 20:06:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:06:54 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 20:06:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:06:54 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 20:07:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:07:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:07:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:07:54 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 20:07:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:07:54 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 84
WARNING - 2014-12-30 20:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:23:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:23:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:23:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:23:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:23:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:23:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:24:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:24:17 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:24:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:24:17 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:24:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:26:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:26:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:26:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:26:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:26:28 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 14
ERROR - 2014-12-30 20:26:28 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
WARNING - 2014-12-30 20:26:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:26:29 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:27:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:27:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:27:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:27:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:27:44 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:28:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:28:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:28:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:28:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:28:56 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 14
ERROR - 2014-12-30 20:28:56 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:28:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:30:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:30:27 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:30:52 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:30:52 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:31:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:31:07 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:31:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:31:07 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:31:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:31:46 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 14
ERROR - 2014-12-30 20:31:46 --> 8 - Undefined index: id in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-30 20:31:46 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:32:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:32:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:32:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:32:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:32:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:32:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:33:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:33:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:33:11 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:33:18 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:34:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:34:54 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:35:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:35:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:35:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:35:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:35:57 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:36:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:36:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:36:12 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:36:28 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:36:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:36:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:36:35 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-30 20:38:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:38:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:38:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:38:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:39:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:39:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:40:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:40:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:41:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:41:22 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 20:41:22 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 20:45:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:45:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:46:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:46:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:46:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 20:46:34 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 20:46:34 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 20:47:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:47:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 20:47:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:00:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:00:25 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:00:25 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:00:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:02:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:03:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:03:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:03:21 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:06:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:06:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:07:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:07:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:07:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:07:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:07:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:07:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:10:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:11:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:11:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:11:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:11:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:11:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:12:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:13:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:14:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:14:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:14:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:14:11 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:17:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:17:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:17:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:17:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:18:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:18:52 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location REGEXP 'glebe|mascot|rozelle|sydenham'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location AND WHERE images.location REGEXP 'glebe|mascot|rozelle|sydenham' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:18:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:18:52 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location REGEXP 'glebe|mascot|rozelle|sydenham'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location AND WHERE images.location REGEXP 'glebe|mascot|rozelle|sydenham' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:19:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:19:05 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE images.location REGEXP 'glebe|mascot|rozelle|sydenham'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location AND WHERE images.location REGEXP 'glebe|mascot|rozelle|sydenham' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:19:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:20:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:21:35 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,12' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot|rozelle' limit -1,12 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:21:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:21:48 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,12' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot|rozelle|sydenham' limit -1,12 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:21:48 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,12' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot|rozelle|sydenham' limit -1,12 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:21:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:21:57 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,12' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot|rozelle|sydenham' limit -1,12 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:23:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:23:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:07 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:23:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:23:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:23:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:23:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:23:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:23:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:23:41 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:23:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:23:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:23:45 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:24:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:24:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:24:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:24:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:24:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:24:23 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:24:23 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:25:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:25:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:25:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:25:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:26:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:26:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:27:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:27:07 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:27:22 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2014-12-30 21:27:22 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2014-12-30 21:27:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:27:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:28:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:28:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:33:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:33:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:33:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:33:45 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-12-30 21:33:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:33:45 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-12-30 21:33:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:33:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:33:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:33:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:34:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:34:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:34:06 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 21:34:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'Array' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:35:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:35:28 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-12-30 21:35:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:35:28 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-12-30 21:35:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:35:38 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 21:35:38 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'Array' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:37:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:37:00 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 21:37:00 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2014-12-30 21:37:00 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2014-12-30 21:37:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:37:00 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2014-12-30 21:37:00 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2014-12-30 21:37:00 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2014-12-30 21:37:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:37:11 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-12-30 21:37:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:37:11 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-12-30 21:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:37:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:37:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:38:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:38:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:38:26 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:38:26 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:38:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:38:26 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:38:26 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:38:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:38:35 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:38:35 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:38:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:38:35 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2014-12-30 21:38:35 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2014-12-30 21:38:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:38:41 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2014-12-30 21:38:41 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2014-12-30 21:38:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:38:41 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2014-12-30 21:38:41 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2014-12-30 21:39:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:39:12 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:39:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:39:12 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:39:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:39:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-30 21:39:22 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe|mascot' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-30 21:39:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:39:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:42:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:42:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:42:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-30 21:42:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
