<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-09-01 13:22:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-09-01 13:22:02 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2012-09-01 13:22:02 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Error - 2012-09-01 13:22:02 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-09-01 13:22:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-09-01 13:22:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
