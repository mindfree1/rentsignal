<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-10-17 00:00:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:00:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:00:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:00:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:00:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:00:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:11:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:11:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:11:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:11:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:11:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:11:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:11:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:12:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:12:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:12:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:12:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:12:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:12:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:12:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:15:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:15:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:15:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:15:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:15:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:15:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:15:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:17:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:17:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:17:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:17:55 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\views\listings\listings.php on line 37
Error - 2013-10-17 00:17:55 --> 8 - Use of undefined constant condition - assumed 'condition' in C:\wamp\fuel\app\views\listings\listings.php on line 41
Warning - 2013-10-17 00:17:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:17:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:18:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:18:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:18:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:18:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:18:20 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\views\listings\listings.php on line 37
Warning - 2013-10-17 00:18:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:18:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:19:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:19:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:19:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:19:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:19:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:19:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:19:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:20:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:20:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:20:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:21:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:21:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:22:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:22:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:22:03 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 37
Warning - 2013-10-17 00:22:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:22:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:22:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:22:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:22:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:22:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:22:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:22:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:22:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:23:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:23:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:23:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:29:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:29:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:29:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:29:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:16 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:29:46 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\classes\arr.php on line 62
Warning - 2013-10-17 00:30:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:30:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:30:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:30:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:30:59 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2013-10-17 00:31:29 --> Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\core\bootstrap.php on line 42
Warning - 2013-10-17 00:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:31:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:31:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:31:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:31:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:32:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:32:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:32:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:32:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:32:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:32:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:33:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:33:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:33:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:33:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:33:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:33:49 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 50
Warning - 2013-10-17 00:33:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:33:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:34:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:34:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:34:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 50
Warning - 2013-10-17 00:34:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:34:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:34:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:34:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:34:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:34:48 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 50
Warning - 2013-10-17 00:34:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:34:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:35:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:35:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:36:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:36:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:36:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:36:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:36:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:36:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:36:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:36:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:36:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:36:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:36:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:36:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:38:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:38:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:38:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:38:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:38:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:39:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:39:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:39:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:39:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:39:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:40:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:40:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:40:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:40:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:40:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:40:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:41:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:41:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:41:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:41:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:41:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:41:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:41:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:41:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:41:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:41:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:41:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:42:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:42:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:42:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:42:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:42:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:42:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-17 00:42:34 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 52
Warning - 2013-10-17 00:42:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:42:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:43:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:43:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:43:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:43:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:43:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:43:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:43:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:43:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:43:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:46:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:46:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:46:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:46:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:46:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:46:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:47:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:47:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:47:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:48:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:48:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:48:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:51:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:51:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:51:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:51:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:51:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:51:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:51:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:51:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:51:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:52:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:52:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:52:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 00:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 00:52:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 00:52:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-17 01:27:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-17 01:27:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-17 01:27:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
