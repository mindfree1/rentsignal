<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-10-11 00:08:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:08:27 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:08:27 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:08:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:08:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:09:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:09:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:09:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:09:23 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:09:23 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:09:23 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:10:24 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:10:24 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:10:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:10:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:10:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:10:27 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:10:27 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:10:27 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:15:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:22:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:22:55 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:22:55 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:22:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:26:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:26:54 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:26:54 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:26:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:27:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:27:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:27:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:27:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:27:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:27:40 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:27:40 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:27:40 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:29:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:29:04 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:29:04 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:29:04 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:31:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:31:08 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:31:08 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:31:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:31:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:31:19 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:31:19 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:31:19 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:32:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:32:47 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:32:47 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Error - 2013-10-11 00:32:47 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:32:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:32:48 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:25 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:33:25 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Error - 2013-10-11 00:33:25 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:25 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:28 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:33:28 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Error - 2013-10-11 00:33:28 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:29 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:32 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:33:32 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Error - 2013-10-11 00:33:32 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:32 --> Parsing Error - syntax error, unexpected ':' in C:\wamp\fuel\core\vendor\phpquickprofiler\display.php on line 17
Warning - 2013-10-11 00:33:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:33:57 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:33:57 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:33:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:34:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:34:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:34:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:34:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:34:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:34:09 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:34:09 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:34:09 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:36:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:36:52 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:36:52 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:36:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:36:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:36:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:36:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:36:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:36:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:36:58 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:36:58 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:36:58 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:39:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:39:36 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\rendertest.php on line 2
Error - 2013-10-11 00:39:36 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\rendertest.php on line 30
Warning - 2013-10-11 00:39:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:39:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:39:42 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:39:42 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:39:42 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:40:21 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 1
Warning - 2013-10-11 00:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:40:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:40:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:40:26 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:40:26 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:40:26 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:44:27 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 1
Warning - 2013-10-11 00:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:44:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:44:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:44:39 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:44:39 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:44:39 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
Warning - 2013-10-11 00:44:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:44:53 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\listings\listings.php on line 1
Warning - 2013-10-11 00:44:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:45:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:45:53 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-10-11 00:45:53 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2013-10-11 00:45:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:46:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:46:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-11 00:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-11 00:46:13 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 5
Error - 2013-10-11 00:46:13 --> 8 - Undefined variable: title in C:\wamp\fuel\app\views\template.php on line 15
Error - 2013-10-11 00:46:13 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\template.php on line 33
