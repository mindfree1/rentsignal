<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-10-10 22:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-10-10 22:28:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-10-10 22:29:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
