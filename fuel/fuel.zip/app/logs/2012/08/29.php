<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-29 00:02:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:02:12 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:02:12 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:02:12 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:02:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:03:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:03:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:03:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 00:03:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:03:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:03:57 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:03:57 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:03:57 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:04:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:04:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 00:04:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:04:50 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:04:50 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:04:50 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:04:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:04:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:04:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:04:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 00:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:05:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:05:10 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:05:10 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:05:10 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:18 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:18 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:18 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:24 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:24 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:24 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:25 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:25 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:25 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:32 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:32 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:32 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:46 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:46 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:46 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:48 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:48 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:48 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:48 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:48 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:06:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:06:55 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:06:55 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:06:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:07:05 --> 2 - Missing argument 1 for Controller_ShowListings::action_searchlistings() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:07:05 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:07:05 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:08:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:08:19 --> 2 - Missing argument 1 for Controller_ShowListings::action_search() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:08:19 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:08:19 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:08:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:08:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:08:23 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:08:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:08:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:08:33 --> 2 - Missing argument 1 for Controller_ShowListings::action_search() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:08:33 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:08:33 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:08:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:08:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:08:37 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:08:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:09:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:09:03 --> 2 - Missing argument 2 for Controller_ShowListings::action_search() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Error - 2012-08-29 00:09:03 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:09:03 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:09:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:09:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:09:11 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Error - 2012-08-29 00:09:11 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:09:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:09:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:09:29 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:09:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:09:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:09:42 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:09:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:10:02 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 19
Error - 2012-08-29 00:10:02 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:10:03 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 19
Error - 2012-08-29 00:10:03 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:10:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:10:20 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\controller\showlistings.php on line 21
Warning - 2012-08-29 00:10:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:10:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:10:33 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:10:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 00:12:18 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 00:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:17:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 00:17:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:17:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 00:17:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:17:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 00:17:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 00:17:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 00:17:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:27:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:27:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:27:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:27:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:28:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:28:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:28:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:28:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:28:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:28:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:28:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:28:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:32:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:32:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:32:57 --> 2 - Missing argument 1 for Controller_ShowListings::action_search() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Warning - 2012-08-29 19:32:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:33:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:33:03 --> 2 - Missing argument 1 for Controller_ShowListings::action_search() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 16
Warning - 2012-08-29 19:33:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:33:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:33:07 --> Error - The data parameter only accepts objects and arrays. in C:\wamp\fuel\core\classes\view.php on line 119
Warning - 2012-08-29 19:33:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:33:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:33:55 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 22
Warning - 2012-08-29 19:33:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:34:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:34:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:34:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:35:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:35:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:35:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:35:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:35:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:36:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:36:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:36:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:36:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:36:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:38:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:38:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:38:47 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 19:38:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:38:58 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 19:38:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:39:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:39:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:39:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:39:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:39:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:39:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:39:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:39:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:39:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:41:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:41:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:41:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:41:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:41:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:42:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:42:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:42:50 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 19:42:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:42:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:42:57 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 19:42:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:43:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:43:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:43:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:43:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:43:25 --> Error - Call to undefined function alert() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 19:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:43:37 --> Error - Call to undefined function alert() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 19:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:43:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:44:32 --> 8 - Undefined index: rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 19:44:32 --> 8 - Undefined index: rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 19:44:32 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 19:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:45:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:45:17 --> 8 - Undefined index: &rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 19:45:17 --> 8 - Undefined index: &rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 19:45:17 --> 8 - Undefined index: &bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 19:45:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:46:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:46:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:46:05 --> 8 - Undefined index: &rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 19:46:05 --> 8 - Undefined index: &rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 19:46:05 --> 8 - Undefined index: &bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 19:46:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:46:14 --> 8 - Undefined index: &rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 19:46:14 --> 8 - Undefined index: &rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 19:46:14 --> 8 - Undefined index: &bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 19:46:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:46:21 --> 8 - Undefined index: &rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 19:46:21 --> 8 - Undefined index: &bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 19:46:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:46:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:47:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:47:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:48:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:48:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:49:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:49:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:49:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:49:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 19:49:54 --> 8 - Undefined index: rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 19:49:54 --> 8 - Undefined index: rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 19:49:54 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 19:50:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:50:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:50:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 19:50:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 19:50:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 19:50:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:29:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 22:29:41 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 18
Warning - 2012-08-29 22:29:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:29:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 22:29:53 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 7
Warning - 2012-08-29 22:29:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:30:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:30:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:30:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:30:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:30:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:30:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:33:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:33:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:33:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:33:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:33:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:33:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 22:33:40 --> 8 - Undefined index: rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 22:33:40 --> 8 - Undefined index: rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 22:33:40 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 22:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:37:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:37:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 22:38:09 --> 8 - Undefined index: rentmax in C:\wamp\fuel\app\views\mapgen\create.php on line 3
Error - 2012-08-29 22:38:09 --> 8 - Undefined index: rooms in C:\wamp\fuel\app\views\mapgen\create.php on line 4
Error - 2012-08-29 22:38:09 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\views\mapgen\create.php on line 5
Warning - 2012-08-29 22:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:39:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:39:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:39:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:41:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:41:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:41:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:41:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:41:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:45:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:45:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:47:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:47:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:47:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:47:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:47:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:47:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:49:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 22:49:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 22:49:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 22:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:06:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:06:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:06:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:06:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:06:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:08:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:08:20 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:08:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:08:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:08:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:08:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:08:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:08:47 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:08:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:08:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:08:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:09:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:09:10 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:09:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:09:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:09:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:09:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:09:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:09:48 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:09:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:09:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:09:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:09:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:12:18 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:12:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:12:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:12:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:12:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:14:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:14:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:14:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:14:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:14:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:14:29 --> 8 - Undefined variable: data in C:\wamp\fuel\app\views\welcome\index.php on line 70
Error - 2012-08-29 23:14:29 --> Error - The requested view could not be found: test/name_to_upper in C:\wamp\fuel\core\classes\view.php on line 389
Warning - 2012-08-29 23:14:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:14:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:14:50 --> 8 - Undefined variable: data in C:\wamp\fuel\app\views\welcome\index.php on line 70
Warning - 2012-08-29 23:14:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:14:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:15:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:15:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:15:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:15:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:16:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:16:23 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:16:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:16:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:16:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:16:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:17:18 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:17:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:17:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:17:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:18:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:18:10 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:18:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:18:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:18:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:18:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:24:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:24:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:24:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:24:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:24:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:27:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:27:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:27:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:27:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:27:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:27:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:27:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:27:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:27:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:28:01 --> Error - Class 'Mapgen' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 30
Warning - 2012-08-29 23:32:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:32:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:32:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:32:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:32:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:32:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:32:59 --> Error - Class 'Mapgen' not found in C:\wamp\fuel\app\classes\controller\showlistings.php on line 30
Warning - 2012-08-29 23:33:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:33:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:33:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:33:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:33:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:34:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:34:00 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column '$rentmin' in 'where clause' with query: "SELECT * FROM `rentsignals` WHERE rent LIKE $rentmin AND $rentmax" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-08-29 23:34:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:34:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:34:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:34:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:34:57 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2012-08-29 23:34:57 --> 8 - Undefined variable: query_results in C:\wamp\fuel\app\classes\model\mapgen.php on line 20
Error - 2012-08-29 23:34:57 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Error - 2012-08-29 23:34:57 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:34:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:34:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:35:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:35:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:35:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:35:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:35:35 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2012-08-29 23:35:35 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Error - 2012-08-29 23:35:35 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:35:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:35:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:36:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:36:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:36:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:36:51 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2012-08-29 23:36:51 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Error - 2012-08-29 23:36:51 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:36:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:36:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:37:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:37:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:37:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:37:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:37:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:37:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:37:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:37:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:37:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-29 23:38:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:38:14 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2012-08-29 23:38:14 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Error - 2012-08-29 23:38:14 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:38:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:38:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-08-29 23:47:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-29 23:47:17 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\classes\model\mapgen.php on line 18
Error - 2012-08-29 23:47:17 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\mapgen.php on line 30
Error - 2012-08-29 23:47:17 --> 8 - Undefined variable: rentmin in C:\wamp\fuel\app\views\mapgen\create.php on line 9
Warning - 2012-08-29 23:47:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-08-29 23:47:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
