<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-01-02 17:47:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:47:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:47:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 17:49:31 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 17:49:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:49:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:50:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 17:50:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle Failed to load resource: the server responded with a status of 500 (Internal Server Error)' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 17:50:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 17:50:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle Failed to load resource: the server responded with a status of 500 (Internal Server Error)' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 17:59:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 17:59:18 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle Failed to load resource: the server responded with a status of 500 (Internal Server Error)' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 17:59:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 17:59:18 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle Failed to load resource: the server responded with a status of 500 (Internal Server Error)' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 17:59:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:59:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:59:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:59:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:59:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 17:59:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:01:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:01:56 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle Failed to load resource: the server responded with a status of 500 (Internal Server Error)' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:01:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:01:57 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle Failed to load resource: the server responded with a status of 500 (Internal Server Error)' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:02:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:02:02 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:02:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:02:03 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:08:53 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:08:53 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location REGEXP 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:09:25 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle' limit -1,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:09:26 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle' limit -1,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe,mascot,rozelle' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 30
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 30
WARNING - 2015-01-02 18:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 30
ERROR - 2015-01-02 18:10:36 --> 8 - Undefined variable: img_amount in C:\wamp\fuel\app\views\listings\listings.php on line 30
WARNING - 2015-01-02 18:11:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:11:24 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2015-01-02 18:11:24 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:11:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:11:24 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2015-01-02 18:11:24 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:12:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:12:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2015-01-02 18:12:05 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:12:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:12:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 54
ERROR - 2015-01-02 18:12:05 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:12:18 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:12:18 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:12:18 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 18
ERROR - 2015-01-02 18:12:18 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:12:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:12:18 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:12:18 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:12:18 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 18
ERROR - 2015-01-02 18:12:18 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:08 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:08 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:08 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:08 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:08 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:08 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:10 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:10 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:10 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:11 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:11 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:11 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:14 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:14 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:14 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:14 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:14 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:14 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:21 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:21 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:21 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:13:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:13:21 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:21 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:13:21 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:00 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Array'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN 'Array' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:01 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Array'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN 'Array' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:36 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:37 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:14:41 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:14:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:14:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:14:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:14:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:15:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:15:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:15:01 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:15:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:15:15 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:15:15 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:15:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:15:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:15:15 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:15:15 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:15:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:17:54 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2015-01-02 18:17:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:17:54 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2015-01-02 18:17:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:18:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:18:15 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:18:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:18:15 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:24:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:09 --> 8 - Undefined variable: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:24:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:10 --> 8 - Undefined variable: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:10 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:24:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:27 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:27 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:54 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:54 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:54 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:56 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:56 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:56 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:58 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:58 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:24:58 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:25:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:11 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:25:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:11 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
ERROR - 2015-01-02 18:25:11 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:25:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:25:22 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:25:22 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:25:22 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:25:22 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:22 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:22 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
ERROR - 2015-01-02 18:25:22 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:25:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:25:23 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:25:23 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:25:23 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:25:23 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:23 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:25:23 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
ERROR - 2015-01-02 18:25:23 --> 8 - Undefined offset: 0 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:27:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:27:38 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:27:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:27:38 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:27:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:28:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:28:09 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:28:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 22
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:28:09 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
ERROR - 2015-01-02 18:28:09 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:28:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:28:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:28:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:28:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:29:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:29:29 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:29:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:29:29 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:29:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:29:32 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:29:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:29:32 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:32:11 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:32:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:32:28 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:33:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:33:24 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:33:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:33:24 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:33:43 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:33:43 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`images`.`propimg_id` = `rentsignals`.`id`) WHERE `rentsignals`.`location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:34:02 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:34:02 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:34:31 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 42
ERROR - 2015-01-02 18:34:31 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location like '' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:34:31 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 42
ERROR - 2015-01-02 18:34:31 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 [ SELECT * FROM `images` WHERE location like '' limit -1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:35:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:35:35 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:35 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:35 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:35:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:35:35 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:35 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:35 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:35:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:35:57 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:57 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:57 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:35:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:35:57 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:57 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:35:57 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:36:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:36:03 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:36:03 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:36:03 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:36:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:36:46 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:36:46 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:36:46 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:37:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:37:04 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:37:04 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:37:04 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:37:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:37:04 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:37:04 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:37:04 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:37:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:37:08 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:37:08 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:37:08 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:39:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:39:54 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:39:54 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:39:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:40:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:40:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:40:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:40:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:40:38 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:38 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:38 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:40:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:40:45 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:45 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:45 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:40:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:40:45 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:45 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:45 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:40:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:40:50 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:50 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:50 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:40:56 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:56 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:40:56 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX ''' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:41:36 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX 'glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:41:36 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX 'glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location REGEX 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:42:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:42:06 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe,mascot,rozelle' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN glebe,mascot,rozelle ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:42:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:42:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe,mascot,rozelle' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN glebe,mascot,rozelle ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:42:25 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:42:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:42:25 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:45:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:45:13 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:45:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:45:13 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:45:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:45:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:45:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:45:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array' at line 1 [ SELECT * FROM `images` INNER JOIN rentsignals ON rentsignals.location = images.location WHERE rentsignals.location IN Array ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:46:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:46:08 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:46:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:46:09 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:47:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:47:16 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:47:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:47:16 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:47:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:47:18 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:47:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:47:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:47:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:47:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:47:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:47:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:47:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:47:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:47:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:40 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:41 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:44 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:48:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:48:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 18:49:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:49:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:49:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:49:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 18:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:49:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:49:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:49:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:04 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:04 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:06 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:06 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:08 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:08 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:22 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:51:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:51:22 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:52:06 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:52:06 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:52:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:52:38 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:52:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:52:39 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:53:00 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:53:00 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 18:53:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:53:44 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:53:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:53:45 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:04 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:04 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:06 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:06 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:54:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:54:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:54:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:54:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:54:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:55 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:54:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:54:56 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:55:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:55:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:55:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:55:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:55:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:55:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:55:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:56:00 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:56:13 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:56:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:56:13 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:56:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:56:41 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:56:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:56:41 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:56:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 18:56:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:56:57 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''0glebe,1mascot,2rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN '0glebe,1mascot,2rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:59:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:59:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:59:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:17 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:59:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:17 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,mascot,rozelle'' at line 1 [ SELECT * FROM `images` WHERE `location` IN 'glebe,mascot,rozelle' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 18:59:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:36 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:59:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:36 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:59:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:59:53 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:53 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 18:59:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: locations in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:59:53 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 18:59:53 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 18:59:54 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:54 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 18:59:54 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:00:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:00:17 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:17 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:00:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:00:17 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:17 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:17 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:00:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:00:37 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:00:37 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:00:37 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:00:37 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:00:37 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:37 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:37 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:00:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:00:38 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:00:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:00:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:00:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:00:38 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:38 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:00:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:00:57 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:57 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:00:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:00:57 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:57 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:00:57 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:01:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:01:14 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:01:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 21
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 23
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: totalresult in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:01:14 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 48
ERROR - 2015-01-02 19:01:14 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:01:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:01:31 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:01:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:01:31 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:02:11 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:02:11 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:02:11 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:02:11 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:02:26 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:02:26 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:02:26 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:02:26 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:02:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:02:29 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:02:29 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:02:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:02:29 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:02:29 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:03:05 --> 8 - unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 0 of 20 bytes in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:03:05 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''0'' at line 1 [ SELECT * FROM `images` WHERE `location` IN '0' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:03:05 --> 8 - unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 0 of 20 bytes in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:03:05 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''0'' at line 1 [ SELECT * FROM `images` WHERE `location` IN '0' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:03:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:03:23 --> 8 - unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 0 of 20 bytes in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:03:23 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''0'' at line 1 [ SELECT * FROM `images` WHERE `location` IN '0' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:03:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:03:23 --> 8 - unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 0 of 20 bytes in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:03:23 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''0'' at line 1 [ SELECT * FROM `images` WHERE `location` IN '0' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:03:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:03:49 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:03:49 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:03:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:03:49 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:03:49 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:05 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:05 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:27 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:27 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:50 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:50 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:50 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:50 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:54 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:55 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:04:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:04:55 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:04:55 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:05:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:05:16 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:05:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:05:16 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:05:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:05:45 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:05:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:05:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:05:45 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:05:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
WARNING - 2015-01-02 19:05:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:05:58 --> 1241 - Operand should contain 1 column(s) [ SELECT * FROM `images` WHERE `location` LIKE ('glebe', 'mascot', 'rozelle') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:05:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:05:58 --> 1241 - Operand should contain 1 column(s) [ SELECT * FROM `images` WHERE `location` LIKE ('glebe', 'mascot', 'rozelle') ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:06:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:06:13 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:06:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:06:13 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:06:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:06:35 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:06:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:06:36 --> 8 - Undefined offset: 10 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:06:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:06:56 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:06:56 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:06:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:06:56 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:06:56 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:07:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:08:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:08:09 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:08:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:08:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:08:55 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:08:55 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:08:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:08:55 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:08:55 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:08:58 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
ERROR - 2015-01-02 19:08:58 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `location` IN null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:11:31 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:11:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:11:31 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:11:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:11:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:11:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:11:43 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:11:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:11:44 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:11:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:11:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:12:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:12:15 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:13:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:13:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:13:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:13:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:14:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:14:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:14:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:14:09 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:15:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:15:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:15:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:15:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:15:18 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations  limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations  limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:15:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:15:23 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations  limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations  limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:15:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:15:23 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations  limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations  limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:17:49 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 19:17:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:17:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:18:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:19:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:19:42 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 19:20:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:20:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:20:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:20:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:21:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:21:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:21:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:22:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:22:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:22:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:23:09 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
WARNING - 2015-01-02 19:23:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:23:09 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
WARNING - 2015-01-02 19:23:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:23:29 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
WARNING - 2015-01-02 19:23:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:23:29 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
WARNING - 2015-01-02 19:23:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:23:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:24:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:24:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:25:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:25:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:26:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:26:19 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2015-01-02 19:26:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1 OFFSET 8' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe', 'mascot', 'rozelle') LIMIT -1 OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:26:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:26:19 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 19
ERROR - 2015-01-02 19:26:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1 OFFSET 8' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe', 'mascot', 'rozelle') LIMIT -1 OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:26:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:26:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:27:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:27:44 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations  limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations  limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:27:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:27:44 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations  limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations  limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:28:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:28:04 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:28:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:28:04 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:28:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:28:28 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INArray limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location INArray limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:28:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:28:28 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INArray limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location INArray limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:28:42 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:28:42 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 1,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 19:29:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:29:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:30:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:30:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:31:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:31:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:32:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:32:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:33:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:33:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:34:15 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:34:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:34:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:35:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:35:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:35:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:35:12 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:37:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:37:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:37:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:37:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:38:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:38:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:40:36 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:42:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:42:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:42:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:42:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:43:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:43:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:43:06 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 32
ERROR - 2015-01-02 19:43:06 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 32
WARNING - 2015-01-02 19:43:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:43:11 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
WARNING - 2015-01-02 19:44:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:44:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:44:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:44:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:44:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:44:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:44:45 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:45 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:44:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:44:48 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:45:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:45:14 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:45:14 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:45:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:45:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:45:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:46:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:48:23 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:48:23 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:48:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:48:26 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:48:26 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:48:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:48:28 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:48:28 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:48:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:48:29 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:48:29 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:48:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 19:48:30 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
ERROR - 2015-01-02 19:48:30 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 33
WARNING - 2015-01-02 19:48:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 19:48:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:09:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:09:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:10:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:10:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:10:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:10:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('Array') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:10:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:10:16 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('Array') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:13:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:13:50 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\views\listings\listings.php on line 8
WARNING - 2015-01-02 20:13:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:13:50 --> 2 - explode() expects parameter 2 to be string, array given in C:\wamp\fuel\app\views\listings\listings.php on line 8
WARNING - 2015-01-02 20:14:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:14:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:14:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:14:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:14:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:14:49 --> 8 - Undefined index: $locations in C:\wamp\fuel\app\views\listings\listings.php on line 8
WARNING - 2015-01-02 20:14:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:14:49 --> 8 - Undefined index: $locations in C:\wamp\fuel\app\views\listings\listings.php on line 8
WARNING - 2015-01-02 20:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:15:25 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe.mascot') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:15:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:15:26 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe.mascot') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:15:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:15:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:16:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:16:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:16:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:16:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:16:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:16:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:18:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:18:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:18:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:18:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:19:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:20:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:20:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:20:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:20:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:20:31 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\views\listings\listings.php on line 7
WARNING - 2015-01-02 20:20:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:20:49 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:20:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:20:51 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:20:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:20:51 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:20:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:20:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:21:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:21:08 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:21:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:21:08 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('') LIMIT 8 OFFSET -1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 20:21:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:21:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:21:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:21:25 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\views\listings\listings.php on line 7
WARNING - 2015-01-02 20:21:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:21:25 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\views\listings\listings.php on line 7
WARNING - 2015-01-02 20:22:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:22:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:23:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:23:53 --> Parsing Error - syntax error, unexpected T_PUBLIC in C:\wamp\fuel\app\classes\model\showlistings.php on line 75
WARNING - 2015-01-02 20:23:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:24:05 --> Parsing Error - syntax error, unexpected T_PUBLIC in C:\wamp\fuel\app\classes\model\showlistings.php on line 75
WARNING - 2015-01-02 20:24:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:24:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:24:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:24:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:24:37 --> Parsing Error - syntax error, unexpected T_PUBLIC in C:\wamp\fuel\app\classes\model\showlistings.php on line 75
WARNING - 2015-01-02 20:25:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:25:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:30:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:30:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:30:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:30:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:30:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:30:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:30:21 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 33
WARNING - 2015-01-02 20:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:31:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:32:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:32:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:32:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:32:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:32:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:32:35 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
WARNING - 2015-01-02 20:34:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:36:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:36:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:36:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:36:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:36:13 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 34
ERROR - 2015-01-02 20:36:13 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 40
ERROR - 2015-01-02 20:36:13 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 42
WARNING - 2015-01-02 20:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:37:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:42:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:43:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:43:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:43:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:43:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:43:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:44:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:44:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:44:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:44:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:45:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:45:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:45:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:45:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:46:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:46:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:46:14 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\views\listings\listings.php on line 31
WARNING - 2015-01-02 20:47:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:47:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:47:57 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:47:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:47:57 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:47:57 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:47:57 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:47:57 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:48:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:48:09 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:09 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:09 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:09 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:09 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:09 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:48:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:48:16 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:16 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:16 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:16 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:16 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:48:16 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:49:16 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:16 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:16 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:16 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:16 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:49:26 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:26 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:26 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:26 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:26 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:49:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:49:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:49:28 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:28 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:28 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:28 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:49:28 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:49:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:50:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:50:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:50:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:51:27 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:51:27 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:51:27 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:51:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:51:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:51:34 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:51:34 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:51:34 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 20:54:11 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:54:11 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 20:54:11 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 20:54:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:54:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:55:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:55:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:55:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:55:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:55:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:55:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:56:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 20:56:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:03:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:03:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:04:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:04:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:04:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:04:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:04:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:04:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:04:22 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:04:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:04:35 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:04:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:04:35 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` INNER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:04:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:04:55 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:04:55 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:04:55 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:04:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:04:55 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:04:55 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:04:55 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:14 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:14 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:14 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:14 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:14 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:14 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:36 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:36 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:36 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:36 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:36 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:36 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:47 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:47 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:47 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:47 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:47 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:05:47 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:59 --> 1054 - Unknown column 'images.location' in 'on clause' [ SELECT * FROM `images` OUTTER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `rentsignals`.`location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:05:59 --> 1054 - Unknown column 'images.location' in 'on clause' [ SELECT * FROM `images` OUTTER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `rentsignals`.`location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:06:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:06:45 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OUTER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHE' at line 1 [ SELECT * FROM `images` OUTER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `rentsignals`.`location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `images`.`propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:06:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:06:46 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OUTER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHE' at line 1 [ SELECT * FROM `images` OUTER JOIN `rentsignals` ON (`rentsignals`.`location` = `images`.`location`) WHERE `rentsignals`.`location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') GROUP BY `images`.`propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:07:05 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:07:05 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:07:05 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:07:05 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:07:05 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:07:05 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:07:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:07:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:07:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:07:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:07:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:07:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:07:41 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:07:41 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:07:41 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:07:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:08:08 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:08:08 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:08:08 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:08:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:08:09 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:08:09 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:08:09 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:08:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:08:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:10:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:13:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:13:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:13:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:13:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:14:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:20:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:20:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:20:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:20:58 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OFFSET 8' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:20:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:20:58 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OFFSET 8' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:21:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:21:01 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'OFFSET 8' at line 1 [ SELECT * FROM `images` WHERE `location` IN ('glebe', 'mascot', 'rozelle', 'sydenham', 'glebe') OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:22:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:22:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:24:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:24:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:25:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:25:39 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:25:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:25:39 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:25:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:25:42 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:25:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:25:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:25:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:25:57 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:26:16 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:26:16 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:26:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:26:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$locations limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN $locations limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:26:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:27:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:27:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:27:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:27:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:31:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:32:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:32:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:34:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:34:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:34:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:35:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:35:47 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$data limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN $data limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:35:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:35:48 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$data limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN $data limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:35:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:35:50 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '$data limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN $data limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INglebe,mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location INglebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INglebe,mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location INglebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:10 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INglebe,mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location INglebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:17 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe,mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN glebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:17 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe,mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN glebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:20 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'glebe,mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN glebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:32 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location LIKE glebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location LIKE glebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:36 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'mascot,rozelle limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location LIKE glebe,mascot,rozelle limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:51 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:51 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:36:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:36:54 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Array limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN Array limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:12 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GLEBE limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN GLEBE limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:12 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GLEBE limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN GLEBE limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:15 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GLEBE limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN GLEBE limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:23 --> 1054 - Unknown column 'GLEBE' in 'where clause' [ SELECT * FROM `images` WHERE location LIKE GLEBE limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:23 --> 1054 - Unknown column 'GLEBE' in 'where clause' [ SELECT * FROM `images` WHERE location LIKE GLEBE limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:26 --> 1054 - Unknown column 'GLEBE' in 'where clause' [ SELECT * FROM `images` WHERE location LIKE GLEBE limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:37:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:37:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:56 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` WHERE location LIKE glebe limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:56 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` WHERE location LIKE glebe limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:37:59 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` WHERE location LIKE glebe limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:38:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:38:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:38:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:38:42 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` WHERE location =glebe limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:38:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:38:42 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` WHERE location =glebe limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:38:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:38:45 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` WHERE location =glebe limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:39:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:39:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:39:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:39:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:40:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:40:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:45:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:45:20 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '8' at line 1 [ SELECT * FROM `images` OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:45:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:45:20 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '8' at line 1 [ SELECT * FROM `images` OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:45:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:45:23 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '8' at line 1 [ SELECT * FROM `images` OFFSET 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:45:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:45:56 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '8 LIMIT 8' at line 1 [ SELECT * FROM `images` OFFSET 8 LIMIT 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:45:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:45:56 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '8 LIMIT 8' at line 1 [ SELECT * FROM `images` OFFSET 8 LIMIT 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:45:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:45:59 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '8 LIMIT 8' at line 1 [ SELECT * FROM `images` OFFSET 8 LIMIT 8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:47:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:47:47 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:47:47 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:47:47 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:47:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:47:48 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:47:48 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 34
ERROR - 2015-01-02 21:47:48 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 34
WARNING - 2015-01-02 21:48:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:48:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:49:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:52:02 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
WARNING - 2015-01-02 21:52:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:52:02 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
WARNING - 2015-01-02 21:52:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:52:05 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
WARNING - 2015-01-02 21:52:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:52:30 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:52:30 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:52:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:52:31 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:52:31 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:52:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:52:34 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:52:34 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:54:04 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:54:04 --> Fatal Error - [] operator not supported for strings in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
WARNING - 2015-01-02 21:54:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:54:04 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:54:04 --> Fatal Error - [] operator not supported for strings in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
WARNING - 2015-01-02 21:54:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:54:08 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:54:08 --> Fatal Error - [] operator not supported for strings in C:\wamp\fuel\app\classes\model\showlistings.php on line 62
WARNING - 2015-01-02 21:54:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:54:56 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
WARNING - 2015-01-02 21:54:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:54:56 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
WARNING - 2015-01-02 21:55:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:55:30 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:55:30 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2015-01-02 21:55:30 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:55:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:55:30 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:55:30 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2015-01-02 21:55:30 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:55:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:55:33 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:55:33 --> 8 - Undefined variable: location in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
ERROR - 2015-01-02 21:55:33 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:56:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:56:05 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:56:05 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Array' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'Array' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:56:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:56:06 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:56:06 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Array' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'Array' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:56:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:56:09 --> 2 - join() [<a href='function.join'>function.join</a>]: Argument must be an array in C:\wamp\fuel\app\classes\model\showlistings.php on line 49
ERROR - 2015-01-02 21:56:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Array' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'Array' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:56:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:56:39 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,rozelle,sydenham,mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe,rozelle,sydenham,mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:56:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:56:39 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,rozelle,sydenham,mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe,rozelle,sydenham,mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:56:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:56:42 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe,rozelle,sydenham,mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe,rozelle,sydenham,mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:57:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:57:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe|rozelle|sydenham|mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe|rozelle|sydenham|mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:57:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:57:07 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe|rozelle|sydenham|mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe|rozelle|sydenham|mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:57:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:57:10 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe|rozelle|sydenham|mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location IN 'glebe|rozelle|sydenham|mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:57:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:57:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX 'glebe|rozelle|sydenham|mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location REGEX 'glebe|rozelle|sydenham|mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:57:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:57:19 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX 'glebe|rozelle|sydenham|mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location REGEX 'glebe|rozelle|sydenham|mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:57:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 21:57:22 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'REGEX 'glebe|rozelle|sydenham|mascot' limit 8,8' at line 1 [ SELECT * FROM `images` WHERE location REGEX 'glebe|rozelle|sydenham|mascot' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 21:58:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:58:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:59:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:59:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 21:59:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:00:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:00:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:00:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:01:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:17:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 22:39:58 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP 'glebe|' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 22:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 22:39:58 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP 'glebe|' limit 8,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2015-01-02 22:40:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:40:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:40:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:40:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:40:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:40:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:41:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:41:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:41:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:42:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:42:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:45:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:48:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:48:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:48:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:48:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:48:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:52:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:53:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:53:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:53:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:53:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:53:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:53:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:54:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 22:54:24 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 52
WARNING - 2015-01-02 22:54:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 22:54:24 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 52
WARNING - 2015-01-02 22:54:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 22:54:27 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 52
WARNING - 2015-01-02 22:54:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:54:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:54:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:54:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:55:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:55:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 22:56:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:05:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:05:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:05:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:05:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:05:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:05:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:06:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:07:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:08:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:08:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:08:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:08:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:08:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:08:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:09:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:10:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:10:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:10:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:10:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:10:29 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:10:29 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:10:44 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:10:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:10:45 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:11:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:11:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:12:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:12:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:12:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:12:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:12:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:13:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:14:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:14:07 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:14:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:14:08 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:14:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:14:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:14:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:14:23 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:14:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:14:24 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 67
WARNING - 2015-01-02 23:14:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:14:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:09 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2015-01-02 23:15:09 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 23:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:09 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2015-01-02 23:15:09 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 23:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:20 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
ERROR - 2015-01-02 23:15:20 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2015-01-02 23:15:20 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 23:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:21 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
ERROR - 2015-01-02 23:15:21 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 55
ERROR - 2015-01-02 23:15:21 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 56
WARNING - 2015-01-02 23:15:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:38 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
WARNING - 2015-01-02 23:15:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:38 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
WARNING - 2015-01-02 23:15:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:41 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
WARNING - 2015-01-02 23:15:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:56 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
WARNING - 2015-01-02 23:15:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:56 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
WARNING - 2015-01-02 23:15:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:15:59 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
WARNING - 2015-01-02 23:16:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:16:41 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
ERROR - 2015-01-02 23:16:41 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 58
WARNING - 2015-01-02 23:16:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:16:42 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 57
ERROR - 2015-01-02 23:16:42 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 58
WARNING - 2015-01-02 23:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:16:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:17:02 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 73
WARNING - 2015-01-02 23:17:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:17:03 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 73
WARNING - 2015-01-02 23:17:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:17:17 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
WARNING - 2015-01-02 23:17:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:17:17 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
WARNING - 2015-01-02 23:17:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:17:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:18:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:19:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:21:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
WARNING - 2015-01-02 23:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:21:05 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
WARNING - 2015-01-02 23:21:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2015-01-02 23:21:21 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 69
WARNING - 2015-01-02 23:21:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-02 23:22:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
