<h2>New Rentsignal</h2>
<br>

<?php echo render('rentsignals/_form'); ?>


<p><?php echo Html::anchor('rentsignals', 'Back'); ?></p>
