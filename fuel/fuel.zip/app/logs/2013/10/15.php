<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-10-15 21:03:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:03:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:03:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:03:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:03:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:03:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:03:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:04:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:04:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:04:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:04:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:04:08 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:04:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:04:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:04:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:04:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:04:43 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:06:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:06:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:06:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:06:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:06:19 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:06:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:06:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:06:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:07:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:07:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:07:20 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:07:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:07:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:07:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:07:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:07:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:07:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:07:56 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:07:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:07:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:08:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:08:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:08:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:08:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:09:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:09:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:09:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:09:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:09:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:09:39 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:09:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:09:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:10:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:10:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:10:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:10:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:10:38 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 47
Warning - 2013-10-15 21:10:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:10:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:12:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:12:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:12:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:12:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:12:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:12:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:13:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:13:05 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:13:05 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 21:13:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:13:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:13:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:14:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:14:02 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:14:02 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 21:23:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:23:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:23:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:25:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:25:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:25:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:26:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:26:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:26:16 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:26:16 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 21:26:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:26:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:26:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:26:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:26:53 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:26:53 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 21:27:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:27:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:27:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:27:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:27:14 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:27:14 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 21:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:28:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:28:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:28:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:28:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:28:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:29:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:29:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:29:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:29:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:29:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:29:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:34:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:34:27 --> 2 - Missing argument 4 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 21:34:27 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
Warning - 2013-10-15 21:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:35:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:35:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:35:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:35:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:35:46 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
Warning - 2013-10-15 21:35:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:35:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:36:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:36:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:36:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:36:40 --> 2 - Missing argument 2 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 21:36:40 --> 2 - Missing argument 3 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 21:36:40 --> 8 - Undefined variable: args2 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:36:40 --> 8 - Undefined variable: args3 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
Error - 2013-10-15 21:36:40 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe%7Cmascot%7Crozelle%7C||'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 21:37:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 21:37:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 21:37:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 21:37:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 21:37:21 --> 2 - Missing argument 2 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 21:37:21 --> 2 - Missing argument 3 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 21:37:21 --> 8 - Undefined variable: args2 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 21:37:21 --> 8 - Undefined variable: args3 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
Error - 2013-10-15 21:37:21 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebemascotrozelle||'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:10:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:10:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:10:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:10:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:10:19 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 43
Error - 2013-10-15 22:10:19 --> 8 - Undefined variable: args2 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
Error - 2013-10-15 22:10:19 --> 8 - Undefined variable: args3 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 46
Error - 2013-10-15 22:10:19 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '|glebemascotrozelle||'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:11:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:11:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:11:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:11:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:11:50 --> 2 - Missing argument 1 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 22:11:50 --> 8 - Undefined variable: args in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
Error - 2013-10-15 22:11:50 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 43
Error - 2013-10-15 22:11:50 --> 8 - Undefined variable: args in C:\wamp\fuel\app\classes\controller\showlistings.php on line 44
Error - 2013-10-15 22:11:50 --> 8 - Undefined variable: args2 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
Error - 2013-10-15 22:11:50 --> 8 - Undefined variable: args3 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 46
Error - 2013-10-15 22:11:50 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '|||'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:14:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:14:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:14:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:14:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:14:20 --> 2 - Missing argument 1 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 22:14:20 --> 8 - Undefined variable: args in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
Error - 2013-10-15 22:14:20 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 46
Warning - 2013-10-15 22:14:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:14:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:21:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:21:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:21:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:21:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:21:37 --> 2 - Missing argument 1 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Error - 2013-10-15 22:21:37 --> 8 - Undefined variable: args in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
Warning - 2013-10-15 22:21:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:21:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:22:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:22:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:22:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:22:32 --> 2 - Missing argument 1 for Controller_ShowListings::action_returnimages() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 36
Warning - 2013-10-15 22:22:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:22:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:22:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:22:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:22:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:22:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:22:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:23:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:23:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:23:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:23:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:23:21 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 42
Error - 2013-10-15 22:23:21 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:23:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:23:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:23:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:23:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:23:33 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 42
Error - 2013-10-15 22:23:33 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:23:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:24:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:24:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:24:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:25:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:25:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:25:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:28:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:31:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:31:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:31:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:31:23 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2013-10-15 22:31:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:31:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:33:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:33:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:33:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:33:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:33:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:33:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:46:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:46:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:46:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:46:17 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2013-10-15 22:46:17 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe|mascot|rozelle'' at line 1 with query: "SELECT * FROM `images` WHERE location REGEXP $max'glebe|mascot|rozelle'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:46:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:46:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:46:26 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2013-10-15 22:46:26 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''glebe|mascot|rozelle'' at line 1 with query: "SELECT * FROM `images` WHERE location REGEXP $max'glebe|mascot|rozelle'" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 22:46:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:46:49 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Error - 2013-10-15 22:46:49 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:46:49 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:46:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:46:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:47:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:47:44 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 22:47:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:47:57 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-10-15 22:47:57 --> 8 - Undefined variable: limit in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-10-15 22:47:57 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:47:57 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:47:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:47:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:48:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:48:22 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-10-15 22:48:22 --> 8 - Undefined variable: limit in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Warning - 2013-10-15 22:48:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:48:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:49:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:49:00 --> 8 - Undefined variable: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 33
Error - 2013-10-15 22:49:00 --> 8 - Undefined variable: limit in C:\wamp\fuel\app\classes\model\showlistings.php on line 33
Error - 2013-10-15 22:49:00 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:00 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:49:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:49:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:49:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:49:23 --> 8 - Undefined variable: limit in C:\wamp\fuel\app\classes\model\showlistings.php on line 33
Error - 2013-10-15 22:49:23 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:23 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:49:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:49:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:49:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:49:50 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:49:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:49:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:50:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:50:26 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:50:26 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:50:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:50:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:50:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 22:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 22:50:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 22:50:53 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 22:50:53 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 22:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 22:50:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:01:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:01:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:01:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:01:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:01:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:01:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:01:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:01:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:01:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:01:47 --> 8 - Undefined variable: max in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Warning - 2013-10-15 23:01:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:01:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:02:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:02:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:02:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:02:26 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-10-15 23:02:26 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle'limit -1,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:02:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:02:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:02:34 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-10-15 23:02:34 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle'limit -1,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:02:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:02:54 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-10-15 23:02:54 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle' limit -1,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:03:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:03:18 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2013-10-15 23:03:19 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1,8' at line 1 with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP 'glebe|mascot|rozelle'  limit -1,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:05:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:05:53 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 23:05:53 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 23:05:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:05:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:06:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:06:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:06:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:06:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:06:11 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Error - 2013-10-15 23:06:11 --> 8 - Undefined offset: 9 in C:\wamp\fuel\app\views\listings\listings.php on line 28
Warning - 2013-10-15 23:06:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:06:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:15:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:15:38 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\views\listings\listings.php on line 26
Error - 2013-10-15 23:15:38 --> 8 - Undefined variable: result in C:\wamp\fuel\app\views\listings\listings.php on line 26
Warning - 2013-10-15 23:15:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:15:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:23:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:23:01 --> 8 - Undefined variable: page_limit in C:\wamp\fuel\app\views\listings\listings.php on line 26
Warning - 2013-10-15 23:23:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:23:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:25:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:25:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:25:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:25:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:25:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:25:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:25:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:25:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:26:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:26:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:26:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:26:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:26:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:27:04 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 38
Error - 2013-10-15 23:27:04 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:27:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:28:11 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 38
Error - 2013-10-15 23:28:11 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:28:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:28:20 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 38
Error - 2013-10-15 23:28:20 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:28:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:28:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:28:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:28:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:28:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:38:00 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 23:38:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:38:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:38:00 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 39
Error - 2013-10-15 23:38:00 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:38:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:38:48 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 23:38:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:38:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:38:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:38:49 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 39
Error - 2013-10-15 23:38:49 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:39:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:39:01 --> 8 - Undefined index: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 23:39:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:39:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:39:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:39:01 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 39
Error - 2013-10-15 23:39:01 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:39:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:39:07 --> 8 - Undefined index: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 23:39:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:39:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:39:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:39:08 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 39
Error - 2013-10-15 23:39:08 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:39:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:39:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:39:34 --> 8 - Undefined index: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 23:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:39:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:39:53 --> 8 - Undefined index: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 26
Warning - 2013-10-15 23:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:44:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:44:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:44:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:44:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:44:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:44:41 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11
Warning - 2013-10-15 23:44:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:44:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:44:51 --> Parsing Error - syntax error, unexpected '[' in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11
Warning - 2013-10-15 23:46:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:46:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:46:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:46:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:46:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:47:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:47:10 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-10-15 23:47:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:47:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:47:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:47:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:47:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:48:09 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 43
Warning - 2013-10-15 23:48:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:48:29 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:29 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:29 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Warning - 2013-10-15 23:48:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:48:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:48:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 2 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 3 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 6 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Error - 2013-10-15 23:48:37 --> 8 - Undefined offset: 7 in C:\wamp\fuel\app\views\listings\listings.php on line 30
Warning - 2013-10-15 23:48:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:48:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:52:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:52:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:52:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:52:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:52:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:53:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:06 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:06 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:06 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:06 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:07 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:07 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:07 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:07 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:08 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:08 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:08 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:08 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:09 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:09 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:09 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:09 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:10 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:10 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:10 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:10 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:10 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:10 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:10 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:10 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:11 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:11 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:11 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:11 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:12 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:12 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:12 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:12 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:12 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:12 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:12 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:12 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:13 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:13 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:13 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:13 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:53:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:53:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:53:22 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 11
Error - 2013-10-15 23:53:22 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\model\showlistings.php on line 14
Error - 2013-10-15 23:53:22 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-10-15 23:53:22 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:56:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:56:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:56:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:56:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-15 23:56:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-15 23:57:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:57:03 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2013-10-15 23:57:03 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:57:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:57:04 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2013-10-15 23:57:04 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:57:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:57:04 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2013-10-15 23:57:04 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:57:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:57:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-10-15 23:57:15 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2013-10-15 23:57:15 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-10-15 23:59:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:59:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:59:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-15 23:59:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
