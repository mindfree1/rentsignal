<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-10-19 11:00:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:00:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:00:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:02:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:02:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:02:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:02:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:02:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:02:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:02:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:03:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:03:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:03:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:03:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:03:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:03:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:05:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-10-19 11:05:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-10-19 11:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-10-19 11:05:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
