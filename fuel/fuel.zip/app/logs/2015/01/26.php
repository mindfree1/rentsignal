<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-01-26 19:28:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:28:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-26 19:34:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
