<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-11-19 20:31:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-11-19 20:31:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-11-19 20:31:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-11-19 21:14:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-11-19 21:14:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:15:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:15:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:15:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:15:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:16:04 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 56
WARNING - 2014-11-19 21:16:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:16:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:16:18 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:16:18 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:16:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:16:46 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:16:46 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:18:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:18:28 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:18:28 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:18:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:18:39 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:18:39 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:20:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:20:01 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:20:01 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:20:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:20:10 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:20:10 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:20:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:20:26 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:20:26 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:20:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:20:42 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:20:42 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:20:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:20:48 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:20:48 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:20:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:20:58 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:20:58 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:21:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:21:08 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:21:08 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:21:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:21:37 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:21:37 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP glebe ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:21:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:21:59 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:21:59 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\showlistings.php on line 24
WARNING - 2014-11-19 21:23:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:23:28 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:23:28 --> 1054 - Unknown column 'glebe' in 'where clause' [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location=glebe ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:23:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:23:42 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:23:42 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` WHERE location REGEXP '' limit 1,8 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-11-19 21:24:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:24:23 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:24:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:24:45 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:24:45 --> 8 - Undefined offset: 1 in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-11-19 21:25:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:25:04 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:25:04 --> 8 - Undefined index: glebe in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-11-19 21:25:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:25:17 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:25:17 --> 8 - Undefined index: glebe in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-11-19 21:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:25:31 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:25:31 --> 8 - Undefined index: glebe in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
WARNING - 2014-11-19 21:25:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:25:45 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:29:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:29:36 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:29:38 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:29:41 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:29:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:29:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:30:10 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:30:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:30:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:30:25 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:30:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:30:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:34:31 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
ERROR - 2014-11-19 21:34:31 --> Parsing Error - syntax error, unexpected ';', expecting T_FUNCTION in C:\wamp\fuel\app\classes\model\showlistings.php on line 144
WARNING - 2014-11-19 21:35:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:35:08 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:36:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:36:09 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 46
WARNING - 2014-11-19 21:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:36:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:36:35 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:36:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:36:41 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:36:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:36:48 --> 8 - Undefined index: loc1 in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:37:29 --> Parsing Error - syntax error, unexpected T_IF in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:39:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:39:31 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:39:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:39:40 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:39:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:39:43 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:39:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:39:48 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:39:50 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:39:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:40:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:40:33 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:40:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:40:44 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:41:12 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:41:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:41:15 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:41:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:41:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:41:37 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:41:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:41:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:41:41 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:41:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:41:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:41:46 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:41:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:41:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:41:55 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:42:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:42:10 --> Fatal Error - Call to undefined method Model\ShowListings::search_favpopular() in C:\wamp\fuel\app\classes\controller\showlistings.php on line 40
WARNING - 2014-11-19 21:42:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:42:14 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:43:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:43:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:43:34 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 45
WARNING - 2014-11-19 21:44:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:44:36 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 50
WARNING - 2014-11-19 21:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:48:24 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 54
ERROR - 2014-11-19 21:48:24 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
WARNING - 2014-11-19 21:48:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:48:42 --> 8 - Undefined variable: data in C:\wamp\fuel\app\classes\controller\showlistings.php on line 54
ERROR - 2014-11-19 21:48:42 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 16
WARNING - 2014-11-19 21:49:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 21:49:04 --> Fatal Error - Cannot use [] for reading in C:\wamp\fuel\app\classes\controller\showlistings.php on line 54
WARNING - 2014-11-19 21:49:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:49:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:49:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:49:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:50:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:50:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:50:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:50:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:50:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:51:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:51:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:51:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:52:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 21:53:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:18:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:19:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 22:19:46 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 56
WARNING - 2014-11-19 22:20:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-11-19 22:20:31 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 56
WARNING - 2014-11-19 22:20:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:20:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:21:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:22:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:24:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-11-19 22:25:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
