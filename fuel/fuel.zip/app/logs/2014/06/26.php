<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-06-26 21:25:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 21:52:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:30:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:36:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:36:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:36:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:36:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 22:36:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 22:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:36:29 --> 1045 - SQLSTATE[28000] [1045] Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\www\fuel\core\classes\database\pdo\connection.php on line 86
Warning - 2014-06-26 22:36:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:37:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:40:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:40:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:40:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 22:40:27 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 22:40:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:40:34 --> 1045 - SQLSTATE[28000] [1045] Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 86
Warning - 2014-06-26 22:52:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:52:05 --> 1045 - SQLSTATE[28000] [1045] Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 85
Warning - 2014-06-26 22:52:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:52:12 --> 1045 - SQLSTATE[28000] [1045] Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 85
Warning - 2014-06-26 22:53:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:53:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:53:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 22:53:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 22:53:16 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 22:53:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:53:23 --> 1045 - SQLSTATE[28000] [1045] Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 85
Warning - 2014-06-26 22:57:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:57:25 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ')' in C:\wamp\fuel\app\config\db.php on line 22
Warning - 2014-06-26 22:57:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:57:40 --> 2 - mysqli::mysqli() [<a href='mysqli.mysqli'>mysqli.mysqli</a>]: (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 104
Error - 2014-06-26 22:57:40 --> 2 - Fuel\Core\Database_MySQLi_Connection::connect() [<a href='fuel\core\database-mysqli-connection.connect'>fuel\core\database-mysqli-connection.connect</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 106
Error - 2014-06-26 22:57:40 --> 2 - mysqli::set_charset() [<a href='mysqli.set-charset'>mysqli.set-charset</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 177
Error - 2014-06-26 22:57:40 --> 2 - mysqli::real_escape_string() [<a href='mysqli.real-escape-string'>mysqli.real-escape-string</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 409
Error - 2014-06-26 22:57:40 --> 2 - mysqli::real_escape_string() [<a href='mysqli.real-escape-string'>mysqli.real-escape-string</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 409
Error - 2014-06-26 22:57:40 --> 2 - mysqli::real_escape_string() [<a href='mysqli.real-escape-string'>mysqli.real-escape-string</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 409
Error - 2014-06-26 22:57:40 --> 2 - mysqli::query() [<a href='mysqli.query'>mysqli.query</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 203
Error - 2014-06-26 22:57:40 --> 2 - mysqli::more_results() [<a href='mysqli.more-results'>mysqli.more-results</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 215
Error - 2014-06-26 22:57:40 --> 8 - Trying to get property of non-object in C:\wamp\fuel\core\classes\database\mysqli\result.php on line 24
Error - 2014-06-26 22:57:40 --> Error - Call to a member function fetch_assoc() on a non-object in C:\wamp\fuel\core\classes\database\mysqli\result.php on line 72
Warning - 2014-06-26 22:58:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 22:58:00 --> 2 - mysqli::mysqli() [<a href='mysqli.mysqli'>mysqli.mysqli</a>]: (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 104
Error - 2014-06-26 22:58:00 --> 2 - Fuel\Core\Database_MySQLi_Connection::connect() [<a href='fuel\core\database-mysqli-connection.connect'>fuel\core\database-mysqli-connection.connect</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 106
Error - 2014-06-26 22:58:00 --> 2 - mysqli::set_charset() [<a href='mysqli.set-charset'>mysqli.set-charset</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 177
Error - 2014-06-26 22:58:00 --> 2 - mysqli::real_escape_string() [<a href='mysqli.real-escape-string'>mysqli.real-escape-string</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 409
Error - 2014-06-26 22:58:00 --> 2 - mysqli::real_escape_string() [<a href='mysqli.real-escape-string'>mysqli.real-escape-string</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 409
Error - 2014-06-26 22:58:00 --> 2 - mysqli::real_escape_string() [<a href='mysqli.real-escape-string'>mysqli.real-escape-string</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 409
Error - 2014-06-26 22:58:00 --> 2 - mysqli::query() [<a href='mysqli.query'>mysqli.query</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 203
Error - 2014-06-26 22:58:00 --> 2 - mysqli::more_results() [<a href='mysqli.more-results'>mysqli.more-results</a>]: Couldn't fetch mysqli in C:\wamp\fuel\core\classes\database\mysqli\connection.php on line 215
Error - 2014-06-26 22:58:00 --> 8 - Trying to get property of non-object in C:\wamp\fuel\core\classes\database\mysqli\result.php on line 24
Error - 2014-06-26 22:58:00 --> Error - Call to a member function fetch_assoc() on a non-object in C:\wamp\fuel\core\classes\database\mysqli\result.php on line 72
Warning - 2014-06-26 23:00:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:00:11 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-06-26 23:00:11 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-06-26 23:00:11 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:00:11 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:00:11 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-06-26 23:01:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:01:07 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-06-26 23:01:07 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-06-26 23:01:07 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:01:07 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:01:07 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-06-26 23:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:01:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 23:01:10 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 23:01:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:01:16 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-06-26 23:01:16 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-06-26 23:01:16 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:01:16 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:01:16 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-06-26 23:02:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:02:52 --> 2 - mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 96
Error - 2014-06-26 23:02:52 --> 2 - mysql_select_db() expects parameter 2 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 127
Error - 2014-06-26 23:02:52 --> 2 - mysql_error() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:02:52 --> 2 - mysql_errno() expects parameter 1 to be resource, boolean given in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Error - 2014-06-26 23:02:52 --> Error -  in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 130
Warning - 2014-06-26 23:09:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:17:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:17:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:17:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 23:17:43 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-26 23:17:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:17:48 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-06-26 23:17:48 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-06-26 23:17:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:17:48 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-06-26 23:17:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:18:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:18:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:18:05 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-06-26 23:18:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:07 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-06-26 23:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:27:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:36:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:36:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:36:37 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-06-26 23:36:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:36:48 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:38:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:39:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:41:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:41:30 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\core\classes\asset.php on line 81
Error - 2014-06-26 23:41:30 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:41:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:41:39 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Error - 2014-06-26 23:41:39 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\core\classes\asset.php on line 81
Error - 2014-06-26 23:41:39 --> Error - Could not find asset: bootstrap.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:41:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:41:43 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\core\classes\asset.php on line 81
Error - 2014-06-26 23:41:43 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:41:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:41:49 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\core\classes\asset.php on line 81
Error - 2014-06-26 23:41:49 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:42:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:42:06 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\core\classes\asset.php on line 81
Error - 2014-06-26 23:42:06 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:42:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:42:23 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:42:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:42:36 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:42:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:42:38 --> Error - Could not find asset: layout.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2014-06-26 23:42:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:43:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:44:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:44:07 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2014-06-26 23:44:07 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-06-26 23:44:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:44:13 --> 8 - Undefined index: locations in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12
Error - 2014-06-26 23:44:13 --> 1139 - Got error 'empty (sub)expression' from regexp [ SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP '' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 210
Warning - 2014-06-26 23:47:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:47:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:47:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:47:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:47:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:47:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:47:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:47:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:47:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:48:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:48:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:48:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:48:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:48:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:48:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:48:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:48:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-06-26 23:48:34 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 40
Warning - 2014-06-26 23:48:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:48:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:49:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:49:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-26 23:49:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-26 23:49:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-26 23:49:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
