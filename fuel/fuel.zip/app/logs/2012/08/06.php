<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-06 23:26:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:29:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:30:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:34:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:34:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:35:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-06 23:35:47 --> Error - The requested view could not be found: welcome/index in C:\wamp\www\fuel\core\classes\view.php on line 389
Warning - 2012-08-06 23:36:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-06 23:36:49 --> Error - Could not find asset: init.js in C:\wamp\www\fuel\core\classes\asset.php on line 154
Warning - 2012-08-06 23:37:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-08-06 23:37:05 --> Error - Could not find asset: init.js in C:\wamp\www\fuel\core\classes\asset.php on line 154
Warning - 2012-08-06 23:37:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-06 23:40:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
