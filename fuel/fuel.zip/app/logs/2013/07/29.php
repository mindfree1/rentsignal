<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-07-29 21:07:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 21:08:02 --> 2 - PDO::__construct() [<a href='pdo.--construct'>pdo.--construct</a>]: [2002] No connection could be made because the target machine actively  (trying to connect via tcp://localhost:3306) in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 82
Error - 2013-07-29 21:08:02 --> 2002 - SQLSTATE[HY000] [2002] No connection could be made because the target machine actively refused it.
 in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 86
Warning - 2013-07-29 21:08:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:08:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:08:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:08:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:08:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:08:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:09:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:09:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:09:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:09:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:09:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:10:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:10:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:10:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:18:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:18:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:18:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:18:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:22:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:22:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 21:22:19 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 21:22:19 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 21:22:19 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 21:22:19 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 21:22:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:22:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:22:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:22:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:22:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:22:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 21:23:13 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 21:23:13 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 21:23:13 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 21:23:13 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 21:23:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:23:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:23:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:23:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:23:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:23:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 21:24:46 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 21:24:46 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 21:24:46 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 21:24:46 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 21:24:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:24:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:24:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:25:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:36:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:36:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:36:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:36:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:36:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:37:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:37:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:37:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:37:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:38:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:38:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:38:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:39:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:39:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:40:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:40:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:40:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:41:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:41:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 21:41:19 --> 8 - Undefined variable: <ul id="pagination">
	<li id="1">1</li></a></ul>
<script>
	//Pagination Click
	$("#pagination li").click(function(){
	
	//CSS Styles
	$("#pagination li")
		.css({'border' : 'solid #dddddd 1px'})
		.css({'color' : '#0063DC'});

	$(this)
		.css({'color' : '#FF0084'})
		.css({'border' : 'none'});

	//Loading Data
	
	var pageNum = this.id;
	if(pageNum == 0 || pageNum == null || pageNum == '')
	{
		pageNum = 1;
	}

	$("#content").load("http://rentsignal.com/showlistings/getListings");
});
</script>
<img width="120px" height="120px" src="http://rentsignal.com/public/assets/img/sydnenham-deg.jpg" style="padding-right:6px;"</><id><p>im here why arent the images?</p></div><img width="120px" height="120px" src="http://rentsignal.com/public/assets/img/mascot-eg-resized.jpg" style="padding-right:6px;"</><id><p>im here why arent the images?</p></div><img width="120px" height="120px" src="http://rentsignal.com/public/assets/img/sydnenham-deg2-resized.jpg" style="padding-right:6px;"</><id><p>im here why arent the images?</p></div><img width="120px" height="120px" src="http://rentsignal.com/public/assets/img/sydnenham-deg3-resized.jpg" style="padding-right:6px;"</><id><p>im here why arent the images?</p></div><img width="120px" height="120px" src="http://rentsignal.com/public/assets/img/sydnenham-deg5-resized.jpg" style="padding-right:6px;"</><id><p>im here why arent the images?</p></div><script></script>
 in C:\wamp\fuel\app\classes\model\mapgen.php on line 41
Warning - 2013-07-29 21:41:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:41:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:42:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:42:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:42:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:42:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:42:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:42:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:42:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:43:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:43:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:43:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:44:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:44:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:44:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:44:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:44:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:44:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:49:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:49:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:49:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:49:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 21:49:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:49:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:49:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:49:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 21:49:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 21:49:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:03:32 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:03:32 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:03:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:03:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:04:36 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:04:36 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:04:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:04:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:04:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:04:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:04:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:05:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:05:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:05:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:05:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:05:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:05:45 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:05:45 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:05:45 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:05:45 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:05:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:05:59 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:05:59 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:05:59 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:05:59 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:06:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:06:07 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:06:07 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:06:07 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:06:07 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:06:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:06:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:06:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:06:10 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:06:10 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:06:10 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:06:10 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:06:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:06:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:06:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:06:29 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:06:29 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:06:29 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:06:29 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:06:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:06:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:07:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:07:02 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:07:02 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:07:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:07:02 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:07:02 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:07:02 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:07:02 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:07:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:07:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:07:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:07:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:07:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:07:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:08:03 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:08:03 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:08:04 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:08:04 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:08:04 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:08:04 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:08:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:08:53 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 12 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:08:53 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:08:53 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:08:53 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:08:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:09:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:09:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:09:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:10:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:10:53 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:10:53 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:10:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:10:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:10:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:11:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:11:26 --> Error - Class 'Mapgen' not found in C:\wamp\fuel\app\views\welcome\index.php on line 94
Warning - 2013-07-29 23:11:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:11:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:11:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:12:00 --> 8 - Undefined variable: data in C:\wamp\fuel\app\views\welcome\index.php on line 96
Error - 2013-07-29 23:12:00 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN  AND" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:13:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:13:22 --> 8 - Undefined variable: i in C:\wamp\fuel\app\views\welcome\index.php on line 95
Error - 2013-07-29 23:13:22 --> 8 - Undefined variable: img_url in C:\wamp\fuel\app\views\welcome\index.php on line 95
Warning - 2013-07-29 23:13:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:13:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:13:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:15:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:15:01 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:15:01 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:15:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:15:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:15:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:15:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:15:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:17:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:17:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:17:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:24:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:24:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:24:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:24:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:24:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:25:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:25:18 --> Error - Call to undefined method Fuel\Core\Response::render() in C:\wamp\fuel\app\classes\model\showlistings.php on line 71
Warning - 2013-07-29 23:25:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:25:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:26:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:26:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:26:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:29:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:29:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:29:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:29:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:29:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:29:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:29:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:29:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:29:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:36:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:36:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:36:51 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 95
Warning - 2013-07-29 23:36:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:36:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:37:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:37:22 --> 8 - Undefined variable: page_nums in C:\wamp\fuel\app\views\listings\listings.php on line 3
Error - 2013-07-29 23:37:22 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-07-29 23:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:37:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:37:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:38:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:39:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:39:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:39:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:43:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:43:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:43:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:43:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:43:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:43:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:43:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:45:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:45:22 --> 8 - Undefined variable: allcoords in C:\wamp\fuel\app\views\welcome\index.php on line 14
Error - 2013-07-29 23:45:22 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\views\welcome\index.php on line 15
Warning - 2013-07-29 23:45:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:45:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:45:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:45:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:45:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:45:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:46:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:46:48 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:46:48 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:46:48 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:46:48 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:46:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:46:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:48:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:48:46 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:48:46 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:48:46 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:48:46 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:48:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:48:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:48:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:48:48 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:48:48 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:48:48 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:48:48 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:48:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:48:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:48:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:48:53 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:48:53 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:48:53 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:48:53 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:48:53 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:48:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:48:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:49:02 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:49:02 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:49:02 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:49:02 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:49:02 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:49:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:49:11 --> 2 - Missing argument 1 for Model\ShowListings::get_results(), called in C:\wamp\fuel\app\classes\controller\showlistings.php on line 11 and defined in C:\wamp\fuel\app\classes\model\showlistings.php on line 13
Error - 2013-07-29 23:49:11 --> 8 - Undefined variable: imagedata in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:49:11 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:49:11 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:49:11 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:49:35 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:49:35 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:49:35 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:49:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:49:37 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in C:\wamp\fuel\app\classes\model\showlistings.php on line 15
Error - 2013-07-29 23:49:37 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:49:37 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1139 Got error 'empty (sub)expression' from regexp with query: "SELECT * FROM `images` INNER JOIN rentsignals ON images.location=rentsignals.location WHERE images.location REGEXP ''" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:49:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:50:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:50:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:50:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:50:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:50:44 --> 8 - Undefined index: rentmin in C:\wamp\fuel\app\classes\controller\showlistings.php on line 22
Error - 2013-07-29 23:50:44 --> 8 - Undefined index: rentmax in C:\wamp\fuel\app\classes\controller\showlistings.php on line 23
Error - 2013-07-29 23:50:44 --> 8 - Undefined index: rooms in C:\wamp\fuel\app\classes\controller\showlistings.php on line 24
Error - 2013-07-29 23:50:44 --> 8 - Undefined index: bathrooms in C:\wamp\fuel\app\classes\controller\showlistings.php on line 25
Error - 2013-07-29 23:50:44 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND' at line 1 with query: "SELECT * FROM `rentsignals` WHERE rent BETWEEN  AND" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2013-07-29 23:50:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:50:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:51:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:51:38 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:51:38 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
Warning - 2013-07-29 23:51:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:51:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-29 23:51:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:51:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:52:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:52:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-29 23:52:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-29 23:52:03 --> 8 - Undefined index: page in C:\wamp\fuel\app\classes\model\showlistings.php on line 25
Error - 2013-07-29 23:52:03 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
Warning - 2013-07-29 23:52:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-29 23:52:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
