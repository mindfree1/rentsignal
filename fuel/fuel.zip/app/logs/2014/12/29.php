<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2014-12-29 01:12:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:12:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:12:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:12:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:12:04 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:12:06 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:12:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:12:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:12:24 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:12:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:12:40 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:12:40 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:13:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:13:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:13:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:13:56 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:13:56 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:13:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:13:56 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:13:56 --> Parsing Error - syntax error, unexpected ')' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:14:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:14:36 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:14:36 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 01:14:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:14:36 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:14:36 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 01:16:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:16:12 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:16:12 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::HAVING_COUNT() in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:16:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:16:12 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:16:12 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::HAVING_COUNT() in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:21 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:21 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:21 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:21 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:46 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:46 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:46 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:46 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:49 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:49 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:49 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:49 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:51 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:51 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:22:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:22:51 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:22:51 --> Parsing Error - syntax error, unexpected '(', expecting T_STRING or T_VARIABLE or '{' or '$' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:24:44 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:24:44 --> Parsing Error - syntax error, unexpected T_PAAMAYIM_NEKUDOTAYIM in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:24:44 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:24:44 --> Parsing Error - syntax error, unexpected T_PAAMAYIM_NEKUDOTAYIM in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:25:03 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:25:03 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:25:03 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:25:03 --> Parsing Error - syntax error, unexpected T_STRING in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 01:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:25:20 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:25:20 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN ((null)) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:25:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:25:20 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:25:20 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN ((null)) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:27:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:27:48 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:27:48 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN ((null)) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:27:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:27:48 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 01:27:48 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN ((null)) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:28:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:28:03 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:28:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:28:03 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:28:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:28:24 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:28:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:28:24 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:28:41 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:28:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:28:41 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT COUNT(*) as count FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:29:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:29:40 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as count)' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND (COUNT(*) as count) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:29:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:29:40 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as count)' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND (COUNT(*) as count) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:30:45 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 01:30:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:30:45 --> Parsing Error - syntax error, unexpected ';' in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 01:31:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:31:03 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'HAVING count("propimg_id") > 1)' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND (HAVING count("propimg_id") > 1) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:31:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:31:03 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'HAVING count("propimg_id") > 1)' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND (HAVING count("propimg_id") > 1) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:31:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:31:32 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:31:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:31:33 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:32:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:32:09 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'HAVING count(propimg_id) > 1)' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND (HAVING count(propimg_id) > 1) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:32:10 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'HAVING count(propimg_id) > 1)' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND (HAVING count(propimg_id) > 1) ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:34:27 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(propimg_id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(propimg_id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:34:27 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(propimg_id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(propimg_id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:34:59 --> 1054 - Unknown column 'count(propimg_id)' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count(propimg_id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:34:59 --> 1054 - Unknown column 'count(propimg_id)' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count(propimg_id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:35:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:35:53 --> 1054 - Unknown column 'count("propimg_id")' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count("propimg_id")` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:35:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:35:53 --> 1054 - Unknown column 'count("propimg_id")' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count("propimg_id")` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:36:14 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 80
WARNING - 2014-12-29 01:36:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:36:14 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 80
WARNING - 2014-12-29 01:36:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:36:59 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 80
WARNING - 2014-12-29 01:36:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:36:59 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 80
WARNING - 2014-12-29 01:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:37:58 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `id` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `id` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:37:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:37:58 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `id` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `id` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:38:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:38:24 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 01:38:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:38:24 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 01:39:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:04 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\mapgen.php on line 66
WARNING - 2014-12-29 01:39:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:04 --> Parsing Error - syntax error, unexpected T_VARIABLE in C:\wamp\fuel\app\classes\model\mapgen.php on line 66
WARNING - 2014-12-29 01:39:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:13 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:39:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:13 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:46 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:39:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:46 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:39:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:49 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:39:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:39:49 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') HAVING `count(id)` > '1'' at line 1 [ SELECT * FROM `images` WHERE `location` IN (('glebe')) AND () HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:40:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:40:46 --> 1054 - Unknown column 'count(id)' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:40:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:40:46 --> 1054 - Unknown column 'count(id)' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count(id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:41:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:41:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:42:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:42:58 --> 1054 - Unknown column 'count(propimg_id)' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count(propimg_id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:42:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:42:58 --> 1054 - Unknown column 'count(propimg_id)' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `count(propimg_id)` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:44:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:44:03 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 62
ERROR - 2014-12-29 01:44:04 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `1` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:44:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:44:04 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 62
ERROR - 2014-12-29 01:44:04 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `1` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:44:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:44:25 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `1` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:44:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:44:26 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `1` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:44:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:44:28 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `1` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:44:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:44:28 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) HAVING `1` > '1' ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 01:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:46:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:46:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:47:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:47:59 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 01:47:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:48:00 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 01:48:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:48:09 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 01:48:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:48:09 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 01:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:48:16 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 01:48:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 01:48:16 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 01:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:48:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:48:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:48:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 01:48:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 09:36:22 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
WARNING - 2014-12-29 09:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 09:36:22 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 09:36:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:36:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 09:36:55 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 79
WARNING - 2014-12-29 09:37:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:37:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 09:38:00 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 09:38:00 --> 8 - Use of undefined constant console - assumed 'console' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 09:38:00 --> 2 - log() expects parameter 1 to be double, object given in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
WARNING - 2014-12-29 09:38:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 09:38:00 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 81
WARNING - 2014-12-29 09:38:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 09:38:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 09:38:14 --> 8 - Use of undefined constant console - assumed 'console' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 09:38:14 --> 2 - log() expects parameter 1 to be double, object given in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 09:38:14 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 81
WARNING - 2014-12-29 10:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:00:15 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:00:15 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
WARNING - 2014-12-29 10:00:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:00:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:00:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:00:28 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
WARNING - 2014-12-29 10:00:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:00:46 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:00:46 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
WARNING - 2014-12-29 10:01:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:01:02 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:01:02 --> Fatal Error - Class 'Model\Profiler' not found in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 10:01:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:01:02 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:01:02 --> Fatal Error - Class 'Model\Profiler' not found in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 10:06:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:06:15 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:06:15 --> Fatal Error - Class 'Model\Profiler' not found in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 10:06:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:06:15 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:06:15 --> Fatal Error - Class 'Model\Profiler' not found in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 10:06:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:06:39 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:06:39 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-29 10:06:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:06:39 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
ERROR - 2014-12-29 10:06:39 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 83
WARNING - 2014-12-29 10:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:07:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:07:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:08:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:08:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:08:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:08:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:09:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:09:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:09:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:09:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:11:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:11:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:11:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:11:37 --> 8 - Undefined variable: propimg_id in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:11:37 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:11:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:11:37 --> 8 - Undefined variable: propimg_id in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:11:38 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:00 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:12:00 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:00 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:12:00 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:22 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:22 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:44 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:44 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:45 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:47 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:12:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:12:47 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 82
WARNING - 2014-12-29 10:13:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:13:10 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('mascot')) HAVING `1` > 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:13:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:13:10 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('mascot')) HAVING `1` > 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:13:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:13:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:14:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:14:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:14:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:14:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:19:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:19:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:19:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:19:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:21:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:21:40 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) GROUP BY `propimg_id` HAVING `1` > 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:21:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:21:40 --> 1054 - Unknown column '1' in 'having clause' [ SELECT * FROM `images` WHERE `location` IN (('glebe')) GROUP BY `propimg_id` HAVING `1` > 1 ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:25:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:25:09 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 81
WARNING - 2014-12-29 10:25:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:25:09 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 81
WARNING - 2014-12-29 10:25:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:25:30 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 81
WARNING - 2014-12-29 10:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:25:31 --> 8 - Undefined variable: imageurls in C:\wamp\fuel\app\classes\model\mapgen.php on line 81
WARNING - 2014-12-29 10:25:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:25:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:26:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:45:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:45:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:46:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:46:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 10:50:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:50:44 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:50:44 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:50:44 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:50:44 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:50:44 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null AND `location` IN (('mascot')) GROUP BY `propimg_id`' at line 1 [ SELECT * FROM `images` WHERE `1`  null AND `location` IN (('mascot')) GROUP BY `propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:50:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:50:44 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:50:44 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:50:45 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:50:45 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:50:45 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null AND `location` IN (('mascot')) GROUP BY `propimg_id`' at line 1 [ SELECT * FROM `images` WHERE `1`  null AND `location` IN (('mascot')) GROUP BY `propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:51:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:51:31 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:31 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:31 --> 8 - Object of class Fuel\Core\Database_Query_Builder_Select could not be converted to int in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:51:31 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null AND `location` IN (('mascot')) GROUP BY `propimg_id`' at line 1 [ SELECT * FROM `images` WHERE ``  null AND `location` IN (('mascot')) GROUP BY `propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:51:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:51:31 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:31 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:31 --> 8 - Object of class Fuel\Core\Database_Query_Builder_Select could not be converted to int in C:\wamp\fuel\app\classes\model\mapgen.php on line 64
ERROR - 2014-12-29 10:51:31 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null AND `location` IN (('mascot')) GROUP BY `propimg_id`' at line 1 [ SELECT * FROM `images` WHERE ``  null AND `location` IN (('mascot')) GROUP BY `propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:51:55 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:55 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:55 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `1`  null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:51:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:51:55 --> 8 - Use of undefined constant images - assumed 'images' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:55 --> 8 - Use of undefined constant propimg_id - assumed 'propimg_id' in C:\wamp\fuel\app\classes\model\mapgen.php on line 63
ERROR - 2014-12-29 10:51:55 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null' at line 1 [ SELECT * FROM `images` WHERE `1`  null ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:52:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:52:28 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null GROUP BY `propimg_id`' at line 1 [ SELECT * FROM `images` WHERE `propimg_id`  null GROUP BY `propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 10:52:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 10:52:28 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'null GROUP BY `propimg_id`' at line 1 [ SELECT * FROM `images` WHERE `propimg_id`  null GROUP BY `propimg_id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 11:03:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 11:03:45 --> Fatal Error - Call to undefined function Model\on() in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 11:03:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 11:03:45 --> Fatal Error - Call to undefined function Model\on() in C:\wamp\fuel\app\classes\model\mapgen.php on line 65
WARNING - 2014-12-29 11:04:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:07:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:07:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:11:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:31:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:31:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:32:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:32:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:32:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:32:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:32:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 11:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 11:33:21 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (('glebe')) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 11:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 11:33:21 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (('glebe')) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 11:34:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 11:34:04 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (('glebe')) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 11:34:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 11:34:04 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN (('glebe')) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
WARNING - 2014-12-29 19:20:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2014-12-29 19:20:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 19:20:30 --> 8 - Undefined index: location in C:\wamp\fuel\app\classes\controller\propertydetails.php on line 15
WARNING - 2014-12-29 19:20:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
ERROR - 2014-12-29 19:20:31 --> 1052 - Column 'location' in where clause is ambiguous [ SELECT * FROM `images` LEFT OUTER JOIN `rentsignals` ON (`rentsignals`.`id` = `images`.`propimg_id`) WHERE `location` IN ((null)) GROUP BY `rentsignals`.`id` ] in C:\wamp\fuel\core\classes\database\mysql\connection.php on line 257
