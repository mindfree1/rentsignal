<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-06-16 00:38:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:38:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:38:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:39:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:40:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:41:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:41:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:41:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:44:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:45:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:45:54 --> 8 - Undefined variable: content in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Warning - 2012-06-16 00:46:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:46:35 --> 8 - Undefined variable: content in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Warning - 2012-06-16 00:47:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:47:26 --> 8 - Undefined variable: content in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Warning - 2012-06-16 00:49:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:49:10 --> 8 - Undefined variable: data in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Error - 2012-06-16 00:49:10 --> Error - The requested view could not be found: rentsignal/index in C:\wamp\www\rentsignal\fuel\core\classes\view.php on line 389
Warning - 2012-06-16 00:49:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:49:26 --> 8 - Undefined variable: data in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Error - 2012-06-16 00:49:26 --> Error - Using $this when not in object context in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Warning - 2012-06-16 00:49:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:49:41 --> 8 - Undefined variable: data in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Error - 2012-06-16 00:49:41 --> Error - Using $this when not in object context in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Warning - 2012-06-16 00:49:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:49:52 --> 8 - Undefined variable: data in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 43
Error - 2012-06-16 00:49:52 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 00:50:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:50:22 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 00:50:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:51:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:51:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:51:17 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 'description' in 'field list' with query: "INSERT INTO `rentsignals` (`title`, `description`, `lat`, `long`, `rent`, `avail_from`, `created_at`, `updated_at`) VALUES ('test', 'test', '324', '234', '$123', '$220', 1339771877, 1339771877)" in C:\wamp\www\rentsignal\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-06-16 00:53:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:53:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 00:53:23 --> Error - The requested view could not be found: rentsingals/index in C:\wamp\www\rentsignal\fuel\core\classes\view.php on line 389
Warning - 2012-06-16 00:56:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 00:59:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:00:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:00:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:00:05 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 01:00:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:00:14 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 01:00:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:00:19 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 01:01:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:01:02 --> 8 - Undefined variable: rentsignal in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 01:02:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:02:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:02:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:02:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:02:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:02:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:03:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:03:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:03:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:03:42 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 01:05:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:05:40 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 42
Warning - 2012-06-16 01:06:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:06:07 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 37
Warning - 2012-06-16 01:06:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:06:58 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 36
Warning - 2012-06-16 01:06:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:06:59 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 36
Warning - 2012-06-16 01:09:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:09:05 --> Error - Class 'Model_Rentsignals' not found in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 17
Warning - 2012-06-16 01:10:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:11:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:11:52 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 33
Warning - 2012-06-16 01:12:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:12:15 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 33
Warning - 2012-06-16 01:13:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:13:12 --> Parsing Error - syntax error, unexpected T_ELSE in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 36
Warning - 2012-06-16 01:15:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:15:29 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\rentsignals\index.php on line 3
Warning - 2012-06-16 01:16:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:16:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:16:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:16:56 --> Error - Class 'Model_Rentsignal' not found in C:\wamp\www\rentsignal\fuel\app\classes\controller\rentsignals.php on line 15
Warning - 2012-06-16 01:18:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:18:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:18:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:20:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:20:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:21:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:21:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:21:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:23:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:24:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:24:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:24:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:24:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:24:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:24:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:31:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:31:49 --> Error - The requested view could not be found: mapgen/index in C:\wamp\www\rentsignal\fuel\core\classes\view.php on line 389
Warning - 2012-06-16 01:32:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:33:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:33:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:33:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:33:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:34:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:35:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:36:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:36:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:36:18 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'action NOT NULL,
	`load` action NOT NULL,
	`created_at` int(11) NOT NULL,
	`upda' at line 3 with query: "CREATE TABLE IF NOT EXISTS `mapgens` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`update` action NOT NULL,
	`load` action NOT NULL,
	`created_at` int(11) NOT NULL,
	`updated_at` int(11) NOT NULL,
	PRIMARY KEY `id` (`id`)
) DEFAULT CHARACTER SET utf8;" in C:\wamp\www\rentsignal\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-06-16 01:41:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:43:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:46:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:46:21 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Error - 2012-06-16 01:46:21 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Error - 2012-06-16 01:46:21 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 9
Error - 2012-06-16 01:46:21 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 9
Warning - 2012-06-16 01:47:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:47:34 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Error - 2012-06-16 01:47:34 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Error - 2012-06-16 01:47:34 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 9
Error - 2012-06-16 01:47:34 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 9
Warning - 2012-06-16 01:49:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:49:45 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 7
Error - 2012-06-16 01:49:45 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 7
Error - 2012-06-16 01:49:45 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Error - 2012-06-16 01:49:45 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Warning - 2012-06-16 01:50:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:50:42 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 7
Error - 2012-06-16 01:50:42 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 7
Error - 2012-06-16 01:50:42 --> 8 - Undefined variable: rentsignals in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Error - 2012-06-16 01:50:42 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 8
Warning - 2012-06-16 01:52:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 01:55:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:55:50 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 9
Warning - 2012-06-16 01:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:56:22 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 01:56:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:56:40 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 01:56:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 01:56:51 --> Parsing Error - syntax error, unexpected T_OBJECT_OPERATOR in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 02:00:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:00:54 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 74
Warning - 2012-06-16 02:02:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:02:32 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 73
Warning - 2012-06-16 02:02:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:02:33 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 73
Warning - 2012-06-16 02:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:02:35 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 73
Warning - 2012-06-16 02:02:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:02:35 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 73
Warning - 2012-06-16 02:03:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:03:02 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 73
Warning - 2012-06-16 02:03:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:03:03 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 73
Warning - 2012-06-16 02:03:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:03:15 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 72
Warning - 2012-06-16 02:07:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:07:31 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 72
Warning - 2012-06-16 02:07:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:07:32 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 72
Warning - 2012-06-16 02:07:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:07:32 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 72
Warning - 2012-06-16 02:07:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:07:46 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 69
Warning - 2012-06-16 02:07:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 02:07:48 --> Parsing Error - syntax error, unexpected $end in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 69
Warning - 2012-06-16 02:11:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 02:12:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 02:13:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 10:22:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 10:23:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 10:24:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 10:26:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 10:26:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 10:28:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 11:20:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 11:42:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 11:42:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-16 11:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 11:43:22 --> Parsing Error - syntax error, unexpected T_DOUBLE_ARROW, expecting '(' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 11:44:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 11:44:00 --> Parsing Error - syntax error, unexpected '=' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 11:46:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 11:46:00 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:46:00 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 11:46:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 11:46:16 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:46:16 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 11:46:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 11:46:40 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:46:40 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Warning - 2012-06-16 11:47:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-16 11:47:42 --> 8 - Undefined variable: value in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:47:42 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:47:42 --> 8 - Undefined variable: value in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-16 11:47:42 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-16 11:47:42 --> 8 - Undefined variable: value in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:47:42 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 12
Error - 2012-06-16 11:47:42 --> 8 - Undefined variable: value in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-16 11:47:42 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Warning - 2012-06-16 11:47:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
