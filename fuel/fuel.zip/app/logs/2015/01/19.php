<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2015-01-19 20:07:39 --> Fatal Error - Maximum execution time of 30 seconds exceeded in C:\wamp\fuel\vendor\composer\ClassLoader.php on line 349
WARNING - 2015-01-19 20:07:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:07:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:10:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:11:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:11:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:11:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
WARNING - 2015-01-19 20:11:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
