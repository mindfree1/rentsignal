<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-12-24 00:28:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:28:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:28:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:28:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:28:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:28:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:28:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:33:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:33:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:33:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:33:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:33:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:33:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:34:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:34:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:34:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:34:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:34:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:35:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:35:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:35:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:35:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:35:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:35:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:35:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:35:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:35:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:35:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:35:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:35:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:35:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:35:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:37:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:37:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:37:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:37:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:37:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:37:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:37:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:38:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:38:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:38:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:38:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:38:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:38:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:38:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:40:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:40:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:40:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:40:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:40:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:40:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:40:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:40:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:41:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:41:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:41:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:41:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:41:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:41:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:41:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:41:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:41:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:42:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:42:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:42:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:42:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:42:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:42:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:42:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:42:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:45:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:45:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:45:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:50:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:50:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:50:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:50:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:50:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:51:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:51:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:51:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:51:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:51:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:53:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:53:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:53:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:53:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:53:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:53:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:53:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:56:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:56:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:56:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:56:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:56:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:56:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:57:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:57:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:57:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:57:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:58:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:58:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 00:58:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 00:58:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 00:58:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:02:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:02:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:02:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:02:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:02:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:04:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:04:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:04:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:04:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:05:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:05:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:05:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:05:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:06:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:06:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:06:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:06:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:06:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:06:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:06:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:06:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:07:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:07:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:07:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:07:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:07:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:07:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:07:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:09:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:09:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:09:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:09:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:09:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:09:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:09:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:11:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:11:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:11:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:11:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:11:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:11:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:11:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:13:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:14:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:14:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:14:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:14:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:14:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:14:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:15:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:16:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:16:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:16:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:16:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:18:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:20:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:20:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:20:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:20:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:20:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:20:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:20:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:20:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:20:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:21:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:21:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:21:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:21:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:21:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:22:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:22:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:22:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:22:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:22:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:23:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:23:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:24:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:24:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:24:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:24:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:50 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:24:50 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:24:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:24:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:25:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:25:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:25:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:25:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:25:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:25:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:26:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:26:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:26:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:26:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:26:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:26:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:26:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:27:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:27:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:27:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:27:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:27:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:27:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:27:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:27:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:27:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:29:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:29:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:29:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:29:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:29:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:29:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:29:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:29:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:29:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:30:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:30:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:30:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:30:36 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:30:36 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:31:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:32:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:32:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:33:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:33:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:33:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:33:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:34:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:34:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:34:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:35:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:35:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:35:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:35:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:43:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:43:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 01:43:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 01:43:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 01:43:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 02:17:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 02:17:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 02:17:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 02:17:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 02:17:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 14:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 14:24:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 14:24:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:24:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 14:24:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 14:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:25:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 14:25:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 14:25:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-12-24 14:25:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-12-24 14:25:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-12-24 14:25:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
