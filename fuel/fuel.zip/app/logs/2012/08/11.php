<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-08-11 12:47:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-08-11 12:47:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
