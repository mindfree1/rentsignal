<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-06-22 14:00:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:00:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:01:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:01:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:01:01 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-22 14:01:01 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-06-22 14:41:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 14:41:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-06-22 19:26:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
