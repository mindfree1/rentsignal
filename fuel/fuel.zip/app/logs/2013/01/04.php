<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-01-04 12:36:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-04 12:36:05 --> Error - Could not find asset: jScrollPane.css in C:\wamp\fuel\core\classes\asset.php on line 154
Warning - 2013-01-04 12:36:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 12:39:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 12:39:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 12:39:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 12:39:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 12:39:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:07:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:07:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:07:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:07:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-04 14:18:32 --> 8 - Undefined variable: pages in C:\wamp\fuel\app\classes\model\showlistings.php on line 45
Error - 2013-01-04 14:18:32 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 51
Error - 2013-01-04 14:18:32 --> 8 - Undefined variable: result in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
Error - 2013-01-04 14:18:32 --> 2 - Invalid argument supplied for foreach() in C:\wamp\fuel\app\classes\model\showlistings.php on line 53
Error - 2013-01-04 14:18:32 --> 8 - Undefined variable: url in C:\wamp\fuel\app\classes\model\showlistings.php on line 58
Error - 2013-01-04 14:18:32 --> 8 - Undefined variable: image_amount in C:\wamp\fuel\app\views\listings\listings.php on line 36
Warning - 2013-01-04 14:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:18:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:18:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-04 14:18:51 --> 8 - Undefined variable: max in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
Error - 2013-01-04 14:18:51 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 42
Error - 2013-01-04 14:18:51 --> 8 - Undefined variable: numrows in C:\wamp\fuel\app\classes\model\showlistings.php on line 51
Warning - 2013-01-04 14:18:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:18:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:19:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:19:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-01-04 14:19:49 --> 8 - Undefined variable: max in C:\wamp\fuel\app\classes\model\showlistings.php on line 41
Warning - 2013-01-04 14:19:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:19:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:19:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:20:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:20:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:20:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:20:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:20:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:20:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:20:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-01-04 14:20:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-01-04 14:20:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-01-04 14:20:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
