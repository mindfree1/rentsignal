<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-11-12 22:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:13:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:13:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:13:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:13:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:13:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:13:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:13:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:13:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:14:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:14:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:14:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:14:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:14:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:14:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:14:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:14:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:14:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:14:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:14:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:14:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:15:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:15:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:15:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:15:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:15:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:15:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:15:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 22:15:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 22:15:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 22:15:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:26:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:26:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:26:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:33:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:33:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:33:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:33:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:33:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:33:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:33:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:33:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:34:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:34:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:34:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:35:38 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:35:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:35:42 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:35:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:35:44 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:35:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:35:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:21 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:22 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:23 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:26 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:27 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:28 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:30 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:31 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-11-12 23:36:31 --> Error - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8,8' at line 1 with query: "SELECT * FROM `images` order by id limit -8,8" in C:\wamp\fuel\core\classes\database\pdo\connection.php on line 137
Warning - 2012-11-12 23:36:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:49 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:49 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:36:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:36:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:36:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:37:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:37:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:37:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:38:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:38:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:38:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2012-11-12 23:39:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-11-12 23:39:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2012-11-12 23:39:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
