<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-11-06 21:59:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
