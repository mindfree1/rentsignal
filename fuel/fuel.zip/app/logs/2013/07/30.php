<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2013-07-30 00:02:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-30 00:02:24 --> 8 - Undefined variable: start in C:\wamp\fuel\app\classes\model\showlistings.php on line 36
Warning - 2013-07-30 00:02:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:02:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:02:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:39 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:02:39 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:02:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:02:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:03:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:03:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:35 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:03:35 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:03:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:03:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:03:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:05:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:05:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:05:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:05:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:12:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:12:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:12:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:12:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:13:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:17:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:17:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:17:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:17:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:18:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:18:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:18:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2013-07-30 00:21:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2013-07-30 00:21:35 --> 8 - Undefined variable: content in C:\wamp\fuel\app\views\welcome\index.php on line 67
Warning - 2013-07-30 00:21:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:21:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:21:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:21:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2013-07-30 00:21:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2013-07-30 00:21:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
