<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2014-10-11 12:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:25:08 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 37
Warning - 2014-10-11 12:25:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:25:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:25:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:25:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:25:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:25:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:25:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:25:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:25:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:25:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:26:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:26:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:26:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:26:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:28:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:28:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:28:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:28:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:28:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:28:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:34:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:34:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:34:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:34:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:34:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:34:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:35:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:35:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:35:09 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Warning - 2014-10-11 12:35:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:35:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:35:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:35:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:35:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:35:33 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Warning - 2014-10-11 12:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:35:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:37:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:37:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:37:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:37:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:37:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:37:29 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Warning - 2014-10-11 12:37:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:37:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:38:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:38:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:38:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:38:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:38:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:38:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:38:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:39:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:39:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:39:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:39:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:39:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:39:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:40:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:40:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:40:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:40:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:40:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:40:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:40:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:42:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:42:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:42:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:42:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:42:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:42:27 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2014-10-11 12:42:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:42:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:42:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:42:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:42:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:42:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:43:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:43:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:43:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:43:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:43:03 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2014-10-11 12:43:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:43:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:44:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:44:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:44:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:44:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:44:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:44:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:44:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:44:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:45:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:45:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:45:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:45:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:45:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:45:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:46:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:46:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:46:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:46:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:46:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:46:44 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 12:46:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:46:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:48:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:48:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:48:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:48:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:48:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:48:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:48:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:49:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:49:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:49:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:49:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:49:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:49:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:49:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:49:01 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:49:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:49:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:49:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:49:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:49:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:49:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:49:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:49:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:49:24 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:49:24 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:49:24 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:50:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:50:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:50:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:50:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:50:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:50:20 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:50:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:50:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:50:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:50:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:50:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:50:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 12:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:51:03 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:51:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:53:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:53:08 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:53:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:53:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:53:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:53:08 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:53:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:53:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:53:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:53:41 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:53:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:53:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:54:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:54:27 --> 8 - Undefined offset: -1 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 12:54:27 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:54:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:54:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:54:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:54:42 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 12:54:42 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:54:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:54:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:55:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:55:03 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:55:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:55:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:55:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:55:08 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:55:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:55:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:55:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:55:56 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:55:56 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:55:56 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:55:56 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:55:56 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 12:55:56 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:55:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:55:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 12:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 12:56:32 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 12:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 12:56:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:00:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:00:40 --> 8 - Undefined variable: img_amount2 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:00:40 --> 8 - Undefined variable: img_amount2 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:00:40 --> 8 - Undefined variable: img_amount2 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:00:40 --> 8 - Undefined variable: img_amount2 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:00:40 --> 8 - Undefined variable: img_amount2 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:00:40 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2014-10-11 13:00:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:00:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:01:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:01:13 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 35
Warning - 2014-10-11 13:01:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:01:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:02:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:02:52 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 13:02:52 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 13:02:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:02:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:03:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:03:12 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 13:03:12 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 13:03:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:03:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:03:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:03:30 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:03:30 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 13:03:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:03:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:10:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:10:51 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:10:51 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 13:10:51 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:10:51 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:11:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:11:14 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Error - 2014-10-11 13:11:14 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 34
Warning - 2014-10-11 13:11:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:11:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:12:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:12:16 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 13:12:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:12:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:12:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Error - 2014-10-11 13:12:57 --> 8 - Undefined offset: 5 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 13:12:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:12:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:14:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:14:08 --> 8 - Undefined offset: 4 in C:\wamp\fuel\app\views\listings\listings.php on line 32
Warning - 2014-10-11 13:14:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:14:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:33:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:33:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:33:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:34:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:34:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:34:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:34:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:34:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:34:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:34:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:37:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:37:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:27 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:37:27 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:37:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:37:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 13:37:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:37:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:39:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:39:16 --> 8 - Undefined variable: per_page in C:\wamp\fuel\app\classes\model\showlistings.php on line 20
Error - 2014-10-11 13:39:16 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 13:39:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:39:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 13:58:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 13:58:46 --> 8 - Undefined offset: 8 in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 13:58:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 13:58:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:01:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:01:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:01:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:01:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:01:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:01:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:01:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:01:29 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:01:29 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:04:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 14:04:01 --> Parsing Error - syntax error, unexpected T_STRING, expecting ',' or ';' in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 14:04:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 14:04:20 --> Parsing Error - syntax error, unexpected T_LNUMBER, expecting ',' or ';' in C:\wamp\fuel\app\views\listings\listings.php on line 33
Warning - 2014-10-11 14:04:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:04:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:04:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:05:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:05:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:05:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:44 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:44 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:06:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:06:45 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:06:45 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 14:08:09 --> 8 - Undefined variable: img_amount2 in C:\wamp\fuel\app\classes\model\showlistings.php on line 68
Error - 2014-10-11 14:08:09 --> 8 - Undefined index:  in C:\wamp\fuel\app\classes\model\showlistings.php on line 68
Warning - 2014-10-11 14:08:09 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:08:09 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:08:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:08:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:08:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:09:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:09:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:09:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:09:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:09:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:09:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:09:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:01 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:01 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:13 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:13 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:31 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:31 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:41 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:41 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:10:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:10:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:10:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:18:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:18:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:18:52 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:18:52 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:18:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:18:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:18:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:18:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:19:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:19:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:19:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:19:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:19:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:19:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:19:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:19:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:19:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 14:19:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 14:19:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 14:19:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:08:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:08:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:08:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:08:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:08:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:08:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:09:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:09:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:09:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:09:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:09:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:09:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:09:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:11:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 15:11:08 --> 8 - Undefined variable: response in C:\wamp\fuel\app\classes\model\mapgen.php on line 37
Warning - 2014-10-11 15:11:08 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:11:08 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:39:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:39:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:39:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:39:54 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:39:54 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:39:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:39:55 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:39:55 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:39:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:39:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:39:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:40:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-10-11 15:40:07 --> Fuel\Core\Validation::errors - This method is deprecated. Please use Validation::error() instead.
Warning - 2014-10-11 15:40:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2014-10-11 15:40:17 --> 8 - Undefined variable: current_user in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Error - 2014-10-11 15:40:17 --> 8 - Trying to get property of non-object in C:\wamp\fuel\app\classes\controller\admin.php on line 39
Warning - 2014-10-11 15:40:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:17 --> Fuel\Core\View::factory - This method is deprecated.  Please use a forge() instead.
Warning - 2014-10-11 15:40:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:40:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:40:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:40:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:40:56 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:40:56 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:44:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:44:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:44:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:44:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:44:23 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:44:23 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:58:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:58:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:58:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:58:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:58:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:59:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:59:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:59:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:11 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:59:11 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:59:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:59:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 15:59:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 15:59:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 15:59:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:00:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:00:03 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:00:03 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:00:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:00:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:00:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:00:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:01:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:01:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:01:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:01:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:01:33 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:01:33 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:02:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:02:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:02:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:10 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:02:10 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:02:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:02:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:02:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:02:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:03:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:00 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:03:00 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:03:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:03:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:03:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:03:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:03:48 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:03:48 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:04:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:15 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:04:15 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:04:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:04:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:04:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:28 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:04:28 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:04:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:04:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:04:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:05:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:02 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:05:02 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:05:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:30 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:05:30 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:05:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:38 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:05:38 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:05:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:05:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:05:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:05:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:05:59 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:05:59 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:06:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:06:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:06:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:06:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:08:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:08:16 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:08:16 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:08:16 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:08:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:08:20 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:08:20 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:08:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:08:21 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:08:21 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:15:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:15:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:15:37 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:15:37 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:15:42 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:15:42 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:15:42 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:15:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:15:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:15:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:24:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:22 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:24:22 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:24:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:24:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:24:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:25 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:24:25 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:24:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:24:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:24:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:24:46 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:24:46 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:25:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:25:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:25:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:12 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:25:12 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:25:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:34 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:25:34 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:25:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:25:43 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:25:43 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:31:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:31:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:31:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:31:58 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:31:58 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:31:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:31:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:31:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:32:05 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:32:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:32:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:32:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:32 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:32:32 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:32:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:40 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:32:40 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:32:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:32:57 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:32:57 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:33:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:33:04 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:33:04 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:33:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:33:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:33:19 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:33:19 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:33:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:33:26 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:33:26 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:34:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:06 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:34:06 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:34:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:14 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:34:14 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:34:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:34:47 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:34:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:34:53 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:34:53 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:35:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:35:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:35:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:35:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:35:07 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:35:07 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:35:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:35:17 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:35:17 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
Warning - 2014-10-11 16:35:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2014-10-11 16:35:18 --> Fuel\Core\Request::execute - The Controller_ShowListings::after() method should accept and return the Controller's response, empty return for the after() method is deprecated.
Warning - 2014-10-11 16:35:18 --> Fuel\Core\Request::execute - The Controller_ShowListings controller should return a string or a Response object, support for the $controller->response object is deprecated.
