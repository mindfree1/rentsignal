<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-06-19 18:30:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 18:31:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 18:32:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:32:41 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Error - 2012-06-19 18:32:41 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 18:32:41 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Error - 2012-06-19 18:32:41 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 18:32:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:32:53 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 18:32:53 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 18:33:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:33:54 --> Parsing Error - syntax error, unexpected T_LOGICAL_AND, expecting ')' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 9
Warning - 2012-06-19 18:35:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:35:30 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-19 18:36:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 18:37:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:37:40 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 18:38:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:38:10 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 18:38:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:38:32 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 18:38:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 18:47:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:47:58 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 8 - Use of undefined constant long - assumed 'long' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 8 - Undefined offset: 1 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Error - 2012-06-19 18:47:58 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-19 18:47:58 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 18:47:58 --> 8 - Use of undefined constant lat - assumed 'lat' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 8 - Use of undefined constant long - assumed 'long' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 18:47:58 --> 2 - Illegal offset type in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Warning - 2012-06-19 18:48:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:48:43 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-19 18:48:43 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 18:48:43 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-19 18:48:43 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-19 18:49:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:49:06 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-19 18:49:06 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 18:49:06 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-19 18:49:06 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-19 18:55:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:55:50 --> 8 - Undefined variable: coords_array in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Error - 2012-06-19 18:55:50 --> 2 - Invalid argument supplied for foreach() in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Error - 2012-06-19 18:55:50 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:55:50 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-19 18:55:50 --> 8 - Undefined variable: coords_array in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Error - 2012-06-19 18:55:50 --> 2 - Invalid argument supplied for foreach() in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Error - 2012-06-19 18:55:50 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:55:50 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Warning - 2012-06-19 18:57:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:57:22 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:57:22 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-19 18:57:22 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:57:22 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Warning - 2012-06-19 18:58:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:58:13 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:58:13 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Warning - 2012-06-19 18:59:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:59:30 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Trying to get property of non-object in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 18:59:30 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Warning - 2012-06-19 18:59:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 18:59:57 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:59:57 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-19 18:59:57 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 18:59:57 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Warning - 2012-06-19 19:00:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:00:29 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 19:00:29 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Error - 2012-06-19 19:00:29 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 25
Error - 2012-06-19 19:00:29 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 26
Warning - 2012-06-19 19:01:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:01:24 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:01:24 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:01:24 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:01:24 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:01:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:01:39 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:06:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:06:59 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:08:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:08:56 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 15
Warning - 2012-06-19 19:11:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:11:06 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 24
Warning - 2012-06-19 19:11:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:11:22 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 16
Warning - 2012-06-19 19:11:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:11:23 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 16
Warning - 2012-06-19 19:12:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:12:15 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:12:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:12:35 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:12:35 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:12:35 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:12:35 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:12:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:12:56 --> Error - Function name must be a string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:15:17 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:15:17 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:15:17 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:15:17 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:15:17 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:15:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:15:43 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:15:43 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 19:15:43 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:15:43 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-19 19:16:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:16:02 --> Parsing Error - syntax error, unexpected T_ECHO in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:19:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:19:19 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:19:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: v in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: i in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: v in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 13
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:19:48 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:19:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:19:59 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:19:59 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:19:59 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:19:59 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:20:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:20:35 --> Parsing Error - syntax error, unexpected T_NS_SEPARATOR, expecting ',' or ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:20:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:20:47 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 19:21:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:21:05 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:21:05 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:21:05 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:21:05 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:21:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:21:27 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:21:27 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:21:27 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:21:27 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:21:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:21:53 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:21:53 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 19:21:53 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 19:21:53 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 19:22:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 19:22:04 --> Parsing Error - syntax error, unexpected '/' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 21:03:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:03:02 --> Parsing Error - syntax error, unexpected '/' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 14
Warning - 2012-06-19 21:03:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:03:12 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 21:03:12 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 21:03:12 --> 8 - Undefined variable: getlat in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 21:03:12 --> 8 - Undefined variable: getlong in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 21:04:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:04:18 --> 8 - Undefined variable: coord in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 21:04:18 --> 8 - Undefined variable: getcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 21:04:18 --> 8 - Undefined variable: coord in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Error - 2012-06-19 21:04:18 --> 8 - Undefined variable: getcoords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 21:04:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:07:12 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:10:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:10:15 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 21:11:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:11:07 --> Parsing Error - syntax error, unexpected '<' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 21:13:05 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:13:05 --> Parsing Error - syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ',' or ';' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 21:13:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:14:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:14:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:15:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:16:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:16:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:16:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:17:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:17:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:18:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:18:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:19:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:19:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:20:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:29:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:29:58 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:30:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:31:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:32:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:32:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:36:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:36:28 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:37:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:37:01 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:37:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:38:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:38:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:39:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:39:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:40:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:40:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:40:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:41:06 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:41:06 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:41:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:41:08 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:41:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:41:24 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:42:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:42:03 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:42:15 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:42:15 --> Parsing Error - syntax error, unexpected T_ENCAPSED_AND_WHITESPACE, expecting T_STRING or T_VARIABLE or T_NUM_STRING in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Warning - 2012-06-19 21:42:45 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:43:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:44:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:44:13 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 18
Warning - 2012-06-19 21:45:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:45:36 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-19 21:46:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:46:33 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 21
Warning - 2012-06-19 21:47:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:49:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:49:38 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:50:37 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:51:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:51:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:51:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:51:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:52:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:55:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:56:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:56:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:56:44 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:57:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:58:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:58:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:59:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 21:59:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 21:59:59 --> 4096 - Object of class Model_Rentsignals could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:00:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:00:09 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Error - 2012-06-19 22:00:09 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Error - 2012-06-19 22:00:09 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Error - 2012-06-19 22:00:09 --> 8 - Undefined variable: coords in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Warning - 2012-06-19 22:00:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:00:22 --> 4096 - Object of class Model_Rentsignals could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:00:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:00:35 --> 8 - Undefined offset: 0 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:00:35 --> 4096 - Object of class Model_Rentsignals could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:04:14 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:04:15 --> 4096 - Object of class Model_Rentsignals could not be converted to string in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:10:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:10:04 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 22:10:04 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-19 22:30:02 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:30:02 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:30:02 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:30:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:30:19 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:30:19 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:30:50 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:30:50 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:30:50 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:30:51 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:30:51 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:30:51 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:31:43 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:31:43 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:31:43 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:33:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:33:19 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:33:19 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:35:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:35:09 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:35:09 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:36:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:36:18 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:36:18 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:36:19 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:36:19 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:36:19 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:36:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:36:30 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:36:30 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:38:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:38:11 --> Parsing Error - syntax error, unexpected '[', expecting '(' in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 27
Warning - 2012-06-19 22:38:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:38:25 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:38:25 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:40:41 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:40:41 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 22:40:41 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 22:43:34 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:43:34 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:43:34 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:44:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:44:27 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:44:27 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:46:47 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 22:46:47 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Error - 2012-06-19 22:46:47 --> 8 - Undefined variable: key in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 35
Warning - 2012-06-19 22:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:54:03 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:54:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:55:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:55:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:56:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:56:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:57:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:58:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:58:30 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 22:58:49 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:01:10 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:01:11 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 23:01:11 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-19 23:01:23 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:01:23 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 23:01:23 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-19 23:01:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:01:33 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Error - 2012-06-19 23:01:33 --> 8 - Undefined offset: 1 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 17
Error - 2012-06-19 23:01:33 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 20
Warning - 2012-06-19 23:02:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:02:01 --> Compile Error - Cannot use [] for reading in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 16
Warning - 2012-06-19 23:02:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:02:11 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 16
Warning - 2012-06-19 23:02:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:02:29 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:02:29 --> 8 - Undefined offset: 2 in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 16
Warning - 2012-06-19 23:03:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:03:48 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:22 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:28 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:04:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:09:24 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:09:24 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 23:09:24 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 23:09:24 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 23:09:24 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 23:09:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-19 23:09:26 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 23:09:26 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 23:09:26 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Error - 2012-06-19 23:09:26 --> 8 - Array to string conversion in C:\wamp\www\rentsignal\fuel\app\views\welcome\index.php on line 19
Warning - 2012-06-19 23:09:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:10:31 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:10:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:11:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:12:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:13:25 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:13:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:14:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:14:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:15:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:15:54 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:26:26 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:26:55 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:29:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:30:36 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:31:07 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:31:27 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:31:40 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:32:04 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:32:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:33:11 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:34:18 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:34:53 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:35:32 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:35:57 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:36:39 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:37:01 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:37:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:37:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:37:59 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:38:13 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:38:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:52:08 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:53:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:53:35 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:53:56 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:54:20 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:55:00 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:58:52 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:59:21 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Warning - 2012-06-19 23:59:46 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
