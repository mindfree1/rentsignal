<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-06-15 14:03:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:06:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:07:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:07:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:09:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:11:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-06-15 14:11:14 --> Error - Could not find asset: jquery-ui-1.8.21 in C:\wamp\www\rentsignal\fuel\core\classes\asset.php on line 154
Warning - 2012-06-15 14:11:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:15:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:16:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:18:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:19:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:20:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-06-15 14:22:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-06-15 14:36:33 --> 8 - date_default_timezone_set(): Timezone ID 'Autralia/Sydeny' is invalid in C:\wamp\www\rentsignal\fuel\core\classes\fuel.php on line 178
Warning - 2012-06-15 14:36:33 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
Error - 2012-06-15 14:38:09 --> 8 - date_default_timezone_set(): Timezone ID 'Australia/Sydeny' is invalid in C:\wamp\www\rentsignal\fuel\core\classes\fuel.php on line 178
Warning - 2012-06-15 14:38:09 --> Fuel\Core\Fuel::init - The configured locale en_AU is not installed on your system.
